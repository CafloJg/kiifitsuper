import React, { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { auth, db } from './lib/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { useStore } from './lib/store';
import Login from './pages/Login';
import Register from './pages/Register';
import ResetPassword from './pages/ResetPassword';
import Onboarding from './pages/Onboarding';
import Dashboard from './pages/Dashboard';
import Goals from './pages/Goals';
import Diet from './pages/Diet';
import Chat from './pages/Chat';
import Admin from './pages/Admin';
import Profile from './pages/Profile';
import { resetDailyStats } from './utils/dailyReset';
import type { UserProfile } from './types/user';
import NetworkStatus from './components/NetworkStatus';

function App() {
  const [isReady, setIsReady] = useState(false);
  const { setUser } = useStore();

  // Handle mobile viewport height
  useEffect(() => {
    const setVH = () => {
      const vh = window.innerHeight * 0.01;
      document.documentElement.style.setProperty('--vh', `${vh}px`);
    };
    
    setVH();
    window.addEventListener('resize', setVH);
    window.addEventListener('orientationchange', setVH);
    
    return () => {
      window.removeEventListener('resize', setVH);
      window.removeEventListener('orientationchange', setVH);
    };
  }, []);

  useEffect(() => {
    const setupDailyReset = async () => {
      if (!auth.currentUser) return;

      // Get current time and calculate time until midnight
      const now = new Date();
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0);
      
      const timeUntilMidnight = tomorrow.getTime() - now.getTime();

      // Check if we need to reset now
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const userDoc = await getDoc(userRef);
      const userData = userDoc.data() as UserProfile | undefined;
      if (!userData) return;

      if (userData?.lastCheckIn) {
        const lastCheckDate = new Date(userData.lastCheckIn);
        const today = new Date();
        
        // If last check-in was not today, trigger auto check-in
        if (lastCheckDate.getDate() !== today.getDate() ||
            lastCheckDate.getMonth() !== today.getMonth() ||
            lastCheckDate.getFullYear() !== today.getFullYear()) {
          await resetDailyStats(); // Reset stats first
          
          // Update check-in streak
          const yesterday = new Date(today);
          yesterday.setDate(yesterday.getDate() - 1);
          
          const streak = lastCheckDate.getDate() === yesterday.getDate() ? 
            (userData.checkInStreak || 0) + 1 : 1;

          await updateDoc(userRef, {
            lastCheckIn: today.toISOString(),
            checkInStreak: streak,
            updatedAt: new Date().toISOString(),
            lastDietReset: new Date().toISOString(),
            lastDietReset: today.toISOString()
          });
        }
      }

      // Schedule next reset at midnight
      const scheduleNextReset = () => {
        const timer = setTimeout(async () => {
          try {
            await resetDailyStats(auth.currentUser.uid); // Reset at midnight
            // Set up daily interval after first reset
            setInterval(async () => {
              if (auth.currentUser) {
                await resetDailyStats(auth.currentUser.uid);
              }
            }, 24 * 60 * 60 * 1000);
          } catch (error) {
            console.error('Error in scheduled reset:', error);
            // Retry in 5 minutes if there's an error
            setTimeout(scheduleNextReset, 5 * 60 * 1000);
          } 
        }, timeUntilMidnight);

        return timer;
      };

      const timer = scheduleNextReset();
      return () => clearTimeout(timer);
    };
    
    setupDailyReset();
    setIsReady(true);
  }, []);

  if (!isReady) {
    return (
      <div className="fixed inset-0 bg-white flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <BrowserRouter>
      <div className="min-h-[100vh] min-h-[calc(var(--vh,1vh)*100)] bg-gray-50 flex flex-col">
        <Routes>
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/onboarding" element={<Onboarding />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/goals" element={<Goals />} />
          <Route path="/diet" element={<Diet />} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/profile" element={<Profile />} />
        </Routes>
        <NetworkStatus />
      </div>
    </BrowserRouter>
  );
}

export default App;