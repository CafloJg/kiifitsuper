import { useQuery } from '@tanstack/react-query';
import { ImageService } from '../lib/services/imageService';
import type { ImageResult } from '../types/image';

export function useFoodImage(foodName: string, enabled = true) {
  const imageService = ImageService.getInstance();

  return useQuery<ImageResult>({
    queryKey: ['foodImage', foodName],
    queryFn: () => imageService.getImage(foodName),
    enabled: enabled && !!foodName,
    staleTime: 24 * 60 * 60 * 1000, // 24 hours
    gcTime: 7 * 24 * 60 * 60 * 1000, // 7 days
    retry: 1,
    retryDelay: 1000
  });
}