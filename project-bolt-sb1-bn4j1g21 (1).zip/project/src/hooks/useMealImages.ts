import { useState, useEffect } from 'react';
import { getImage } from '../utils/imageService';
import type { Meal } from '../types/user';

interface ImageCache {
  [key: string]: {
    imageUrl: string;
    thumbnailUrl: string;
  };
}

export function useMealImages(meal: Meal, isExpanded: boolean) {
  const [mealImage, setMealImage] = useState<string | null>(null);
  const [foodImages, setFoodImages] = useState<ImageCache>({});
  const [isLoading, setIsLoading] = useState(true);

  // Load meal header image
  useEffect(() => {
    const loadMealImage = async () => {
      if (!meal.name) return;

      try {
        // Try to get a more specific image based on meal type
        const searchTerm = meal.name.toLowerCase().includes('café') ? 'gourmet breakfast plate served restaurant'
          : meal.name.toLowerCase().includes('almoço') ? 'gourmet lunch plate served restaurant'
          : meal.name.toLowerCase().includes('jantar') ? 'gourmet dinner plate served restaurant'
          : meal.name.toLowerCase().includes('lanche') ? 'healthy snack plate served restaurant'
          : `${meal.name} gourmet plate served restaurant`;
          
        const image = await getImage(searchTerm);
        setMealImage(image.thumbnailUrl);
      } catch (error) {
        console.warn('Error loading meal image:', error);
      }
    };

    loadMealImage();
  }, [meal.name]);

  // Load food images when expanded
  useEffect(() => {
    if (!isExpanded) return;

    const loadFoodImages = async () => {
      setIsLoading(true);
      try {
        const newImages: ImageCache = {};
        
        // Load images in parallel with better error handling
        const imagePromises = meal.foods.map(async (food) => {
          if (!food.name) return;
          
          try {
            // Try to use existing food image first
            if (food.thumbnailUrl && food.imageUrl) {
              newImages[food.id] = {
                imageUrl: food.imageUrl,
                thumbnailUrl: food.thumbnailUrl
              };
              return;
            }
            
            // Otherwise fetch new image
            const searchTerm = `${food.name} food plate served restaurant style`;
            const image = await getImage(searchTerm);
            newImages[food.id] = image;
          } catch (error) {
            console.warn(`Error loading image for ${food.name}:`, error);
            // Use food's existing images or fallback
            newImages[food.id] = {
              imageUrl: food.imageUrl || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=2000',
              thumbnailUrl: food.thumbnailUrl || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=400'
            };
          }
        });
        
        await Promise.all(imagePromises);

        setFoodImages(newImages);
      } catch (error) {
        console.error('Error loading food images:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadFoodImages();
  }, [isExpanded, meal.foods]);

  return {
    mealImage,
    foodImages,
    isLoading
  };
}