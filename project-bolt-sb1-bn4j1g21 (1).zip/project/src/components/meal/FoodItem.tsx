import React, { memo, useState } from 'react';
import { ThumbsUp, ThumbsDown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import type { Food } from '../../types/user';
import type { ImageResult } from '../../utils/imageService';

interface FoodItemProps {
  food: Food;
  image: ImageResult | undefined;
  showNutrients: boolean;
  onFeedback: (foodId: string, type: 'like' | 'dislike') => void;
  preferences: Record<string, { type: 'like' | 'dislike'; score: number }>;
}

const FoodItem = memo(({ food, image, showNutrients, onFeedback, preferences }: FoodItemProps) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4 p-3 sm:p-4 bg-gray-50 hover:bg-gray-100 rounded-xl relative overflow-hidden transition-colors shadow-sm"
      role="listitem"
      aria-label={`${food.name} - ${food.calories} calorias`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <motion.div 
        className="w-full sm:w-24 h-32 sm:h-24 rounded-xl overflow-hidden flex-shrink-0 shadow-lg relative bg-gray-100"
        whileHover={{ scale: 1.05 }}
      >
        {image?.thumbnailUrl ? (
          <img
            src={image.thumbnailUrl}
            alt={food.name}
            className="w-full h-full object-cover animate-fade-in"
            loading="lazy"
            onError={(e) => {
              const img = e.target as HTMLImageElement;
              if (food.thumbnailUrl) {
                img.src = food.thumbnailUrl;
              } else {
                img.src = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=400';
              }
            }}
          />
        ) : (
          <img
            src={food.thumbnailUrl || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=400'}
            alt={food.name}
            className="w-full h-full object-cover animate-fade-in"
            loading="lazy"
          />
        )}
      </motion.div>
      
      <div className="flex-1 min-w-0 flex flex-col">
        <motion.p 
          layout
          className="font-semibold text-base sm:text-lg text-gray-800 mb-1"
        >
          {food.name}
        </motion.p>
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <span>{food.portion}</span>
          <span>•</span>
          <span>{food.calories} kcal</span>
          {showNutrients && (
            <AnimatePresence>
              <span>•</span>
              <span>P: {food.protein}g</span>
              <span>•</span>
              <span>C: {food.carbs}g</span>
              <span>•</span>
              <span>G: {food.fat}g</span>
            </AnimatePresence>
          )}
        </div>
        
        <motion.div 
          className="flex items-center gap-2 mt-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <button
            onClick={() => onFeedback(food.id, 'like')}
            aria-label={`Gostei de ${food.name}`}
            aria-pressed={preferences[food.id]?.type === 'like'}
            className={`preference-button ${
              preferences[food.id]?.type === 'like'
                ? 'liked'
                : ''
            }`}
          >
            <ThumbsUp size={16} />
          </button>
          <button
            onClick={() => onFeedback(food.id, 'dislike')}
            aria-label={`Não gostei de ${food.name}`}
            aria-pressed={preferences[food.id]?.type === 'dislike'}
            className={`preference-button ${
              preferences[food.id]?.type === 'dislike'
                ? 'disliked'
                : ''
            }`}
          >
            <ThumbsDown size={16} />
          </button>
        </motion.div>
      </div>
    </motion.div>
  );
});

FoodItem.displayName = 'FoodItem';

export default FoodItem;