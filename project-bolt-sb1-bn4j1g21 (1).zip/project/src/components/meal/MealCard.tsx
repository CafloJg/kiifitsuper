import React, { useCallback, useState } from 'react';
import { useState } from 'react';
import { Check, Utensils, Plus, Loader2, Clock, ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { auth } from '../../lib/firebase';
import MealHeader from './MealHeader';
import FoodItem from './FoodItem';
import AddIngredient from './AddIngredient';
import { useFoodPreferences } from '../../hooks/useFoodPreferences';
import { useMealImages } from '../../hooks/useMealImages';
import type { Meal, Food } from '../../types/user';

interface MealCardSkeletonProps {
  animate?: boolean;
}

const MealCardSkeleton = ({ animate = true }: MealCardSkeletonProps) => (
  <div className={`bg-white rounded-2xl p-6 shadow-sm ${animate ? 'animate-pulse' : ''}`}>
    <div className="flex items-center gap-4 mb-6">
      <div className="w-14 h-14 bg-gray-200 rounded-xl" />
      <div className="flex-1">
        <div className="h-6 w-32 bg-gray-200 rounded mb-2" />
        <div className="h-4 w-24 bg-gray-200 rounded" />
      </div>
    </div>
    <div className="space-y-4">
      {[1, 2, 3].map(i => (
        <div key={i} className="h-24 bg-gray-200 rounded-xl" />
      ))}
    </div>
  </div>
);
interface MealCardProps {
  meal: Meal;
  isCompleted: boolean;
  onCheckIn: (mealId: string) => void;
  isLoading?: boolean;
}

const MealCard = ({ meal, isCompleted, onCheckIn, isLoading = false }: MealCardProps) => {
  const {
    isExpanded,
    setIsExpanded,
    isFavorite,
    isUpdating,
    showNutrients,
    setShowNutrients,
    foodPreferences,
    handleFavorite,
    handleFoodFeedback,
    handleAddIngredient,
    error
  } = useFoodPreferences(meal);

  const [showAddIngredient, setShowAddIngredient] = useState(false);

  const { mealImage, foodImages, isLoading: imagesLoading } = useMealImages(meal, isExpanded);

  const handleMealCheckIn = useCallback(async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!auth.currentUser || isCompleted || isUpdating) return;
    onCheckIn(meal.id);
  }, [auth.currentUser, isCompleted, isUpdating, meal.id, onCheckIn]);

  if (isLoading) {
    return <MealCardSkeleton />;
  }

  return (
    <motion.article 
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`
        diet-card ${getMealTypeClass(meal.name)}
        ${isCompleted ? 'border-2 border-green-500' : ''}
        transition-all duration-300
      `}
    >
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className={`
              w-14 h-14 rounded-xl flex items-center justify-center
              ${getMealIconBackground(meal.name)} 
              transform transition-transform hover:scale-110
            `}>
              {getMealIcon(meal)}
            </div>
            <div>
              <h3 className="text-2xl font-semibold mb-1 text-gray-800">{meal.name}</h3>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 text-sm text-gray-500">
                  <Clock size={14} className="text-primary-400" />
                  <span>{meal.time}</span>
                </div>
                <div className="flex items-center gap-1 text-sm text-gray-500">
                  <span>•</span>
                  <span>{meal.calories} kcal</span>
                </div>
              </div>
            </div>
          </div>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            {isExpanded ? (
              <ChevronUp size={20} className="text-gray-400" />
            ) : (
              <ChevronDown size={20} className="text-gray-400" />
            )}
          </button>
        </div>

        {/* Macros */}
        <AnimatePresence>
          <div className="flex items-center gap-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="macro-chip macro-protein"
            >
              <span>{meal.protein}g</span>
              <span>Proteína</span>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 }}
              className="macro-chip macro-carbs"
            >
              <span>{meal.carbs}g</span>
              <span>Carboidratos</span>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="macro-chip macro-fat"
            >
              <span>{meal.fat}g</span>
              <span>Gorduras</span>
            </motion.div>
          </div>
        </AnimatePresence>

        {/* Foods */}
        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-4 overflow-hidden"
            >
              {meal.foods.map((food, index) => (
                <motion.div
                  key={food.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="food-item-card"
                >
                  <div className="food-image-container">
                    <img
                      src={food.thumbnailUrl}
                      alt={food.name}
                      className="w-full h-full object-cover transition-transform duration-300"
                    />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-lg font-medium mb-2">{food.name}</h4>
                    <p className="text-sm text-gray-500">{food.portion}</p>
                    <div className="flex items-center gap-3 mt-3">
                      <div className="text-sm font-medium text-primary-500">
                        {food.calories} kcal
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="macro-chip macro-protein text-xs">
                          P: {food.protein}g
                        </div>
                        <div className="macro-chip macro-carbs text-xs">
                          C: {food.carbs}g
                        </div>
                        <div className="macro-chip macro-fat text-xs">
                          G: {food.fat}g
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Action Button */}
        {!isCompleted ? (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleMealCheckIn}
            className={`
              w-full py-4 rounded-xl text-white font-medium
              transition-all duration-300 transform
              ${isLoading 
                ? 'bg-gray-300 cursor-not-allowed'
                : 'bg-gradient-to-r from-primary-500 to-secondary-500 hover:shadow-lg hover:-translate-y-0.5'
              }
            `}
          >
            <div className="flex items-center justify-center gap-2">
              {isLoading ? (
                <Loader2 size={20} className="animate-spin" />
              ) : (
                <Utensils size={20} className="animate-bounce-subtle" />
              )}
              <span>
                {isLoading ? 'Processando...' : 'Marcar como Concluída'}
              </span>
            </div>
          </motion.button>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex items-center justify-center gap-2 py-4 bg-green-50 rounded-xl text-green-500"
          >
            <Check size={20} className="completion-check" />
            <span className="font-medium">Refeição Concluída</span>
          </motion.div>
        )}
      </div>
    </motion.article>
  );
}

// Helper functions
function getMealTypeClass(mealName: string): string {
  const name = mealName.toLowerCase();
  if (name.includes('café')) return 'meal-breakfast';
  if (name.includes('almoço')) return 'meal-lunch';
  if (name.includes('lanche')) return 'meal-snack';
  if (name.includes('jantar')) return 'meal-dinner';
  return '';
}

function getMealIconBackground(mealName: string): string {
  const name = mealName.toLowerCase();
  if (name.includes('café')) return 'bg-blue-50 text-blue-500';
  if (name.includes('almoço')) return 'bg-green-50 text-green-500';
  if (name.includes('lanche')) return 'bg-orange-50 text-orange-500';
  if (name.includes('jantar')) return 'bg-purple-50 text-purple-500';
  return 'bg-gray-50 text-gray-500';
}

MealCard.displayName = 'MealCard';

export default MealCard;