import React, { useState, useEffect } from 'react';
import { auth, db } from '../lib/firebase';
import { doc, updateDoc, getDoc } from 'firebase/firestore';
import { Activity, Calendar, Coins, TrendingUp, Award } from 'lucide-react';
import { resetDailyStats } from '../utils/dailyReset';
import type { UserProfile } from '../types/user';

interface DailyCheckInProps {
  userData: UserProfile;
  onCheckIn: () => void;
}

function DailyCheckIn({ userData, onCheckIn }: DailyCheckInProps) {
  const [isChecking, setIsChecking] = useState(false);
  const [showReward, setShowReward] = useState(false);
  const [earnedCoins, setEarnedCoins] = useState(0);
  const [canCheck, setCanCheck] = useState(false);
  const [timeUntilNextCheck, setTimeUntilNextCheck] = useState<string>('');
  const [isResetting, setIsResetting] = useState(false);

  const isSameDay = (date1: Date, date2: Date) => {
    return (
      date1.getFullYear() === date2.getFullYear() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getDate() === date2.getDate()
    );
  };

  useEffect(() => {
    const checkAvailability = () => {
      const now = new Date();

      if (!userData.lastCheckIn) {
        setCanCheck(true);
        return;
      }

      const lastCheckDate = new Date(userData.lastCheckIn);
      const canCheckIn = !isSameDay(lastCheckDate, now);
      setCanCheck(canCheckIn);

      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 1, 0, 0);
      
      const timeLeft = tomorrow.getTime() - now.getTime();
      const hours = Math.floor(timeLeft / (1000 * 60 * 60));
      const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
      
      setTimeUntilNextCheck(`${hours}h ${minutes}m`);
    };

    checkAvailability();
    const interval = setInterval(checkAvailability, 60000);
    
    return () => clearInterval(interval);
  }, [userData.lastCheckIn]);

  const calculateReward = () => {
    let coins = 10;
    
    if (userData.checkInStreak) {
      if (userData.checkInStreak >= 30) coins += 50;
      else if (userData.checkInStreak >= 7) coins += 20;
      else if (userData.checkInStreak >= 3) coins += 10;
    }
    
    return coins;
  };

  const handleCheckIn = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!auth.currentUser || !canCheck || isChecking || isResetting) return;
    
    const now = new Date();
    setIsResetting(true);
    const today = now.toISOString().split('T')[0];

    setIsChecking(true);
    try {
      // Reset daily stats first
      await resetDailyStats(auth.currentUser.uid);
      
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const userDoc = await getDoc(userRef);
      const currentData = userDoc.data() as UserProfile;
      
      if (currentData.lastCheckIn) {
        const lastCheckDate = new Date(currentData.lastCheckIn);
        if (isSameDay(lastCheckDate, now)) {
          setCanCheck(false);
          setIsChecking(false);
          return;
        }
      }
      
      let streak = 1;
      if (currentData.lastCheckIn) {
        const lastCheckDate = new Date(currentData.lastCheckIn);
        const yesterday = new Date(now);
        yesterday.setDate(yesterday.getDate() - 1);
        
        if (isSameDay(lastCheckDate, yesterday)) {
          streak = (currentData.checkInStreak || 0) + 1;
        }
      }
      
      const coins = calculateReward();
      
      await updateDoc(userRef, {
        lastCheckIn: now.toISOString(),
        checkInStreak: streak,
        lastDietReset: now.toISOString(),
        totalCoins: (currentData.totalCoins || 0) + coins
      });

      setEarnedCoins(coins);
      setShowReward(true);
      setCanCheck(false);
      onCheckIn();
      setIsResetting(false);
    } catch (error) {
      setError(
        error instanceof Error 
          ? error.message 
          : 'Erro ao fazer check-in. Tente novamente.'
      );
      setIsResetting(false);
    } finally {
      setIsChecking(false);
    }
  };

  if (showReward) {
    return (
      <div className="mobile-card p-6">
        <div className="relative z-10">
          <div className="w-20 h-20 bg-primary-50 rounded-2xl flex items-center justify-center mx-auto mb-6 transform hover:rotate-12 transition-transform">
            <Coins className="text-primary-500" size={40} />
          </div>
          <h3 className="text-2xl font-semibold text-center mb-3">Parabéns!</h3>
          <p className="text-gray-600 text-center mb-6">
            Você ganhou {earnedCoins} moedas pelo check-in diário!
          </p>
          <div className="inline-flex items-center gap-2 bg-primary-50 px-4 py-2 rounded-xl text-primary-500 w-full justify-center">
            <TrendingUp size={20} />
            <span className="font-medium">
              Sequência atual: {userData.checkInStreak || 1} dias
            </span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mobile-card p-6 glass-card">
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-primary-50 rounded-2xl flex items-center justify-center transform hover:rotate-12 transition-transform pulse-effect">
              <Calendar className="text-primary-500" size={28} />
            </div>
            <div>
              <h3 className="font-semibold text-lg">Check-in Diário</h3>
              <p className="text-sm text-gray-500">
                {userData.checkInStreak 
                  ? `Sequência: ${userData.checkInStreak} dias` 
                  : 'Faça check-in todos os dias'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-primary-50 px-3 py-1.5 rounded-xl glow-effect">
            <Coins className="text-primary-500" size={18} />
            <span className="font-medium">{userData.totalCoins || 0}</span>
          </div>
        </div>

        <button
          onClick={handleCheckIn}
          disabled={!canCheck || isChecking}
          className={`mobile-button neon-border relative ${
            canCheck
              ? 'bg-primary-500 text-white active:bg-primary-600'
              : 'bg-gray-100 text-gray-400'
          }`}
        >
          <div className="flex items-center justify-center gap-2">
            <Award size={20} className={canCheck ? 'animate-pulse float-effect' : ''} />
            <span className="font-medium">
              {isChecking 
                ? 'Processando...' 
                : canCheck
                  ? 'Fazer Check-in'
                  : `Próximo check-in em ${timeUntilNextCheck}`}
            </span>
          </div>
          {isResetting && (
            <div className="absolute inset-0 bg-black/10 rounded-lg flex items-center justify-center">
              <span className="text-sm text-white">Reiniciando refeições...</span>
            </div>
          )}
        </button>
      </div>
    </div>
  );
}

export default DailyCheckIn;