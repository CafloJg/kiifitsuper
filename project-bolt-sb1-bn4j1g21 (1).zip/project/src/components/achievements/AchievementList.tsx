import React from 'react';
import { useVirtualizer } from '@tanstack/react-virtual';
import { Trophy } from 'lucide-react';
import { useAchievements } from '../../hooks/useAchievements';
import AchievementCard from './AchievementCard';
import type { UserProfile } from '../../types/user';

interface AchievementListProps {
  user: UserProfile;
  onClose: () => void;
}

function AchievementList({ user, onClose }: AchievementListProps) {
  const { achievements, progress, isLoading } = useAchievements(user);
  const parentRef = React.useRef<HTMLDivElement>(null);

  const virtualizer = useVirtualizer({
    count: achievements.data?.length || 0,
    getScrollElement: () => parentRef.current,
    estimateSize: () => 200,
    overscan: 5
  });

  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center">
        <div className="bg-white rounded-2xl p-6 max-w-lg w-full mx-4">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/2" />
            <div className="space-y-3">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-40 bg-gray-100 rounded-2xl" />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-14 h-14 bg-primary-50 rounded-2xl flex items-center justify-center">
              <Trophy className="text-primary-500" size={28} />
            </div>
            <div>
              <h2 className="text-xl font-semibold">Conquistas</h2>
              <p className="text-sm text-gray-500">
                {progress.data?.completed || 0} de {progress.data?.total || 0} completadas
              </p>
            </div>
          </div>

          {/* Progress Overview */}
          <div className="grid grid-cols-3 gap-4">
            <div className="p-3 bg-gray-50 rounded-xl text-center">
              <p className="text-sm text-gray-600">Total</p>
              <p className="text-xl font-semibold text-primary-500">
                {progress.data?.total || 0}
              </p>
            </div>
            <div className="p-3 bg-gray-50 rounded-xl text-center">
              <p className="text-sm text-gray-600">Completas</p>
              <p className="text-xl font-semibold text-green-500">
                {progress.data?.completed || 0}
              </p>
            </div>
            <div className="p-3 bg-gray-50 rounded-xl text-center">
              <p className="text-sm text-gray-600">Em Progresso</p>
              <p className="text-xl font-semibold text-blue-500">
                {progress.data?.inProgress || 0}
              </p>
            </div>
          </div>
        </div>

        {/* Achievement List */}
        <div 
          ref={parentRef}
          className="flex-1 overflow-auto p-6"
          style={{ height: `calc(90vh - 200px)` }}
        >
          <div
            style={{
              height: `${virtualizer.getTotalSize()}px`,
              width: '100%',
              position: 'relative'
            }}
          >
            {virtualizer.getVirtualItems().map((virtualItem) => {
              const achievement = achievements.data?.[virtualItem.index];
              if (!achievement) return null;

              return (
                <div
                  key={achievement.id}
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: `${virtualItem.size}px`,
                    transform: `translateY(${virtualItem.start}px)`
                  }}
                  className="p-2"
                >
                  <AchievementCard 
                    achievement={achievement}
                    onCollectReward={() => {
                      // Handle reward collection
                      console.log('Collect reward for:', achievement.id);
                    }}
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* Close Button */}
        <div className="p-6 border-t border-gray-100">
          <button
            onClick={onClose}
            className="w-full py-3 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}

export default AchievementList;