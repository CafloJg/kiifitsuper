import { doc, getDoc, updateDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { DietPlan } from '../../types/user';
import { z } from 'zod';

const dietPlanSchema = z.object({
  id: z.string(),
  userId: z.string(),
  createdAt: z.string(),
  totalCalories: z.number(),
  proteinTarget: z.number(),
  carbsTarget: z.number(),
  fatTarget: z.number(),
  meals: z.array(z.object({
    id: z.string(),
    name: z.string(),
    time: z.string(),
    calories: z.number(),
    protein: z.number(),
    carbs: z.number(),
    fat: z.number(),
    foods: z.array(z.object({
      name: z.string(),
      portion: z.string(),
      calories: z.number(),
      protein: z.number(),
      carbs: z.number(),
      fat: z.number()
    }))
  }))
});

export class DietRepository {
  private static instance: DietRepository;

  private constructor() {}

  static getInstance(): DietRepository {
    if (!this.instance) {
      this.instance = new DietRepository();
    }
    return this.instance;
  }

  async getCurrentPlan(userId: string): Promise<DietPlan | null> {
    try {
      const userDoc = await getDoc(doc(db, 'users', userId));
      if (!userDoc.exists()) return null;

      const userData = userDoc.data();
      if (!userData.currentDietPlan) return null;

      const validatedPlan = dietPlanSchema.parse(userData.currentDietPlan);
      return validatedPlan as DietPlan;
    } catch (error) {
      console.error('Error fetching current plan:', error);
      throw error;
    }
  }

  async getDietHistory(userId: string): Promise<DietPlan[]> {
    try {
      const userDoc = await getDoc(doc(db, 'users', userId));
      if (!userDoc.exists()) return [];

      const userData = userDoc.data();
      if (!userData.dietHistory?.plans) return [];

      const validatedPlans = z.array(dietPlanSchema).parse(userData.dietHistory.plans);
      return validatedPlans as DietPlan[];
    } catch (error) {
      console.error('Error fetching diet history:', error);
      throw error;
    }
  }

  async updateCurrentPlan(userId: string, plan: DietPlan): Promise<void> {
    try {
      const validatedPlan = dietPlanSchema.parse(plan);
      await updateDoc(doc(db, 'users', userId), {
        currentDietPlan: validatedPlan,
        updatedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error updating current plan:', error);
      throw error;
    }
  }
}