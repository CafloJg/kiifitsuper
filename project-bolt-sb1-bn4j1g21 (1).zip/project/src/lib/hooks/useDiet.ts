import { useCallback } from 'react';
import { useStore } from '../store';
import { DietRepository } from '../repositories/dietRepository';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import type { DietPlan } from '../../types/user';

export function useDiet(userId: string | undefined) {
  const queryClient = useQueryClient();
  const { setCurrentPlan, setGenerating, setError } = useStore();
  const dietRepo = DietRepository.getInstance();

  const { data: currentPlan } = useQuery({
    queryKey: ['diet', 'current', userId],
    queryFn: () => userId ? dietRepo.getCurrentPlan(userId) : null,
    enabled: !!userId
  });

  const { data: dietHistory } = useQuery({
    queryKey: ['diet', 'history', userId],
    queryFn: () => userId ? dietRepo.getDietHistory(userId) : [],
    enabled: !!userId
  });

  const updatePlanMutation = useMutation({
    mutationFn: (plan: DietPlan) => 
      userId ? dietRepo.updateCurrentPlan(userId, plan) : Promise.reject('No user ID'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['diet'] });
    }
  });

  const updateCurrentPlan = useCallback(async (plan: DietPlan) => {
    try {
      if (!userId) throw new Error('User not authenticated');
      await updatePlanMutation.mutateAsync(plan);
      setCurrentPlan(plan);
    } catch (error) {
      console.error('Error updating plan:', error);
      setError(error instanceof Error ? error.message : 'Failed to update plan');
    }
  }, [userId, updatePlanMutation, setCurrentPlan, setError]);

  return {
    currentPlan,
    dietHistory,
    isLoading: updatePlanMutation.isPending,
    error: updatePlanMutation.error,
    updateCurrentPlan
  };
}