import { z } from 'zod';
import type { UserProfile, Achievement } from '../../types/user';

const achievementSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  type: z.enum(['daily', 'weekly', 'monthly', 'special']),
  icon: z.string(),
  reward: z.number(),
  progress: z.number().min(0).max(100),
  completed: z.boolean(),
  completedAt: z.string().optional(),
  requirements: z.object({
    type: z.string(),
    target: z.number(),
    current: z.number()
  })
});

export class AchievementService {
  private static instance: AchievementService;

  private constructor() {}

  static getInstance(): AchievementService {
    if (!this.instance) {
      this.instance = new AchievementService();
    }
    return this.instance;
  }

  private getAvailableAchievements(user: UserProfile): Achievement[] {
    return [
      {
        id: 'streak-7',
        title: 'Semana Perfeita',
        description: 'Complete 7 dias seguidos de check-in',
        type: 'weekly',
        icon: 'calendar',
        reward: 50,
        progress: (user.checkInStreak || 0) / 7 * 100,
        completed: (user.checkInStreak || 0) >= 7,
        requirements: {
          type: 'streak',
          target: 7,
          current: user.checkInStreak || 0
        }
      },
      {
        id: 'protein-goal',
        title: 'Mestre das Proteínas',
        description: 'Atinja sua meta de proteínas por 5 dias',
        type: 'weekly',
        icon: 'target',
        reward: 30,
        progress: ((user.dailyStats?.proteinGoalsReached || 0) / 5) * 100,
        completed: (user.dailyStats?.proteinGoalsReached || 0) >= 5,
        requirements: {
          type: 'protein_goals',
          target: 5,
          current: user.dailyStats?.proteinGoalsReached || 0
        }
      },
      {
        id: 'water-master',
        title: 'Hidratação Perfeita',
        description: 'Atinja sua meta de água por 3 dias',
        type: 'weekly',
        icon: 'droplet',
        reward: 20,
        progress: ((user.dailyStats?.waterGoalsReached || 0) / 3) * 100,
        completed: (user.dailyStats?.waterGoalsReached || 0) >= 3,
        requirements: {
          type: 'water_goals',
          target: 3,
          current: user.dailyStats?.waterGoalsReached || 0
        }
      }
    ];
  }

  async checkAchievements(user: UserProfile): Promise<Achievement[]> {
    try {
      const achievements = this.getAvailableAchievements(user);
      
      // Check for newly completed achievements
      const newlyCompleted = achievements.filter(achievement => {
        const wasCompleted = user.achievements?.[achievement.id]?.completed;
        return achievement.completed && !wasCompleted;
      });

      if (newlyCompleted.length > 0) {
        // Award coins for new achievements
        const totalReward = newlyCompleted.reduce((sum, a) => sum + a.reward, 0);
        
        // Update user's total coins
        // This would be handled by the UserService in a real implementation
        console.log('Coins earned:', totalReward);
      }

      return achievements;
    } catch (error) {
      console.error('Error checking achievements:', error);
      throw new Error('Failed to check achievements');
    }
  }

  async getProgress(user: UserProfile): Promise<{
    total: number;
    completed: number;
    inProgress: number;
    nextAchievement?: Achievement;
  }> {
    try {
      const achievements = this.getAvailableAchievements(user);
      const completed = achievements.filter(a => a.completed).length;
      const inProgress = achievements.filter(a => !a.completed && a.progress > 0).length;
      
      // Find next achievement close to completion
      const nextAchievement = achievements
        .filter(a => !a.completed)
        .sort((a, b) => b.progress - a.progress)[0];

      return {
        total: achievements.length,
        completed,
        inProgress,
        nextAchievement
      };
    } catch (error) {
      console.error('Error getting achievement progress:', error);
      throw new Error('Failed to get achievement progress');
    }
  }
}