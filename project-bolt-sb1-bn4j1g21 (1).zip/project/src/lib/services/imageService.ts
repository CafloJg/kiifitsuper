import { ImageRepository } from '../repositories/imageRepository';
import { getUnsplashImage } from '../../utils/unsplash';
import { getPixabayImage } from '../../utils/pixabay';
import type { ImageResult } from '../../types/image';

export class ImageService {
  private static instance: ImageService;
  private readonly imageRepo: ImageRepository;
  private readonly DEFAULT_IMAGE: ImageResult = {
    imageUrl: 'https://images.unsplash.com/photo-1635321593200-5ca363bfdb02?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1635321593200-5ca363bfdb02?q=80&w=400'
  };

  private constructor() {
    this.imageRepo = ImageRepository.getInstance();
  }

  static getInstance(): ImageService {
    if (!this.instance) {
      this.instance = new ImageService();
    }
    return this.instance;
  }

  async getImage(query: string, forceRefresh = false): Promise<ImageResult> {
    if (!query?.trim()) {
      return this.DEFAULT_IMAGE;
    }

    try {
      const normalizedQuery = query.toLowerCase().trim();

      // Check repository first if not forcing refresh
      if (!forceRefresh) {
        const cachedImage = await this.imageRepo.getImageByFoodName(normalizedQuery);
        if (cachedImage) {
          return cachedImage;
        }
      }

      // Try Unsplash first
      try {
        const result = await getUnsplashImage(`${normalizedQuery} food plated dish`);
        await this.imageRepo.cacheImage(normalizedQuery, result.imageUrl, result.thumbnailUrl);
        return result;
      } catch (unsplashError) {
        console.warn('Unsplash error, falling back to Pixabay:', unsplashError);
        
        // Try Pixabay as fallback
        const result = await getPixabayImage(normalizedQuery);
        await this.imageRepo.cacheImage(normalizedQuery, result.imageUrl, result.thumbnailUrl);
        return result;
      }
    } catch (error) {
      console.error('Error getting image:', {
        query,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
      return this.DEFAULT_IMAGE;
    }
  }

  async cleanupCache(): Promise<void> {
    await this.imageRepo.cleanupOldCache();
  }
}