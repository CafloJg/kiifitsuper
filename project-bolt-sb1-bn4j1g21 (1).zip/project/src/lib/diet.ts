import { doc, getDoc, updateDoc, writeBatch, runTransaction } from 'firebase/firestore';
import { db } from './firebase';
import { auth } from './firebase';
import { getOpenAIKey } from '../utils/apiKeys';
import { calculateTargetMacros } from './dailyStats';
import { getImage } from '../utils/imageService';
import type { UserProfile, DietPlan } from '../types/user';

const RETRY_DELAY = 2000; // 2 seconds between retries

// Helper function to validate meal plan structure
function validateMealPlan(plan: any): void {
  if (!plan || typeof plan !== 'object') {
    throw new Error('Resposta inválida do serviço.');
  }

  if (!Array.isArray(plan.meals) || plan.meals.length !== 5) {
    throw new Error('Plano alimentar inválido: número incorreto de refeições.');
  }

  plan.meals.forEach((meal: any, index: number) => {
    if (!meal.name || !Array.isArray(meal.foods) || meal.foods.length === 0) {
      throw new Error(`Refeição ${index + 1} inválida: dados incompletos.`);
    }

    meal.foods.forEach((food: any, foodIndex: number) => {
      if (!food.name || !food.portion || typeof food.calories !== 'number') {
        throw new Error(`Alimento ${foodIndex + 1} da refeição ${index + 1} inválido.`);
      }
    });
  });
}

// Calculate daily calories based on user profile
function calculateDailyCalories(user: UserProfile): number {
  if (!user.weight || !user.height || !user.age || !user.gender || !user.goals) {
    throw new Error('Dados do usuário incompletos.');
  }

  // Harris-Benedict formula
  let bmr = 0;
  if (user.gender === 'masculino') {
    bmr = 88.362 + (13.397 * user.weight) + (4.799 * user.height) - (5.677 * user.age);
  } else {
    bmr = 447.593 + (9.247 * user.weight) + (3.098 * user.height) - (4.330 * user.age);
  }

  // Activity factor
  let activityFactor = 1.2; // Sedentary
  if (user.goals.activityLevel === 'moderate') activityFactor = 1.375;
  if (user.goals.activityLevel === 'active') activityFactor = 1.55;
  if (user.goals.activityLevel === 'very_active') activityFactor = 1.725;

  let tdee = bmr * activityFactor;

  // Adjust based on goal
  switch (user.goals.type) {
    case 'loss':
      tdee *= 0.85; // 15% deficit
      break;
    case 'gain':
      tdee *= 1.15; // 15% surplus
      break;
  }

  return Math.round(tdee);
}

// Cache configuration
const CACHE_TTL = 10 * 60 * 1000; // 10 minutes
const planCache = new Map<string, {
  plan: DietPlan;
  timestamp: number;
  macros: { calories: number; protein: number; carbs: number; fat: number };
}>();

// Validation constants
const CALORIE_TOLERANCE = 100; // ±100 kcal
const MACRO_TOLERANCE = 5;    // ±5g for macros
const REQUIRED_MEAL_TIMES = ['07:00', '12:00', '16:00', '20:00'];

// Error handling
const MAX_RETRIES = 3;

// Helper function to get cache key
function getCacheKey(user: UserProfile): string {
  return JSON.stringify({
    weight: user.weight,
    height: user.height,
    age: user.age,
    gender: user.gender,
    goals: user.goals,
    dietType: user.dietType,
    allergies: user.allergies,
    foodPreferences: user.foodPreferences
  });
}

export async function calculateMacros(ingredients: string[]): Promise<{
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
}> {
  if (!ingredients || ingredients.length === 0) {
    throw new Error('Por favor, forneça os ingredientes para calcular os macros.');
  }

  try {
    const apiKey = await getOpenAIKey();
    if (!apiKey) {
      throw new Error('Serviço temporariamente indisponível. Entre em contato com o suporte.');
    }

    const prompt = `
      Calcule os macronutrientes para os seguintes alimentos usando a TACO:
      ${ingredients.join('\n')}

      Retorne apenas um objeto JSON com este formato exato:
      {
        "calories": number,
        "protein": number,
        "carbs": number,
        "fat": number,
        "fiber": number
      }

      Regras:
      1. Use APENAS valores da TACO (Tabela Brasileira de Composição de Alimentos)
      2. Para alimentos não encontrados, use valores de alimentos similares
      3. Retorne apenas números, sem unidades
      4. Arredonde todos os valores para números inteiros
      5. Valores devem ser sempre positivos
      6. Retorne apenas o objeto JSON, sem texto adicional
    `;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4-turbo-preview',
        messages: [
          {
            role: 'system',
            content: 'You are a professional nutritionist. Return a valid JSON with the following structure: {"calories": number, "protein": number, "carbs": number, "fat": number, "fiber": number}'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.1,
        max_tokens: 500,
        presence_penalty: 0.6,
        frequency_penalty: 0.3
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error('OpenAI API error:', errorData);
      throw new Error(`Erro da API: ${errorData.error?.message || 'Erro desconhecido'}`);
    }

    const data = await response.json();
    
    if (!data.choices || !data.choices[0]?.message?.content) {
      console.error("Invalid API response format:", data);
      throw new Error('Erro ao calcular macros. Por favor, tente novamente.');
    }
    
    const cleanJson = data.choices[0].message.content.trim();
    const jsonMatch = cleanJson.match(/\{[\s\S]*\}/);
    
    if (!jsonMatch) {
      throw new Error('Erro ao processar resposta. Por favor, tente novamente.');
    }

    const macros = JSON.parse(jsonMatch[0]);

    const requiredFields = ['calories', 'protein', 'carbs', 'fat', 'fiber'];
    for (const field of requiredFields) {
      if (!(field in macros) || typeof macros[field] !== 'number') {
        throw new Error(`Campo ${field} ausente na resposta`);
      }
      if (typeof macros[field] !== 'number' || macros[field] < 0) {
        throw new Error('Erro ao calcular macros. Por favor, tente novamente.');
      }
    }

    return {
      calories: Math.round(macros.calories),
      protein: Math.round(macros.protein),
      carbs: Math.round(macros.carbs),
      fat: Math.round(macros.fat),
      fiber: Math.round(macros.fiber)
    };
  } catch (error) {
    console.error('Erro ao calcular macros:', error);
    if (error instanceof Error) {
      if (error.message.includes('API key') || error.message.includes('rate limit')) {
        throw new Error('Serviço temporariamente indisponível. Por favor, tente novamente em alguns minutos.');
      }
      if (error.message.includes('network') || error.message.includes('Failed to fetch')) {
        throw new Error('Erro de conexão. Verifique sua internet e tente novamente.');
      }
      throw error;
    }
    throw new Error('Erro ao calcular macros. Por favor, tente novamente.');
  }
}