import { create } from 'zustand';
import { devtools, persist, createJSONStorage } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import { createUserSlice, type UserSlice } from './slices/userSlice';
import { createDietSlice, type DietSlice } from './slices/dietSlice';
import { createAuthSlice, type AuthSlice } from './slices/authSlice';

export type RootState = UserSlice & DietSlice & AuthSlice;

export const useStore = create<RootState>()(
  devtools(
    persist(
      immer((...a) => ({
        ...createUserSlice(...a),
        ...createDietSlice(...a),
        ...createAuthSlice(...a),
      })),
      {
        name: 'kiifit-store',
        partialize: (state) => ({
          user: {
            uid: state.user?.uid,
            email: state.user?.email,
            subscriptionTier: state.user?.subscriptionTier,
            completedOnboarding: state.user?.completedOnboarding
          },
          auth: {
            isAuthenticated: state.auth.isAuthenticated
          }
        }),
        storage: createJSONStorage(() => ({
          getItem: (name) => {
            const data = localStorage.getItem(name);
            return data ? JSON.parse(data) : null;
          },
          setItem: (name, value) => {
            localStorage.setItem(name, JSON.stringify(value));
          },
          removeItem: (name) => localStorage.removeItem(name)
        }))
      }
    )
  )
);