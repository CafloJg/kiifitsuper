import { doc, getDoc, setDoc, collection, query, where, getDocs, runTransaction } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { getUnsplashImage } from './unsplash';
import { getPixabayImage } from './pixabay';
import { foodCategories } from '../data/foodImages';

// Constants
const CACHE_DURATION = 7 * 24 * 60 * 60 * 1000; // 7 days
const MAX_RETRIES = 3;
const RETRY_DELAY = 1000;
const MAX_CACHE_SIZE = 1000;
const BATCH_SIZE = 5;

// Types
export interface ImageResult {
  imageUrl: string;
  thumbnailUrl: string;
}

export interface ImageCache {
  imageUrl: string;
  thumbnailUrl: string;
  timestamp: string;
  category?: string;
}

// Track in-flight requests
const pendingRequests = new Map<string, Promise<ImageResult>>();

// Default high-quality food image
const DEFAULT_FOOD_IMAGE: ImageResult = {
  imageUrl: 'https://images.unsplash.com/photo-1635321593200-5ca363bfdb02?q=80&w=2000',
  thumbnailUrl: 'https://images.unsplash.com/photo-1635321593200-5ca363bfdb02?q=80&w=400'
};

// High-quality curated images for common foods
const CURATED_IMAGES: Record<string, ImageResult> = {
  // Proteínas
  'frango grelhado': {
    imageUrl: 'https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?q=80&w=400'
  },
  'frango': {
    imageUrl: 'https://images.unsplash.com/photo-1606728035253-49e8a23146de?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1606728035253-49e8a23146de?q=80&w=400'
  },
  'peixe': {
    imageUrl: 'https://images.unsplash.com/photo-1615141982883-c7ad0e69fd62?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1615141982883-c7ad0e69fd62?q=80&w=400'
  },
  'atum': {
    imageUrl: 'https://images.unsplash.com/photo-1599084993091-1cb5c0721cc6?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1599084993091-1cb5c0721cc6?q=80&w=400'
  },
  'sardinha': {
    imageUrl: 'https://images.unsplash.com/photo-1580217593608-61931cefc821?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1580217593608-61931cefc821?q=80&w=400'
  },
  'carne': {
    imageUrl: 'https://images.unsplash.com/photo-1546964124-0cce460f38ef?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1546964124-0cce460f38ef?q=80&w=400'
  },
  // Nuts and Seeds
  'castanhas': {
    imageUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY=',
    thumbnailUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY='
  },
  'castanha do pará': {
    imageUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY=',
    thumbnailUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY='
  },
  'castanha de caju': {
    imageUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY=',
    thumbnailUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY='
  },
  'amendoim': {
    imageUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY=',
    thumbnailUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY='
  },
  'nozes': {
    imageUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY=',
    thumbnailUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY='
  },
  // Temperos e Suplementos
  'açúcar': {
    imageUrl: 'https://images.unsplash.com/photo-1581441363689-1f3c3c414635?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1581441363689-1f3c3c414635?q=80&w=400'
  },
  'sal': {
    imageUrl: 'https://images.unsplash.com/photo-1518110925495-5fe287c921f7?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1518110925495-5fe287c921f7?q=80&w=400'
  },
  'azeite': {
    imageUrl: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?q=80&w=400'
  },
  'pimenta': {
    imageUrl: 'https://images.unsplash.com/photo-1514517604298-cf80e0fb7f1e?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1514517604298-cf80e0fb7f1e?q=80&w=400'
  },
  'whey protein': {
    imageUrl: 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?q=80&w=400'
  },
  'creatina': {
    imageUrl: 'https://images.unsplash.com/photo-1627467959547-8e44da7aa00a?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1627467959547-8e44da7aa00a?q=80&w=400'
  },
  'bcaa': {
    imageUrl: 'https://images.unsplash.com/photo-1579722820308-d74e571900a9?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1579722820308-d74e571900a9?q=80&w=400'
  },
  'mel': {
    imageUrl: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?q=80&w=400'
  },
  'adoçante': {
    imageUrl: 'https://images.unsplash.com/photo-1581441363689-1f3c3c414635?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1581441363689-1f3c3c414635?q=80&w=400'
  },
  'ovos mexidos': {
    imageUrl: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?q=80&w=400'
  },
  'ovos': {
    imageUrl: 'https://images.unsplash.com/photo-1506976785307-8732e854ad03?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1506976785307-8732e854ad03?q=80&w=400'
  },
  'salmão grelhado': {
    imageUrl: 'https://images.unsplash.com/photo-1485921325833-c519f76c4927?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1485921325833-c519f76c4927?q=80&w=400'
  },
  // Laticínios
  'iogurte natural': {
    imageUrl: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?q=80&w=400'
  },
  'iogurte': {
    imageUrl: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?q=80&w=400'
  },
  'queijo': {
    imageUrl: 'https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?q=80&w=400'
  },
  'queijo branco': {
    imageUrl: 'https://images.unsplash.com/photo-1624806992066-5ffcf7ca186b?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1624806992066-5ffcf7ca186b?q=80&w=400'
  },
  'requeijão': {
    imageUrl: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?q=80&w=400'
  },
  // Vegetais
  'salada verde': {
    imageUrl: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?q=80&w=400'
  },
  'alface': {
    imageUrl: 'https://images.unsplash.com/photo-1622205313162-be1d5712a43b?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1622205313162-be1d5712a43b?q=80&w=400'
  },
  'tomate': {
    imageUrl: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?q=80&w=400'
  },
  'cenoura': {
    imageUrl: 'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?q=80&w=400'
  },
  'brócolis': {
    imageUrl: 'https://images.unsplash.com/photo-1583663848850-46af132dc08e?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1583663848850-46af132dc08e?q=80&w=400'
  },
  'batata': {
    imageUrl: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?q=80&w=400'
  },
  // Grãos
  'arroz integral': {
    imageUrl: 'https://images.unsplash.com/photo-1516684732162-798a0062be99?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1516684732162-798a0062be99?q=80&w=400'
  },
  'arroz': {
    imageUrl: 'https://images.unsplash.com/photo-1516684732162-798a0062be99?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1516684732162-798a0062be99?q=80&w=400'
  },
  'feijão': {
    imageUrl: 'https://images.unsplash.com/photo-1612257999756-11e70dec1b82?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1612257999756-11e70dec1b82?q=80&w=400'
  },
  'quinoa': {
    imageUrl: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?q=80&w=400'
  },
  'aveia': {
    imageUrl: 'https://images.unsplash.com/photo-1586201375835-b935e237314f?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1586201375835-b935e237314f?q=80&w=400'
  },
  'pão integral': {
    imageUrl: 'https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?q=80&w=400'
  },
  'pão': {
    imageUrl: 'https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?q=80&w=400'
  },
  'abobrinha grelhada': {
    imageUrl: 'https://images.unsplash.com/photo-1572453800999-e8d2d1589b7c?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1572453800999-e8d2d1589b7c?q=80&w=400'
  },
  'legumes cozidos': {
    imageUrl: 'https://images.unsplash.com/photo-1580013759032-c96505e24c1f?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1580013759032-c96505e24c1f?q=80&w=400'
  },
  // Frutas
  'banana': {
    imageUrl: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?q=80&w=400'
  },
  'maçã': {
    imageUrl: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?q=80&w=400'
  },
  'laranja': {
    imageUrl: 'https://images.unsplash.com/photo-1557800636-894a64c1696f?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1557800636-894a64c1696f?q=80&w=400'
  },
  'mamão': {
    imageUrl: 'https://images.unsplash.com/photo-1517282009859-f000ec3b26fe?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1517282009859-f000ec3b26fe?q=80&w=400'
  },
  'frutas frescas': {
    imageUrl: 'https://images.unsplash.com/photo-1619566636858-adf3ef46400b?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1619566636858-adf3ef46400b?q=80&w=400'
  },
  'frutas variadas': {
    imageUrl: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?q=80&w=2000',
    thumbnailUrl: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?q=80&w=400'
  },
  'castanhas': {
    imageUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY=',
    thumbnailUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY='
  },
  'castanha do pará': {
    imageUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY=',
    thumbnailUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY='
  },
  'castanha de caju': {
    imageUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY=',
    thumbnailUrl: 'https://media.istockphoto.com/id/701022106/pt/foto/mix-almonds-cashew-nuts-peanuts-pistachio-top-view.jpg?s=612x612&w=0&k=20&c=iwS5vvnwP2hX018gmNsJEqe_VgLdzsUSndIbff0GpZY='
  }
};

// Helper to find best matching curated image
function findBestCuratedMatch(query: string): ImageResult | null {
  const normalizedQuery = query.toLowerCase();
  const queryWords = normalizedQuery.split(/\s+/);
  
  // Remove common words that might interfere with matching
  const cleanWords = queryWords.filter(word => 
    !['com', 'de', 'do', 'da', 'e', 'ou'].includes(word)
  );
  
  // Try exact match first
  if (CURATED_IMAGES[normalizedQuery]) {
    return CURATED_IMAGES[normalizedQuery];
  }
  
  // Try matching individual words
  for (const word of cleanWords) {
    if (CURATED_IMAGES[word]) {
      return CURATED_IMAGES[word];
    }
  }
  
  // Try matching nut types specifically
  if (queryWords.includes('castanha') || queryWords.includes('castanhas')) {
    if (queryWords.includes('pará')) {
      return CURATED_IMAGES['castanha do pará'];
    }
    if (queryWords.includes('caju')) {
      return CURATED_IMAGES['castanha de caju'];
    }
    return CURATED_IMAGES['castanhas'];
  }
  
  // Try partial matches
  for (const [key, image] of Object.entries(CURATED_IMAGES)) {
    if (cleanWords.some(word => key.includes(word))) {
      return image;
    }
  }
  
  // Try category matches
  for (const [category, data] of Object.entries(foodCategories)) {
    if (data.items.some(item => 
      cleanWords.some(word => item.name.toLowerCase().includes(word))
    )) {
      // Return first matching curated image for category
      const categoryImage = Object.entries(CURATED_IMAGES)
        .find(([key]) => data.items.some(item => 
          cleanWords.some(word => key.includes(word))
        ));
      if (categoryImage) {
        return categoryImage[1];
      }
    }
  }
  
  return null;
}

// Helper for exponential backoff
async function wait(attempt: number): Promise<void> {
  const delay = Math.min(RETRY_DELAY * Math.pow(2, attempt), 10000);
  const jitter = Math.random() * 1000;
  await new Promise(resolve => setTimeout(resolve, delay + jitter));
}

// Cache management
async function cleanupOldCache(userId: string): Promise<void> {
  try {
    const cacheRef = collection(db, 'users', userId, 'imageCache');
    const snapshot = await getDocs(cacheRef);
    
    const cacheEntries = snapshot.docs
      .map(doc => ({
        id: doc.id,
        timestamp: new Date(doc.data().timestamp).getTime()
      }))
      .sort((a, b) => b.timestamp - a.timestamp);
    
    if (cacheEntries.length > MAX_CACHE_SIZE) {
      const entriesToDelete = cacheEntries.slice(MAX_CACHE_SIZE);
      await Promise.all(
        entriesToDelete.map(entry => 
          runTransaction(db, async transaction => {
            const docRef = doc(cacheRef, entry.id);
            const docSnap = await transaction.get(docRef);
            if (docSnap.exists()) {
              transaction.delete(docRef);
            }
          })
        )
      );
    }
  } catch (error) {
    console.warn('Cache cleanup error:', error);
  }
}

// Cache operations
async function getCachedImage(query: string): Promise<ImageResult | null> {
  if (!auth.currentUser) return null;
  
  try {
    // Check food_images collection first
    const foodImagesRef = collection(db, 'food_images');
    const foodQuery = query(foodImagesRef, where('food_name', '==', query.toLowerCase()));
    const snapshot = await getDocs(foodQuery);
    
    if (!snapshot.empty) {
      const data = snapshot.docs[0].data();
      return {
        imageUrl: data.image_url,
        thumbnailUrl: data.thumbnail_url
      };
    }
    
    // Check user's personal cache
    const cacheRef = doc(db, 'users', auth.currentUser.uid, 'imageCache', query);
    const cacheDoc = await getDoc(cacheRef);
    
    if (cacheDoc.exists()) {
      const data = cacheDoc.data();
      if (Date.now() - new Date(data.timestamp).getTime() < CACHE_DURATION) {
        return {
          imageUrl: data.imageUrl,
          thumbnailUrl: data.thumbnailUrl
        };
      }
    }
    
    return null;
  } catch (error) {
    console.warn('Cache read error:', error);
    return null;
  }
}

async function cacheImage(query: string, imageUrl: string, thumbnailUrl: string, category?: string): Promise<void> {
  if (!auth.currentUser) return;
  
  try {
    await runTransaction(db, async transaction => {
      const cacheRef = doc(db, 'users', auth.currentUser.uid, 'imageCache', query);
      const cacheData: ImageCache = {
        imageUrl,
        thumbnailUrl,
        timestamp: new Date().toISOString(),
        category
      };
      
      transaction.set(cacheRef, cacheData);
      
      if (category) {
        const foodImagesRef = collection(db, 'food_images');
        const foodQuery = query(foodImagesRef, where('food_name', '==', query.toLowerCase()));
        const snapshot = await transaction.get(foodQuery);
        
        if (snapshot.empty) {
          const newFoodImageRef = doc(foodImagesRef);
          transaction.set(newFoodImageRef, {
            food_name: query.toLowerCase(),
            image_url: imageUrl,
            thumbnail_url: thumbnailUrl,
            category,
            created_at: new Date().toISOString()
          });
        }
      }
    });
    
    cleanupOldCache(auth.currentUser.uid).catch(console.warn);
  } catch (error) {
    console.warn('Cache write error:', error);
  }
}

// Main image fetching function
async function getImage(query: string, forceRefresh = false): Promise<ImageResult> {
  if (!query) {
    return DEFAULT_FOOD_IMAGE;
  }
  
  const normalizedQuery = query.toLowerCase().trim();
  
  // Try to find best matching curated image first
  const curatedMatch = findBestCuratedMatch(normalizedQuery);
  if (curatedMatch) {
    return curatedMatch;
  }

  // Validate query
  if (normalizedQuery.length < 2) {
    console.warn('Query too short:', query);
    return DEFAULT_FOOD_IMAGE;
  }
  
  try {
    if (!auth.currentUser) {
      console.warn('User not authenticated');
      return DEFAULT_FOOD_IMAGE;
    }

    // Check cache first if not forcing refresh
    if (!forceRefresh) {
      const cachedImage = await getCachedImage(normalizedQuery);
      if (cachedImage?.imageUrl) {
        return cachedImage;
      }
    }

    // Check curated images
    const curatedImage = CURATED_IMAGES[normalizedQuery];
    if (curatedImage) {
      return curatedImage;
    }

    // Fetch from Unsplash
    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      try {
        // Try Unsplash first
        let result;
        try {
          result = await getUnsplashImage(`${normalizedQuery} food plated dish`);
        } catch (unsplashError) {
          console.warn('Unsplash error, falling back to Pixabay:', unsplashError);
          // Try Pixabay as fallback
          result = await getPixabayImage(normalizedQuery);
        }

        await cacheImage(normalizedQuery, result.imageUrl, result.thumbnailUrl);
        return result;
      } catch (error) {
        if (attempt === MAX_RETRIES - 1) {
          throw error;
        }
        await wait(attempt);
      }
    }

    return DEFAULT_FOOD_IMAGE;
  } catch (error) {
    console.warn('Error getting image:', {
      query: normalizedQuery,
      error: error instanceof Error ? error.message : 'Unknown error',
      fallback: 'Using default food image'
    });
    return DEFAULT_FOOD_IMAGE;
  }
}

// Helper to enhance search terms
function enhanceSearchQuery(query: string): string {
  query = query.replace(/\bfood\b/g, '').trim();
  
  // Add plating context for better food presentation
  if (!query.includes('plate') && !query.includes('bowl')) {
    query += ' plate served';
  }
  
  // Add quality and lighting context
  if (!query.includes('professional') && !query.includes('restaurant')) {
    query += ' professional food photography';
  }

  // Special handling for prepared foods
  if (query.includes('cooked') || query.includes('grilled') || query.includes('fried')) {
    return `${query} restaurant style plated`;
  }
  
  // Special handling for fresh ingredients
  if (query.includes('fresh')) {
    return `${query} fresh served plate`;
  }
  
  // Special handling for fruits and vegetables
  if (query.includes('fruit') || query.includes('vegetable')) {
    return `${query} fresh plate served`;
  }
  
  return `${query} restaurant style food photography`;
}

// Export both named and default exports
export { getImage };
export default getImage;