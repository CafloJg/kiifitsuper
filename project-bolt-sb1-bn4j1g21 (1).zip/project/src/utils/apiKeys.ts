// Validate and format API key
export function getValidatedApiKey(): string {
  const key = import.meta.env.VITE_OPENAI_API_KEY?.trim();
  if (!key) {
    throw new Error('Chave da API OpenAI não encontrada.\n\nAdicione sua chave no arquivo .env como:\nVITE_OPENAI_API_KEY=sk-...\n\nObtenha uma chave em:\nhttps://platform.openai.com/account/api-keys');
  }
  
  // Basic key format validation
  if (!key.startsWith('sk-')) {
    throw new Error('Formato de chave API inválido.\n\nA chave deve começar com "sk-".\n\nVerifique se a chave está correta ou obtenha uma nova em:\nhttps://platform.openai.com/account/api-keys');
  }
  
  return key;
}

// Get API key with error handling
export async function getOpenAIKey(): Promise<string> {
  try {
    return getValidatedApiKey();
  } catch (error) {
    console.error('Error getting OpenAI API key:', error);
    throw new Error('Erro de configuração da API. Por favor, verifique sua chave da API OpenAI.');
  }
}