import { doc, updateDoc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { getOpenAIKey } from '../utils/apiKeys';
import type { UserProfile, DietPlan, ShoppingList, ShoppingItem } from '../types/user';
import getImage from './imageService';
import { calculateTargetMacros } from './dailyStats';

// Cache configuration
const PLAN_CACHE_TTL = 10 * 60 * 1000; // 10 minutes
const PROMPT_CACHE_TTL = 60 * 60 * 1000; // 1 hour

// Validation constants
const CALORIE_TOLERANCE = 100; // ±100 kcal
const MACRO_TOLERANCE = 5;    // ±5g for macros
const MIN_FOODS_PER_MEAL = 3; // Minimum foods per meal
const MAX_FOODS_PER_MEAL = 3; // Maximum foods per meal
const REQUIRED_MEAL_TIMES = ['07:00', '12:00', '16:00', '20:00'];

// Default macro ratios for different food types
const DEFAULT_MACRO_RATIOS = {
  protein: { protein: 0.8, carbs: 0.05, fat: 0.15 }, // High protein foods
  carbs: { protein: 0.1, carbs: 0.8, fat: 0.1 },    // High carb foods
  fat: { protein: 0.1, carbs: 0.1, fat: 0.8 },      // High fat foods
  vegetable: { protein: 0.2, carbs: 0.7, fat: 0.1 }, // Vegetables
  fruit: { protein: 0.05, carbs: 0.9, fat: 0.05 }    // Fruits
};

// Food type patterns for categorization
const FOOD_TYPE_PATTERNS = {
  protein: [
    'frango', 'peixe', 'carne', 'ovo', 'queijo', 'iogurte',
    'tofu', 'lentilha', 'grão', 'feijão'
  ],
  carbs: [
    'arroz', 'pão', 'batata', 'mandioca', 'aveia', 'quinoa',
    'macarrão', 'cereal'
  ],
  fat: [
    'azeite', 'óleo', 'castanha', 'amendoim', 'abacate',
    'coco', 'chia', 'linhaça'
  ],
  vegetable: [
    'alface', 'brócolis', 'couve', 'espinafre', 'cenoura',
    'abobrinha', 'berinjela', 'pepino', 'tomate'
  ],
  fruit: [
    'maçã', 'banana', 'laranja', 'morango', 'uva', 'mamão',
    'pera', 'kiwi', 'manga'
  ]
};

// Memory caches
type PlanCacheEntry = { 
  plan: DietPlan; 
  timestamp: number; 
  macros: { 
    calories: number; 
    protein: number; 
    carbs: number; 
    fat: number; 
  } 
};

const planCache = new Map<string, PlanCacheEntry>();
const promptCache = new Map<string, { prompt: string; timestamp: number }>();

// Constants for retry and rate limiting
const MAX_RETRIES = 3;
const BASE_RETRY_DELAY = 1000;
const TIMEOUT = 45000; // 45 seconds
const BACKOFF_FACTOR = 1.5;

// Helper function to parse portion strings
function parsePortionString(portion: string): { amount: number; unit: string } {
  const match = portion.match(/(\d+(?:\.\d+)?)\s*([a-zA-Z]+)/);
  if (!match) return { amount: 1, unit: portion };
  return { amount: parseFloat(match[1]), unit: match[2] };
}

// Helper function to determine food category
function getCategoryForFood(foodName: string): string {
  const categories = {
    carnes: ['frango', 'carne', 'peixe', 'atum', 'sardinha'],
    graos: ['arroz', 'feijão', 'quinoa', 'aveia'],
    vegetais: ['alface', 'tomate', 'cenoura', 'brócolis'],
    frutas: ['maçã', 'banana', 'laranja', 'morango'],
    laticinios: ['leite', 'queijo', 'iogurte', 'requeijão'],
    outros: []
  };

  const normalizedName = foodName.toLowerCase();
  for (const [category, foods] of Object.entries(categories)) {
    if (foods.some(food => normalizedName.includes(food))) {
      return category;
    }
  }
  return 'outros';
}

// Generate shopping list from meal plans
async function generateShoppingList(plans: Record<string, DietPlan>): Promise<ShoppingList> {
  const items: Record<string, ShoppingItem> = {};

  // Process each plan's meals
  Object.entries(plans).forEach(([date, plan]) => {
    plan.meals.forEach(meal => {
      meal.foods.forEach(food => {
        const { amount, unit } = parsePortionString(food.portion);
        const category = getCategoryForFood(food.name);
        const key = `${food.name}_${unit}`;

        if (items[key]) {
          // Update existing item
          const currentAmount = parseFloat(items[key].quantity);
          items[key].quantity = (currentAmount + amount).toString();
          items[key].mealIds.push(meal.id);
        } else {
          // Add new item
          items[key] = {
            id: `item_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            name: food.name,
            quantity: amount.toString(),
            unit,
            category,
            checked: false,
            mealIds: [meal.id]
          };
        }
      });
    });
  });

  return {
    id: `list_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    userId: Object.values(plans)[0].userId,
    startDate: Object.keys(plans)[0],
    endDate: Object.keys(plans)[Object.keys(plans).length - 1],
    items: Object.values(items),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
}

// Generate future meal plans
async function generateFuturePlans(
  user: UserProfile,
  basePlan: DietPlan,
  days: number = 15
): Promise<Record<string, DietPlan>> {
  const plans: Record<string, DietPlan> = {};
  const startDate = new Date();
  
  for (let i = 1; i <= days; i++) {
    const date = new Date(startDate);
    date.setDate(date.getDate() + i);
    const dateStr = date.toISOString().split('T')[0];

    // Generate variations of the base plan
    const newPlan: DietPlan = {
      ...basePlan,
      id: `plan_${dateStr}_${Math.random().toString(36).substr(2, 9)}`,
      date: dateStr,
      meals: await Promise.all(basePlan.meals.map(async meal => {
        // Vary foods while maintaining macros
        const newFoods = await Promise.all(meal.foods.map(async food => {
          // Get alternative foods with similar macros
          const alternatives = food.alternatives || [];
          if (alternatives.length > 0) {
            const randomAlt = alternatives[Math.floor(Math.random() * alternatives.length)];
            const images = await getImage(`${randomAlt.name} food plated`);
            return {
              ...randomAlt,
              id: `food_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
              imageUrl: images.imageUrl,
              thumbnailUrl: images.thumbnailUrl
            };
          }
          return food;
        }));

        return {
          ...meal,
          id: `meal_${dateStr}_${Math.random().toString(36).substr(2, 9)}`,
          foods: newFoods
        };
      }))
    };

    plans[dateStr] = newPlan;
  }

  return plans;
}

function getPlanCacheKey(user: UserProfile): string {
  return JSON.stringify({
    weight: user.weight,
    height: user.height,
    age: user.age,
    gender: user.gender,
    goals: user.goals,
    dietType: user.dietType,
    allergies: user.allergies,
    foodPreferences: user.foodPreferences
  });
}

function calculateDailyCalories(user: UserProfile): number {
  if (!user.weight || !user.height || !user.age || !user.gender || !user.goals) {
    throw new Error('Dados do usuário incompletos.');
  }

  // Mifflin-St Jeor formula with activity level and goal adjustments
  let bmr = 0;
  
  // Base Metabolic Rate calculation
  if (user.gender === 'masculino') {
    bmr = (10 * user.weight) + (6.25 * user.height) - (5 * user.age) + 5;
  } else {
    bmr = (10 * user.weight) + (6.25 * user.height) - (5 * user.age) - 161;
  }

  // Activity factor (TDEE Multiplier)
  let activityFactor = 1.2; // Sedentary (little or no exercise)
  switch (user.goals.activityLevel) {
    case 'light':
      activityFactor = 1.375; // Light exercise (1-3 days/week)
      break;
    case 'moderate':
      activityFactor = 1.55; // Moderate exercise (3-5 days/week)
      break;
    case 'active':
      activityFactor = 1.725; // Heavy exercise (6-7 days/week)
      break;
    case 'very_active':
      activityFactor = 1.9; // Very heavy exercise/physical job
      break;
  }

  // Calculate Total Daily Energy Expenditure (TDEE)
  let tdee = bmr * activityFactor;

  // Goal-specific adjustments
  switch (user.goals.type) {
    case 'loss':
      // Safe weight loss: 20% deficit for BMI > 30, 15% for BMI 25-30, 10% for BMI < 25
      const bmi = user.weight / ((user.height / 100) ** 2);
      let deficit = 0.15; // Default 15% deficit
      
      if (bmi > 30) deficit = 0.20;
      else if (bmi < 25) deficit = 0.10;
      
      tdee *= (1 - deficit);
      break;
      
    case 'gain':
      // Lean muscle gain: 10% surplus for beginners, 5% for advanced
      const isAdvanced = user.checkInStreak ? user.checkInStreak > 90 : false;
      const surplus = isAdvanced ? 0.05 : 0.10;
      tdee *= (1 + surplus);
      break;
      
    case 'maintenance':
      // No adjustment needed for maintenance
      break;
  }

  // Ensure minimum safe calories
  const minCalories = user.gender === 'masculino' ? 1500 : 1200;
  return Math.max(Math.round(tdee), minCalories);
}

function generatePrompt(user: UserProfile, calories: number, macros: { proteinTarget: number; carbsTarget: number; fatTarget: number }): string {
  const foodPreferences = user.foodPreferences || {};
  const likedFoods = Object.entries(foodPreferences)
    .filter(([_, pref]) => pref.type === 'like')
    .sort((a, b) => b[1].score - a[1].score)
    .map(([_, pref]) => `- ${pref.name} (score: ${pref.score})`)
    .join('\n');
  
  const dislikedFoods = Object.entries(foodPreferences)
    .filter(([_, pref]) => pref.type === 'dislike')
    .sort((a, b) => a[1].score - b[1].score)
    .map(([_, pref]) => `- ${pref.name} (score: ${pref.score})`)
    .join('\n');

  return `
Você é uma nutricionista profissional gerando um plano alimentar personalizado.
RETORNE APENAS O JSON SOLICITADO, SEM TEXTO ADICIONAL E SEM FORMATAÇÃO MARKDOWN.

PREFERÊNCIAS DO USUÁRIO:
Alimentos preferidos:
${likedFoods || '- Nenhum preferido'}
Alimentos não desejados:
${dislikedFoods || '- Nenhum não desejado'}
Alergias: ${user.allergies?.join(', ') || 'Nenhuma'}
Tipo de dieta: ${user.dietType}
Objetivo: ${user.goals.type}
Meta calórica: ${calories} kcal/dia
Meta de proteína: ${macros.proteinTarget}g
Meta de carboidratos: ${macros.carbsTarget}g
Meta de gorduras: ${macros.fatTarget}g

REGRAS DE REFEIÇÕES:
Café da Manhã (07:00):
- PERMITIDO: ovos, pães integrais, aveia, iogurte, frutas, café, leite, queijos magros
- PROIBIDO: doces, sobremesas, alimentos muito gordurosos ou processados

Almoço (12:00):
- PERMITIDO: carnes magras, arroz, feijão, legumes, verduras
- EQUILIBRAR: proteínas, carboidratos e vegetais no prato

Lanche (16:00):
- PERMITIDO: frutas, iogurte, oleaginosas, pães integrais
- EVITAR: alimentos muito calóricos ou processados

Jantar (20:00):
- SIMILAR ao almoço, mas em porções menores
- EVITAR carboidratos refinados

HORÁRIOS OBRIGATÓRIOS:
- Café da manhã: 07:00
- Almoço: 12:00
- Lanche: 16:00
- Jantar: 20:00

IMPORTANTE:
- Use APENAS alimentos comuns e acessíveis no Brasil
- NUNCA repita o mesmo alimento principal em refeições diferentes
- PRIORIZE os alimentos preferidos, iniciando pelos de maior score
- EVITE totalmente os alimentos não desejados e aqueles com score negativo
- Ao substituir um alimento não desejado, use alternativas similares em nutrientes
- Priorize SEMPRE alimentos naturais e frescos
- Controle o sódio diário (máx 2000mg) e use temperos naturais
- Varie os tipos de proteína, carboidrato, vegetais e frutas
- Utilize medidas caseiras comuns (colher, xícara, unidade)

REGRAS ADICIONAIS:
1. Café da manhã deve ser nutritivo e apropriado para o início do dia
2. Evite doces e sobremesas nas refeições principais
3. Priorize alimentos integrais sobre refinados
4. Inclua proteína em todas as refeições
5. Adicione vegetais no almoço e jantar

RETORNE O JSON NO SEGUINTE FORMATO:
{
  "meals": [
    {
      "name": "Café da Manhã",
      "time": "07:00",
      "calories": number,
      "protein": number,
      "carbs": number,
      "fat": number,
      "foods": [
        {
          "name": "Nome do Alimento",
          "portion": "Porção em medida caseira",
          "calories": number,
          "protein": number,
          "carbs": number,
          "fat": number
        }
      ]
    },
    {
      "name": "Almoço",
      "time": "12:00",
      ...
    },
    {
      "name": "Lanche",
      "time": "16:00",
      ...
    },
    {
      "name": "Jantar", 
      "time": "20:00",
      ...
    }
  ]
}`;
}

function validateMealPlan(plan: any): void {
  if (!plan || typeof plan !== 'object') {
    throw new Error('Plano inválido. Por favor, tente novamente.');
  }

  if (!Array.isArray(plan.meals) || plan.meals.length !== REQUIRED_MEAL_TIMES.length) {
    throw new Error('Número de refeições inválido. Por favor, tente novamente.');
  }

  plan.meals.forEach((meal: any, index: number) => {
    if (!meal.name || !Array.isArray(meal.foods) || meal.foods.length === 0) {
      throw new Error(`Refeição ${meal.name || index + 1} inválida. Por favor, tente novamente.`);
    }

    if (!meal.time || !REQUIRED_MEAL_TIMES.includes(meal.time)) {
      throw new Error(`Horário inválido para ${meal.name}. Por favor, tente novamente.`);
    }

    if (meal.foods.length < MIN_FOODS_PER_MEAL || meal.foods.length > MAX_FOODS_PER_MEAL) {
      throw new Error(`Número de alimentos inválido em ${meal.name}. Por favor, tente novamente.`);
    }

    meal.foods.forEach((food: any, foodIndex: number) => {
      // Validate required fields
      if (!food.name || typeof food.name !== 'string' || food.name.trim().length === 0) {
        throw new Error(`Nome do alimento inválido em ${meal.name}. Por favor, tente novamente.`);
      }
      
      if (!food.portion || typeof food.portion !== 'string' || food.portion.trim().length === 0) {
        throw new Error(`Porção inválida para ${food.name}. Por favor, tente novamente.`);
      }
      
      // Validate numeric fields
      const numericFields = ['calories', 'protein', 'carbs', 'fat'];
      for (const field of numericFields) {
        const value = food[field];
        if (typeof value !== 'number' || isNaN(value) || value < 0) {
          throw new Error(`Valor inválido de ${field} para ${food.name}. Por favor, tente novamente.`);
        }
      }
      
      // Ensure reasonable calorie range
      if (food.calories < 1 || food.calories > 2000) {
        throw new Error(`Calorias inválidas para ${food.name}. Por favor, tente novamente.`);
      }
      
      // Special handling for low-calorie vegetables and fruits
      const isLowCalorieFood = food.calories < 100 && (
        food.name.toLowerCase().includes('abobrinha') ||
        food.name.toLowerCase().includes('brócolis') ||
        food.name.toLowerCase().includes('alface') ||
        food.name.toLowerCase().includes('couve') ||
        food.name.toLowerCase().includes('espinafre') ||
        food.name.toLowerCase().includes('tomate') ||
        food.name.toLowerCase().includes('pepino') ||
        food.name.toLowerCase().includes('berinjela') ||
        food.name.toLowerCase().includes('repolho') ||
        food.name.toLowerCase().includes('agrião') ||
        food.name.toLowerCase().includes('salada') ||
        food.name.toLowerCase().includes('folhas') ||
        food.name.toLowerCase().includes('rúcula') ||
        food.name.toLowerCase().includes('acelga') ||
        food.name.toLowerCase().includes('chicória')
      );
      
      // Calculate macro calories
      const calculatedCalories = (food.protein * 4) + (food.carbs * 4) + (food.fat * 9);
      const caloriesDiff = Math.abs(calculatedCalories - food.calories);
      const allowedMargin = isLowCalorieFood ? 0.5 : 0.15; // 50% margin for low cal, 15% for others
      
      // Check if calories are within allowed margin
      if (caloriesDiff > food.calories * allowedMargin) {
        // Get food type for default ratios
        const foodType = Object.entries(FOOD_TYPE_PATTERNS).find(([_, patterns]) =>
          patterns.some(pattern => food.name.toLowerCase().includes(pattern))
        )?.[0] || 'protein';

        // Apply default ratios based on food type
        const ratios = DEFAULT_MACRO_RATIOS[foodType as keyof typeof DEFAULT_MACRO_RATIOS];
        const totalCalories = food.calories;

        // Adjust macros based on ratios
        food.protein = Math.round((totalCalories * ratios.protein) / 4);
        food.carbs = Math.round((totalCalories * ratios.carbs) / 4);
        food.fat = Math.round((totalCalories * ratios.fat) / 9);

        console.warn(`Adjusted macros for ${food.name} using ${foodType} ratios`);
      }
      
      // Ensure minimum macro values for low calorie foods
      if (isLowCalorieFood) {
        const minProtein = 0.5;
        const minCarbs = 1.0;
        const minFat = 0.1;
        
        if (food.protein < minProtein || food.carbs < minCarbs || food.fat < minFat) {
          // Adjust to minimum values
          food.protein = Math.max(food.protein, minProtein);
          food.carbs = Math.max(food.carbs, minCarbs);
          food.fat = Math.max(food.fat, minFat);
          console.warn(`Adjusted minimum macros for low calorie food: ${food.name}`);
        }
      }
    });
    
    // Validate meal totals
    const mealCalories = meal.foods.reduce((sum: number, food: any) => sum + food.calories, 0);
    const minMealCalories = meal.name.toLowerCase().includes('lanche') ? 150 : 300;
    const maxMealCalories = meal.name.toLowerCase().includes('lanche') ? 400 : 800;
    
    if (mealCalories < minMealCalories || mealCalories > maxMealCalories) {
      console.warn(`Adjusting calories for ${meal.name} (${mealCalories} kcal)`);
      
      // Scale all foods proportionally
      const scale = mealCalories < minMealCalories 
        ? minMealCalories / mealCalories
        : maxMealCalories / mealCalories;
        
      meal.foods.forEach((food: any) => {
        food.calories = Math.round(food.calories * scale);
        food.protein = Math.round(food.protein * scale);
        food.carbs = Math.round(food.carbs * scale);
        food.fat = Math.round(food.fat * scale);
      });
    }
  });
  
  // Validate total daily calories
  const totalCalories = plan.meals.reduce((sum: number, meal: any) => 
    sum + meal.foods.reduce((mealSum: number, food: any) => mealSum + food.calories, 0), 0
  );
  
  // Log validation results
  console.info('Diet plan validation:', {
    totalCalories,
    mealsCount: plan.meals.length,
    foodsPerMeal: plan.meals.map(m => m.foods.length),
    mealCalories: plan.meals.map(m => ({
      name: m.name,
      calories: m.foods.reduce((sum: number, f: any) => sum + f.calories, 0)
    }))
  });
}

async function generateMeals(user: UserProfile): Promise<DietPlan> {
  if (!user.uid) {
    throw new Error('Faça login para gerar um plano alimentar.');
  }

  if (!user.weight || !user.height || !user.age || !user.gender) {
    throw new Error('Complete seu perfil antes de gerar um plano alimentar.');
  }

  if (!user.goals?.type) {
    throw new Error('Configure suas metas antes de gerar um plano alimentar.');
  }

  if (!user.dietType) {
    throw new Error('Selecione um tipo de dieta no seu perfil.');
  }

  const calories = calculateDailyCalories(user);
  const macros = calculateTargetMacros(calories, user.goals.type);
  const cacheKey = getPlanCacheKey(user);

  // Check cache
  const cached = planCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < PLAN_CACHE_TTL) {
    return cached.plan;
  }

  let retryCount = 0;

  while (retryCount < MAX_RETRIES) {
    const controller = new AbortController();
    let timeoutId: NodeJS.Timeout | undefined;
    
    try {
      // Create timeout promise
      const timeoutPromise = new Promise((_, reject) => {
        timeoutId = setTimeout(() => {
          controller.abort();
          reject(new Error('O serviço está demorando para responder. Tente novamente.'));
        }, TIMEOUT);
      });

      const prompt = generatePrompt(user, calories, macros);
      
      // Get validated API key
      const apiKey = await getOpenAIKey();
      
      // Prepare fetch options
      const fetchPromise = fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Accept-Encoding': 'gzip'
        },
        signal: controller.signal,
        keepalive: true,
        body: JSON.stringify({
          model: 'gpt-3.5-turbo-0125',
          messages: [
            {
              role: 'system', 
              content: `Você é uma nutricionista profissional gerando planos alimentares. RETORNE APENAS JSON VÁLIDO.

REGRAS CRÍTICAS:
1. Retorne APENAS JSON válido, sem texto adicional
2. Todos os valores numéricos devem ser inteiros positivos
3. Calorias por alimento: mínimo 50, máximo 800
4. Calorias por refeição: mínimo 200, máximo 1000
5. Macros devem somar corretamente:
   - Proteína: 4 cal/g
   - Carboidrato: 4 cal/g
   - Gordura: 9 cal/g
6. Cada refeição DEVE ter exatamente 3 alimentos
7. Use apenas alimentos comuns no Brasil
8. PROIBIDO alimentos processados
9. Inclua proteína em todas as refeições
10. Valide todos os números antes de retornar
11. Use APENAS estas medidas caseiras:
    - Colher (sopa/chá/café)
    - Xícara
    - Unidade
    - Fatia
    - Grama (g)
    - Mililitro (ml)
12. SEMPRE inclua estas informações para cada alimento:
    - Nome em português
    - Porção em medida caseira
    - Calorias (entre 50-800)
    - Proteína (g)
    - Carboidrato (g)
    - Gordura (g)`
            },
            { role: 'user', content: prompt }
          ],
          temperature: 0.2,
          max_tokens: 1000,
          presence_penalty: 0.0,
          frequency_penalty: 0.0,
          top_p: 1
        })
      });

      // Race between fetch and timeout
      const response = await Promise.race([fetchPromise, timeoutPromise]) as Response;
      
      // Clear timeout if fetch wins
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = undefined;
      }

      if (!response.ok) {
        let errorMessage = 'Erro desconhecido';
        
        // Handle API key errors first
        if (response.status === 401) {
          throw new Error('Chave da API OpenAI inválida. Verifique se a chave está correta no arquivo .env');
        }
        if (response.status === 403) {
          throw new Error('Acesso negado ao modelo GPT-4. Verifique suas permissões.');
        }
        
        // Handle rate limits
        if (response.status === 429) {
          const retryAfter = parseInt(response.headers.get('Retry-After') || '60');
          if (retryCount < MAX_RETRIES - 1) {
            console.warn(`Rate limit hit (attempt ${retryCount + 1}/${MAX_RETRIES}), waiting ${retryAfter}s...`);
            await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
            retryCount++;
            continue;
          }
          throw new Error('Muitas solicitações. Por favor, aguarde alguns minutos e tente novamente.');
        }
        
        // Parse error response
        try {
          const error = await response.json();
          errorMessage = error.error?.message || `Erro ${response.status}: ${response.statusText}`;
          
          console.error('OpenAI API error:', {
            status: response.status,
            error: error.error,
            message: errorMessage
          });
        } catch (jsonError) {
          console.error('Failed to parse error response:', jsonError);
          errorMessage = `Erro ${response.status}: ${response.statusText}`;
        }
        
        // Check for API key related errors in message
        const msg = errorMessage.toLowerCase();
        if (msg.includes('api key') || msg.includes('invalid') || msg.includes('incorrect')) {
          throw new Error('Chave da API OpenAI inválida. Verifique se a chave está correta no arquivo .env');
        }
        
        // Other errors should retry
        if (retryCount < MAX_RETRIES - 1) {
          retryCount++;
          const jitter = Math.random() * 500;
          const delay = BASE_RETRY_DELAY * Math.pow(2, retryCount) + jitter;
          console.warn(`API error (attempt ${retryCount}/${MAX_RETRIES}), retrying in ${delay.toFixed(0)}ms...`);
          await new Promise(resolve => setTimeout(resolve, delay));
          continue;
        }
        
        throw new Error('Erro ao gerar plano alimentar. Tente novamente.');
      }

      let data;
      try {
        data = await response.json();
      } catch (parseError) {
        console.error('Failed to parse API response:', jsonError);
        throw new Error('Erro ao processar resposta do serviço. Por favor, tente novamente.');
      }

      if (!data.choices?.[0]?.message?.content) {
        console.error('Invalid API response:', data);
        throw new Error('Resposta inválida do serviço. Por favor, tente novamente.');
      }
      
      let content = data.choices[0].message.content.trim();
      
      // Clean up the content and extract JSON
      let cleanContent = content;
      
      // Clean up JSON content
      cleanContent = cleanContent
        .replace(/```(?:json)?|```/g, '')
        .replace(/[\n\r\t]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
      
      // Try to parse the cleaned content
      let plan;
      try {
        // First try direct parse
        try {
          plan = JSON.parse(cleanContent);
        } catch (directError) {
          // If direct parse fails, try to extract JSON
          const jsonMatch = cleanContent.match(/\{[\s\S]*\}/);
          if (!jsonMatch) {
            throw new Error('Erro ao processar resposta do serviço. Por favor, tente novamente.');
          }
          plan = JSON.parse(jsonMatch[0]);
        }

        // Validate basic structure before detailed validation
        if (!plan?.meals?.length) {
          throw new Error('Erro ao gerar plano alimentar. Tente novamente.');
        }

        // Validate meal count
        if (plan.meals.length !== 4) {
          throw new Error('Erro ao gerar plano alimentar. Tente novamente.');
        }

        // Validate each meal has exactly 3 foods
        for (const meal of plan.meals) {
          if (!meal.foods || meal.foods.length !== 3) {
            throw new Error('Erro ao gerar plano alimentar. Tente novamente.');
          }
        }

        // Validate plan before processing
        validateMealPlan(plan);

        // Add images to meals and foods
        const mealsWithImages = await Promise.all(
          plan.meals.map(async (meal: any, index: number) => {
            let mealImages;
            try {
              mealImages = await getImage(`${meal.name} gourmet plated dish`);
            } catch (imageError) {
              console.warn('Error loading meal image:', imageError);
              mealImages = {
                imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=2000',
                thumbnailUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=400'
              };
            }

            const foodsWithImages = await Promise.all(
              meal.foods.map(async (food: any) => {
                let foodImages;
                try {
                  foodImages = await getImage(`${food.name} gourmet plated dish`);
                } catch (imageError) {
                  console.warn('Error loading food image:', imageError);
                  foodImages = {
                    imageUrl: food.imageUrl || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=2000',
                    thumbnailUrl: food.thumbnailUrl || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=400'
                  };
                }

                return {
                  ...food,
                  id: `food_${index}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                  imageUrl: foodImages.imageUrl,
                  thumbnailUrl: foodImages.thumbnailUrl
                };
              })
            );

            return {
              ...meal,
              id: `meal_${index}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
              imageUrl: mealImages.imageUrl,
              thumbnailUrl: mealImages.thumbnailUrl,
              foods: foodsWithImages
            };
          })
        );

        const finalPlan: DietPlan = {
          id: `plan_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          userId: user.uid,
          nextPlans: {},
          createdAt: new Date().toISOString(),
          totalCalories: calories,
          proteinTarget: macros.proteinTarget,
          carbsTarget: macros.carbsTarget,
          fatTarget: macros.fatTarget,
          meals: mealsWithImages,
          dailyStats: {
            caloriesConsumed: 0,
            proteinConsumed: 0,
            carbsConsumed: 0,
            fatConsumed: 0,
            waterIntake: 0,
            completedMeals: { [new Date().toISOString().split('T')[0]]: [] },
            lastUpdated: new Date().toISOString()
          }
        };

        // Update user document
        try {
          const userRef = doc(db, 'users', user.uid);
          const userDoc = await getDoc(userRef);
          
          if (!userDoc.exists()) {
            throw new Error('Usuário não encontrado');
          }
          
          // Generate future plans
          const futurePlans = await generateFuturePlans(user, finalPlan);
          finalPlan.nextPlans = futurePlans;
          
          // Generate shopping list
          const shoppingList = await generateShoppingList({
            [new Date().toISOString().split('T')[0]]: finalPlan,
            ...futurePlans
          });
          
          await updateDoc(userRef, {
            currentDietPlan: finalPlan,
            lastPlanGenerated: new Date().toISOString(),
            shoppingList,
            updatedAt: new Date().toISOString()
          });
        } catch (firestoreError) {
          console.error('Error updating user document:', firestoreError);
          // Only throw if it's a critical error
          if (firestoreError instanceof Error && 
              firestoreError.message.includes('not found')) {
            throw new Error('Erro ao salvar plano. Por favor, faça login novamente.');
          }
        }

        // Cache the plan
        planCache.set(cacheKey, {
          plan: finalPlan,
          timestamp: Date.now(),
          macros: {
            calories,
            protein: macros.proteinTarget,
            carbs: macros.carbsTarget,
            fat: macros.fatTarget
          }
        });

        return finalPlan;

    } catch (error) {
      // Always clear timeout
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = undefined;
      }

      console.error('Erro na geração do plano:', {
        attempt: retryCount + 1,
        error: error instanceof Error ? error.message : 'Erro desconhecido'
      });

      // Check if this is a fatal error that shouldn't be retried
      if (error instanceof Error) {
        const errorMessage = error.message.toLowerCase();
          
        // Handle network errors
        const isNetworkError = error.name === 'TypeError' && error.message === 'Failed to fetch';
        const isTimeout = error.name === 'AbortError';
        const isConnectionError = errorMessage.includes('network') ||
                                errorMessage.includes('connection') ||
                                errorMessage.includes('internet') ||
                                errorMessage.includes('demorando');

        if (isNetworkError || isTimeout || isConnectionError) {
          if (retryCount < MAX_RETRIES - 1) {
            retryCount++;
            const delay = BASE_RETRY_DELAY * Math.pow(BACKOFF_FACTOR, retryCount);
            console.warn(`${isTimeout ? 'Timeout' : 'Network'} error (attempt ${retryCount + 1}/${MAX_RETRIES}), retrying in ${delay}ms...`);
            await new Promise(resolve => setTimeout(resolve, delay));
            continue;
          }
          throw new Error(isTimeout 
            ? 'O serviço está sobrecarregado. Por favor, tente novamente em alguns minutos.'
            : 'Erro de conexão. Verifique sua internet e tente novamente.');
        }

        // JSON parsing errors should retry
        if (errorMessage.includes('json') && retryCount < MAX_RETRIES - 1) {
          retryCount++;
          const delay = BASE_RETRY_DELAY * Math.pow(BACKOFF_FACTOR, retryCount);
          console.warn(`JSON parsing error (attempt ${retryCount}/${MAX_RETRIES}), retrying in ${delay}ms...`);
          await new Promise(resolve => setTimeout(resolve, delay));
          continue;
        }
          
        // API key errors are fatal - no need to retry
        if (errorMessage.includes('api key') || errorMessage.includes('chave da api')) {
          throw error;
        }
        // Rate limit errors are also fatal (already handled with Retry-After header)
        if (errorMessage.includes('rate limit') || errorMessage.includes('muitas solicitações')) {
          throw error;
        }
      }

      retryCount++;
      if (retryCount >= MAX_RETRIES) {
        throw new Error('Não foi possível gerar um plano alimentar. Por favor, tente novamente em alguns minutos.');
      }

      const jitter = Math.random() * 1000;
      const delay = BASE_RETRY_DELAY * Math.pow(BACKOFF_FACTOR, retryCount) + jitter;
      console.warn(`Retrying in ${delay.toFixed(0)}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
      continue;
    } finally {
      // Always clear timeout if it exists
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = undefined;
      }
    }
  }

  throw new Error('Não foi possível gerar um plano alimentar adequado. Por favor, tente novamente.');
}

export { generateMeals, generateFuturePlans, generateShoppingList }