import { UserProfile } from '../types/user';
import { getPlanByTier, checkPlanLimits } from '../lib/plans';

export function checkBasicPlanLimits(user: UserProfile): {
  canGenerateNewPlan: boolean;
  canUpdateGoals: boolean;
  message?: string;
} {
  const plan = getPlanByTier(user.subscriptionTier);
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  // Verificar limite de planos mensais
  const monthlyPlanCount = user.monthlyPlanCount || 0;
  const canGenerateNewPlan = checkPlanLimits(
    user.subscriptionTier,
    'monthlyDietPlans',
    monthlyPlanCount
  );

  // Verificar limite de metas personalizadas
  const customGoalsCount = user.customGoals?.length || 0;
  const canUpdateGoals = checkPlanLimits(
    user.subscriptionTier,
    'customGoals',
    customGoalsCount
  );

  if (!canGenerateNewPlan && !canUpdateGoals) {
    return {
      canGenerateNewPlan: false,
      canUpdateGoals: false,
      message: `Você atingiu o limite do plano ${plan.name}. Faça upgrade para mais recursos!`
    };
  }

  return {
    canGenerateNewPlan,
    canUpdateGoals,
    message: canGenerateNewPlan ? undefined : 'Limite de planos mensais atingido'
  };
}

export function checkPremiumPlanLimits(user: UserProfile): {
  canScheduleSession: boolean;
  message?: string;
} {
  const plan = getPlanByTier(user.subscriptionTier);
  
  // Verificar limite de sessões com nutricionista
  const weeklySessionCount = user.weeklySessionCount || 0;
  const canScheduleSession = checkPlanLimits(
    user.subscriptionTier,
    'nutritionistSessions',
    weeklySessionCount
  );

  if (!canScheduleSession) {
    return {
      canScheduleSession: false,
      message: `Você atingiu o limite de consultas do plano ${plan.name}`
    };
  }

  return {
    canScheduleSession: true
  };
}

export function getSupportPriority(user: UserProfile): string {
  const plan = getPlanByTier(user.subscriptionTier);
  return plan.limits.supportPriority;
}

export function getAvailableFeatures(user: UserProfile): string[] {
  const plan = getPlanByTier(user.subscriptionTier);
  return plan.features
    .filter(feature => feature.included)
    .map(feature => feature.name);
}