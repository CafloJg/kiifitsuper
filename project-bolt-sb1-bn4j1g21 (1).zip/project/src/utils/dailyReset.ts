import { doc, getDoc, updateDoc } from 'firebase/firestore'; 
import { db, auth } from '../lib/firebase';
import type { UserProfile } from '../types/user';

interface DailyStats {
  caloriesConsumed: number;
  proteinConsumed: number;
  carbsConsumed: number;
  fatConsumed: number;
  waterIntake: number;
  completedMeals: {
    [date: string]: string[];
  };
  lastUpdated: string;
}

async function archiveCurrentPlan(userId: string, currentPlan: UserProfile['currentDietPlan']) {
  try {
    if (!currentPlan) return;
    const userRef = doc(db, 'users', userId);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      throw new Error('User document not found');
    }

    const userData = userDoc.data() as UserProfile;
    const today = new Date().toISOString().split('T')[0];

    // Keep only last 120 days
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - 120);
    
    const existingPlans = userData.dietHistory?.plans || [];
    const filteredPlans = existingPlans
      .filter(plan => new Date(plan.date || plan.createdAt) > cutoffDate)
      .sort((a, b) => 
        new Date(b.date || b.createdAt).getTime() - 
        new Date(a.date || a.createdAt).getTime()
      );

    // Update with new history
    await updateDoc(userRef, {
      'dietHistory': {
        plans: [...filteredPlans, { ...currentPlan, date: today }],
        lastUpdated: new Date().toISOString()
      },
      'dietHistory.lastUpdated': new Date().toISOString()
    });
  } catch (error) {
    console.error('Error archiving current plan:', error);
    throw error;
  }
}

export async function resetDailyStats(userId?: string) {
  if (!userId && !auth.currentUser) {
    console.warn('No authenticated user');
    return;
  }

  const uid = userId || auth.currentUser?.uid;
  if (!uid) return;

  try {
    const userRef = doc(db, 'users', uid);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      throw new Error('User document not found');
    }
    
    const userData = userDoc.data() as UserProfile;
    if (!userData) {
      throw new Error('Invalid user data');
    }

    const today = new Date().toISOString().split('T')[0];
    
    // Check if already reset today
    const lastReset = userData.lastDietReset ? new Date(userData.lastDietReset) : null;
    const now = new Date();
    if (lastReset && 
        lastReset.getDate() === now.getDate() &&
        lastReset.getMonth() === now.getMonth() &&
        lastReset.getFullYear() === now.getFullYear()) {
      console.log('Already reset today');
      return;
    }

    // Archive current plan before resetting
    await archiveCurrentPlan(uid, userData.currentDietPlan);

    // Reset daily stats
    const resetStats: DailyStats = {
      waterIntake: 0,
      caloriesConsumed: 0,
      proteinConsumed: 0,
      carbsConsumed: 0,
      fatConsumed: 0,
      completedMeals: {
        [today]: []
      },
      lastUpdated: new Date().toISOString()
    };

    // Update user document with reset stats
    await updateDoc(userRef, {
      dailyStats: {
        ...resetStats,
        lastUpdated: now.toISOString()
      },
      'currentDietPlan.dailyStats': {
        ...resetStats,
        lastUpdated: now.toISOString()
      },
      lastDietReset: now.toISOString()
    });

    console.log('Daily stats reset successfully');
  } catch (error) {
    console.error('Error resetting daily stats:', error);
    throw new Error('Failed to reset daily stats. Please try again.');
  }
}