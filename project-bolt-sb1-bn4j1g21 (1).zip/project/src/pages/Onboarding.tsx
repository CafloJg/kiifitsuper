import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Camera, Upload } from 'lucide-react';
import { auth, db, storage } from '../lib/firebase';
import { doc, updateDoc, getDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import type { UserProfile, OnboardingData, DietType, Gender } from '../types/user';
import Slider from '../components/Slider';

const DIET_OPTIONS: { value: DietType; label: string }[] = [
  { value: 'omnivoro', label: 'Onívoro' },
  { value: 'vegetariano', label: 'Vegetariano' },
  { value: 'vegano', label: 'Vegano' },
  { value: 'low-carb', label: 'Low Carb' },
  { value: 'cetogenica', label: 'Cetogênica' },
  { value: 'mediterranea', label: 'Mediterrânea' }
];

const COMMON_ALLERGIES = [
  'Leite',
  'Ovo',
  'Amendoim',
  'Soja',
  'Trigo',
  'Peixe',
  'Frutos do Mar',
  'Nozes'
];

const DEFAULT_FORM_DATA: Required<Omit<UserProfile, 'uid' | 'email' | 'subscriptionTier' | 'stripeCustomerId' | 'subscriptionId' | 'subscriptionStatus' | 'createdAt' | 'completedOnboarding'>> = {
  name: '',
  age: 0,
  gender: 'feminino',
  height: 0,
  weight: 0,
  photoURL: '',
  dietType: 'omnivoro',
  allergies: [],
  dislikedIngredients: []
};

const sanitizeDataForFirestore = (data: Partial<UserProfile>): Partial<UserProfile> => {
  const sanitized: Partial<UserProfile> = {};

  if (data.name) sanitized.name = String(data.name);
  if (data.age !== undefined) sanitized.age = Number(data.age);
  if (data.gender) sanitized.gender = data.gender;
  if (data.height !== undefined) sanitized.height = Number(data.height);
  if (data.weight !== undefined) sanitized.weight = Number(data.weight);
  if (data.photoURL) sanitized.photoURL = String(data.photoURL);
  if (data.dietType) sanitized.dietType = data.dietType;
  if (Array.isArray(data.allergies)) sanitized.allergies = data.allergies;
  if (Array.isArray(data.dislikedIngredients)) sanitized.dislikedIngredients = data.dislikedIngredients;

  return sanitized;
};

function Onboarding() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [data, setData] = useState<OnboardingData>({
    step: 1,
    totalSteps: 4,
    formData: DEFAULT_FORM_DATA
  });
  const [uploadError, setUploadError] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [newIngredient, setNewIngredient] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const loadOnboardingProgress = async () => {
      if (!auth.currentUser) {
        navigate('/login');
        return;
      }

      try {
        const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
        if (userDoc.exists()) {
          const userData = userDoc.data();
          if (userData && !userData.completedOnboarding) {
            // Ensure all required fields have default values
            const mergedData = {
              ...DEFAULT_FORM_DATA,
              ...userData,
              // Ensure numeric fields are properly initialized
              age: userData.age ?? DEFAULT_FORM_DATA.age,
              height: userData.height ?? DEFAULT_FORM_DATA.height,
              weight: userData.weight ?? DEFAULT_FORM_DATA.weight,
              // Ensure arrays are properly initialized
              allergies: userData.allergies ?? DEFAULT_FORM_DATA.allergies,
              dislikedIngredients: userData.dislikedIngredients ?? DEFAULT_FORM_DATA.dislikedIngredients
            };
            
            setData(prev => ({
              ...prev,
              formData: mergedData
            }));
          }
        }
      } catch (error) {
        console.error('Error loading onboarding progress:', error);
        setError('Erro ao carregar dados. Por favor, tente novamente.');
      } finally {
        setIsLoading(false);
      }
    };

    loadOnboardingProgress();
  }, [navigate]);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !auth.currentUser) return;

    setIsUploading(true);
    setUploadError('');

    try {
      if (file.size > 5 * 1024 * 1024) {
        throw new Error('A foto deve ter no máximo 5MB');
      }

      if (!file.type.startsWith('image/')) {
        throw new Error('O arquivo deve ser uma imagem');
      }

      const storageRef = ref(storage, `profile-photos/${auth.currentUser.uid}`);
      await uploadBytes(storageRef, file);
      const photoURL = await getDownloadURL(storageRef);

      setData(prev => ({
        ...prev,
        formData: { ...prev.formData, photoURL }
      }));

      const userRef = doc(db, 'users', auth.currentUser.uid);
      await updateDoc(userRef, { photoURL });
    } catch (error) {
      console.error('Erro ao fazer upload da foto:', error);
      setUploadError(
        error instanceof Error 
          ? error.message 
          : 'Erro ao fazer upload da foto. Tente novamente.'
      );
    } finally {
      setIsUploading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    
    setData(prev => ({
      ...prev,
      formData: {
        ...prev.formData,
        [name]: type === 'number' ? Number(value) || 0 : value
      }
    }));
  };

  const handleGenderSelect = (gender: Gender) => {
    setData(prev => ({
      ...prev,
      formData: { ...prev.formData, gender }
    }));
  };

  const handleDietSelect = (dietType: DietType) => {
    setData(prev => ({
      ...prev,
      formData: { ...prev.formData, dietType }
    }));
  };

  const handleAllergyToggle = (allergy: string) => {
    setData(prev => {
      const currentAllergies = prev.formData.allergies || [];
      const newAllergies = currentAllergies.includes(allergy)
        ? currentAllergies.filter(a => a !== allergy)
        : [...currentAllergies, allergy];

      return {
        ...prev,
        formData: { ...prev.formData, allergies: newAllergies }
      };
    });
  };

  const handleDislikedIngredient = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const value = newIngredient.trim();

      if (value) {
        setData(prev => {
          const currentIngredients = prev.formData.dislikedIngredients || [];
          return {
            ...prev,
            formData: {
              ...prev.formData,
              dislikedIngredients: [...currentIngredients, value]
            }
          };
        });
        setNewIngredient('');
      }
    }
  };

  const removeDislikedIngredient = (ingredient: string) => {
    setData(prev => ({
      ...prev,
      formData: {
        ...prev.formData,
        dislikedIngredients: (prev.formData.dislikedIngredients || []).filter(
          i => i !== ingredient
        )
      }
    }));
  };

  const saveProgress = async () => {
    if (!auth.currentUser) return;
    setError('');

    try {
      const sanitizedData = sanitizeDataForFirestore(data.formData);
      const userRef = doc(db, 'users', auth.currentUser.uid);
      await updateDoc(userRef, sanitizedData);
    } catch (error) {
      console.error('Error saving progress:', error);
      setError('Erro ao salvar progresso. Por favor, tente novamente.');
      throw error;
    }
  };

  const handleNext = async () => {
    try {
      await saveProgress();
      if (data.step < data.totalSteps) {
        setData(prev => ({ ...prev, step: prev.step + 1 }));
      } else {
        handleSubmit();
      }
    } catch (error) {
      // Error already handled in saveProgress
      return;
    }
  };

  const handleBack = () => {
    if (data.step > 1) {
      setData(prev => ({ ...prev, step: prev.step - 1 }));
    }
  };

  const handleSubmit = async () => {
    if (!auth.currentUser) {
      navigate('/login');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const sanitizedData = sanitizeDataForFirestore(data.formData);
      const userRef = doc(db, 'users', auth.currentUser.uid);
      await updateDoc(userRef, {
        ...sanitizedData,
        completedOnboarding: true
      });

      navigate('/dashboard');
    } catch (error) {
      console.error('Erro ao salvar dados:', error);
      setError('Erro ao salvar dados. Por favor, tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  const renderStep = () => {
    switch (data.step) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="w-24 h-24 bg-primary-100 rounded-full mx-auto mb-4 flex items-center justify-center relative">
                {data.formData.photoURL ? (
                  <img
                    src={data.formData.photoURL}
                    alt="Foto de perfil"
                    className="w-full h-full object-cover rounded-full"
                  />
                ) : (
                  <Camera size={32} className="text-primary-500" />
                )}
                {isUploading && (
                  <div className="absolute inset-0 bg-black bg-opacity-50 rounded-full flex items-center justify-center">
                    <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
                  </div>
                )}
              </div>
              <input
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
                id="photo-upload"
                disabled={isUploading}
              />
              <label
                htmlFor="photo-upload"
                className={`inline-flex items-center gap-2 ${
                  isUploading 
                    ? 'text-gray-400 cursor-not-allowed' 
                    : 'text-primary-500 cursor-pointer hover:text-primary-600'
                }`}
              >
                <Upload size={20} />
                <span>{isUploading ? 'Enviando...' : 'Adicionar foto'}</span>
              </label>
              {uploadError && (
                <p className="text-red-500 text-sm mt-2">{uploadError}</p>
              )}
            </div>

            <div className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Nome
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={data.formData.name}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                  required
                />
              </div>

              <div>
                <label htmlFor="age" className="block text-sm font-medium text-gray-700 mb-1">
                  Idade
                </label>
                <input
                  type="number"
                  id="age"
                  name="age"
                  value={data.formData.age}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Gênero
                </label>
                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => handleGenderSelect('feminino')}
                    className={`flex-1 py-3 px-4 rounded-lg border ${
                      data.formData.gender === 'feminino'
                        ? 'bg-primary-500 text-white border-primary-500'
                        : 'border-gray-300 text-gray-700 hover:border-primary-500'
                    }`}
                  >
                    Feminino
                  </button>
                  <button
                    type="button"
                    onClick={() => handleGenderSelect('masculino')}
                    className={`flex-1 py-3 px-4 rounded-lg border ${
                      data.formData.gender === 'masculino'
                        ? 'bg-primary-500 text-white border-primary-500'
                        : 'border-gray-300 text-gray-700 hover:border-primary-500'
                    }`}
                  >
                    Masculino
                  </button>
                  <button
                    type="button"
                    onClick={() => handleGenderSelect('nao-binario')}
                    className={`flex-1 py-3 px-4 rounded-lg border ${
                      data.formData.gender === 'nao-binario'
                        ? 'bg-primary-500 text-white border-primary-500'
                        : 'border-gray-300 text-gray-700 hover:border-primary-500'
                    }`}
                  >
                    Não Binário
                  </button>
                </div>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-8">
            <Slider
              label="Altura"
              value={data.formData.height}
              onChange={(value) => setData(prev => ({
                ...prev,
                formData: { ...prev.formData, height: value }
              }))}
              min={100}
              max={240}
              step={1}
              unit="cm"
            />

            <Slider
              label="Peso"
              value={data.formData.weight}
              onChange={(value) => setData(prev => ({
                ...prev,
                formData: { ...prev.formData, weight: value }
              }))}
              min={20}
              max={250}
              step={0.5}
              unit="kg"
            />
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tipo de Dieta
              </label>
              <div className="grid grid-cols-2 gap-3">
                {DIET_OPTIONS.map(({ value, label }) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => handleDietSelect(value)}
                    className={`py-3 px-4 rounded-lg border ${
                      data.formData.dietType === value
                        ? 'bg-primary-500 text-white border-primary-500'
                        : 'border-gray-300 text-gray-700 hover:border-primary-500'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Alergias
              </label>
              <div className="flex flex-wrap gap-2">
                {COMMON_ALLERGIES.map(allergy => (
                  <button
                    key={allergy}
                    type="button"
                    onClick={() => handleAllergyToggle(allergy)}
                    className={`py-2 px-4 rounded-full border ${
                      (data.formData.allergies || []).includes(allergy)
                        ? 'bg-primary-500 text-white border-primary-500'
                        : 'border-gray-300 text-gray-700 hover:border-primary-500'
                    }`}
                  >
                    {allergy}
                  </button>
                ))}
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ingredientes que você não gosta
              </label>
              <input
                type="text"
                placeholder="Digite e pressione Enter"
                value={newIngredient}
                onChange={(e) => setNewIngredient(e.target.value)}
                onKeyDown={handleDislikedIngredient}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
              <div className="flex flex-wrap gap-2 mt-3">
                {(data.formData.dislikedIngredients || []).map(ingredient => (
                  <span
                    key={ingredient}
                    className="inline-flex items-center gap-1 bg-gray-100 text-gray-700 px-3 py-1 rounded-full"
                  >
                    {ingredient}
                    <button
                      type="button"
                      onClick={() => removeDislikedIngredient(ingredient)}
                      className="text-gray-500 hover:text-gray-700"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-lg mx-auto px-4 py-6">
        <div className="flex items-center mb-6">
          {data.step > 1 && (
            <button
              onClick={handleBack}
              className="p-2 hover:bg-gray-100 rounded-lg mr-2"
            >
              <ArrowLeft size={24} />
            </button>
          )}
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">
              {data.step === 1 && 'Vamos nos conhecer melhor?'}
              {data.step === 2 && 'Medidas'}
              {data.step === 3 && 'Preferências Alimentares'}
              {data.step === 4 && 'Restrições'}
            </h1>
            <p className="text-gray-600">
              Etapa {data.step} de {data.totalSteps}
            </p>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-sm mb-6">
          {error && (
            <div className="bg-red-50 text-red-500 p-4 rounded-lg mb-4">
              {error}
            </div>
          )}
          {renderStep()}
        </div>

        <button
          onClick={handleNext}
          disabled={isSubmitting}
          className="w-full bg-primary-500 text-white rounded-lg py-3 hover:bg-primary-600 transition-colors disabled:opacity-50"
        >
          {data.step === data.totalSteps
            ? isSubmitting
              ? 'Salvando...'
              : 'Concluir'
            : 'Próximo'}
        </button>
      </div>
    </div>
  );
}

export default Onboarding;