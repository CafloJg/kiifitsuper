import React, { useState, useEffect, useRef } from 'react';
import { auth, db } from '../lib/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { Activity, TrendingUp, ChevronRight, Utensils, Target, Dumbbell, Sun, Moon, Coffee, Apple, Award, Droplet, Calendar } from 'lucide-react';
import BottomNav from '../components/BottomNav';
import DailyCheckIn from '../components/DailyCheckIn';
import { resetDailyStats } from '../utils/dailyReset';
import type { UserProfile } from '../types/user';

const POLL_INTERVAL = 2000; // 2 seconds

function Dashboard() {
  const navigate = useNavigate();
  const [userData, setUserData] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentHour] = useState(new Date().getHours());
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const pollTimeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    const resetStats = async () => {
      try {
        await resetDailyStats();
        await loadUserData(); // Reload data after reset
      } catch (error) {
        console.error('Error resetting stats:', error);
      }
    };

    resetStats();
  }, []);

  useEffect(() => {
    loadUserData();
  }, [navigate]);

  // Real-time updates for daily stats
  useEffect(() => {
    if (!auth.currentUser) return;

    const fetchUpdates = async () => {
      try {
        const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
        const data = userDoc.data() as UserProfile;
        
        if (!data) return;

        const newUpdateTime = data.dailyStats?.lastUpdated 
          ? new Date(data.dailyStats.lastUpdated)
          : null;

        if (!newUpdateTime) return;

        // Only update if we have a newer timestamp
        if (!lastUpdate || newUpdateTime > lastUpdate) {
          setUserData(data);
          setLastUpdate(newUpdateTime);
        }
      } catch (error) {
        console.error('Error polling for updates:', error);
      }
    };

    // Set up polling with cleanup
    pollTimeoutRef.current = setInterval(fetchUpdates, POLL_INTERVAL);

    return () => clearInterval(pollTimeoutRef.current);
  }, [auth.currentUser, lastUpdate]);

  const loadUserData = async () => {
    if (!auth.currentUser) {
      navigate('/login');
      return;
    }

    try {
      const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
      if (userDoc.exists()) {
        const data = userDoc.data() as UserProfile;        
        if (data.dailyStats?.lastUpdated) {
          setLastUpdate(data.dailyStats.lastUpdated.toString());
        }
        setUserData(data);        
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getGreeting = () => {
    if (currentHour < 12) return 'Bom dia';
    if (currentHour < 18) return 'Boa tarde';
    return 'Boa noite';
  };

  const handleCheckIn = async () => {
    if (!auth.currentUser) return;
    
    try {
      const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
      if (userDoc.exists()) {
        setUserData(userDoc.data() as UserProfile);
      }
    } catch (error) {
      console.error('Erro ao atualizar dados:', error);
    }
  };

  const updateWaterIntake = async (amount: number) => {
    if (!auth.currentUser || !userData) return;

    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const userDoc = await getDoc(userRef);
      if (!userDoc.exists()) return;

      const currentData = userDoc.data() as UserProfile;
      const currentWaterIntake = currentData.dailyStats?.waterIntake || 0;
      const newWaterIntake = currentWaterIntake + amount;
      const now = new Date();

      const updatedStats = {
        ...currentData.dailyStats,
        waterIntake: newWaterIntake,
        lastUpdated: now.toISOString()
      };

      await updateDoc(userRef, {
        dailyStats: updatedStats,
        'currentDietPlan.dailyStats': updatedStats
      });

      setUserData(prev => ({
        ...prev!,
        dailyStats: {
          ...prev!.dailyStats!,
          ...updatedStats
        },
        currentDietPlan: prev!.currentDietPlan ? {
          ...prev!.currentDietPlan,
          dailyStats: updatedStats
        } : null
      }));
    } catch (error) {
      console.error('Erro ao atualizar ingestão de água:', error);
      throw new Error('Erro ao atualizar ingestão de água. Tente novamente.');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 via-white to-gray-50 relative overflow-y-auto overscroll-contain">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-primary-500/5 blur-3xl animate-pulse-slow" />
        <div className="absolute top-60 -left-40 w-[32rem] h-[32rem] rounded-full bg-secondary-500/5 blur-3xl animate-pulse-slow delay-300" />
        <div className="absolute bottom-20 right-20 w-64 h-64 rounded-full bg-blue-500/5 blur-3xl animate-pulse-slow delay-700" />
      </div>

      <div className="max-w-lg mx-auto px-4 py-6 pb-[calc(5rem+env(safe-area-inset-bottom))]">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 animate-fade-in">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800 mb-1">
              {getGreeting()}, {userData?.name?.split(' ')[0] || 'Usuário'}!
            </h1>
            <p className="text-gray-600 flex items-center gap-2 animate-fade-in delay-200">
              <span>Vamos manter o foco hoje!</span>
              <span className="inline-block animate-bounce-subtle">💪</span>
            </p>
          </div>
          <button 
            onClick={() => navigate('/profile')}
            className="relative w-14 h-14 rounded-2xl glass-morphism overflow-hidden hover:shadow-lg transition-all transform hover:scale-105 border border-white/20"
          >
            {userData?.photoURL ? (
              <img 
                src={userData.photoURL} 
                alt="Perfil" 
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-primary-50 flex items-center justify-center text-primary-500 text-lg font-semibold">
                {userData?.name?.[0]?.toUpperCase() || 'U'}
              </div>
            )}
          </button>
        </div>

        {/* Daily Check-in */}
        <DailyCheckIn userData={userData!} onCheckIn={handleCheckIn} />

        {/* Water and Calories Stats */}
        <div className="grid grid-cols-2 gap-6 mb-6 animate-slide-up">
          <div 
            onClick={() => updateWaterIntake(250)}
            className="stat-card glass-morphism hover:shadow-lg transition-all cursor-pointer"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 bg-blue-500/10 rounded-2xl flex items-center justify-center pulse-effect">
                  <Droplet className="text-blue-500" size={20} />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Água</p>
                  <div className="flex items-baseline gap-1">
                    <p className="text-xl font-semibold">
                      {userData?.dailyStats?.waterIntake || 0}
                    </p>
                    <p className="text-sm text-gray-500">ml</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="circular-progress">
                <svg width="120" height="120" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <linearGradient id="blue-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#60A5FA" />
                      <stop offset="100%" stopColor="#3B82F6" />
                    </linearGradient>
                  </defs>
                  <circle className="bg" cx="50" cy="50" r="40" strokeWidth="8" />
                  <circle
                    className="progress" 
                    cx="50" 
                    cy="50" 
                    r="40"
                    strokeWidth="8"
                    stroke="url(#blue-gradient)"
                    strokeDashoffset={251.2 * (1 - Math.min((userData?.dailyStats?.waterIntake || 0) / 2500, 1))}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold">
                    {Math.round((userData?.dailyStats?.waterIntake || 0) / 2500 * 100)}%
                  </span>
                  <span className="text-sm text-gray-500">Meta</span>
                </div>
              </div>
            </div>
          </div>

          <div 
            onClick={() => navigate('/diet')}
            className="stat-card glass-morphism hover:shadow-lg transition-all cursor-pointer"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-14 h-14 bg-primary-500/10 rounded-2xl flex items-center justify-center pulse-effect">
                <Activity className="text-primary-500" size={20} />
              </div>
              <div>
                <p className="text-sm text-gray-600">Calorias</p>
                <div className="flex items-baseline gap-1">
                  <p className="text-xl font-semibold">
                    {Math.round(userData?.dailyStats?.caloriesConsumed || 0)}
                  </p>
                  <p className="text-sm text-gray-500">kcal</p>
                </div>
              </div>
            </div>
            
            <div className="circular-progress">
              <svg width="120" height="120" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <linearGradient id="primary-gradient" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stopColor="#F840BA" />
                    <stop offset="1" stopColor="#EE8B60" />
                  </linearGradient>
                </defs>
                <circle className="bg" cx="50" cy="50" r="40" strokeWidth="8" />
                <circle
                  className="progress" 
                  cx="50" 
                  cy="50" 
                  r="40"
                  strokeWidth="8"
                  stroke="url(#primary-gradient)"
                  strokeDashoffset={251.2 * (1 - Math.min(
                    (userData?.dailyStats?.caloriesConsumed || 0) / 
                    (userData?.currentDietPlan?.totalCalories || 2000),
                    1
                  ))}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-2xl font-bold">
                  {Math.round((userData?.dailyStats?.caloriesConsumed || 0) / 
                    (userData?.currentDietPlan?.totalCalories || 2000) * 100)}%
                </span>
                <span className="text-sm text-gray-500">Meta</span>
              </div>
            </div>
          </div>
        </div>

        {/* Today's Schedule */}
        <div className="glass-morphism overflow-hidden mb-6 animate-slide-up delay-100">
          <div className="p-6 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-secondary-500/10 rounded-2xl flex items-center justify-center float-effect">
                <Calendar className="text-secondary-500" size={20} />
              </div>
              <h2 className="text-lg font-semibold">Cronograma de Hoje</h2>
            </div>
          </div>
          
          <div className="divide-y divide-white/5">
            {[
              { 
                icon: Coffee, 
                time: '07:00', 
                title: 'Café da Manhã',
                calories: userData?.currentDietPlan?.meals?.[0]?.calories || 0,
                status: currentHour >= 7 ? 'done' : 'pending'
              },
              { 
                icon: Apple, 
                time: '10:00', 
                title: 'Lanche da Manhã',
                calories: userData?.currentDietPlan?.meals?.[1]?.calories || 0,
                status: currentHour >= 10 ? 'done' : 'pending'
              },
              { 
                icon: Sun, 
                time: '13:00', 
                title: 'Almoço',
                calories: userData?.currentDietPlan?.meals?.[2]?.calories || 0,
                status: currentHour >= 13 ? 'done' : 'pending'
              },
              { 
                icon: Apple, 
                time: '16:00', 
                title: 'Lanche da Tarde',
                calories: userData?.currentDietPlan?.meals?.[3]?.calories || 0,
                status: 'pending'
              },
              { 
                icon: Moon, 
                time: '19:00', 
                title: 'Jantar',
                calories: userData?.currentDietPlan?.meals?.[4]?.calories || 0,
                status: 'pending'
              }
            ].map((meal, index) => {
              const Icon = meal.icon;
              return (
                <div 
                  key={index}
                  className="flex items-center gap-4 p-6 hover:bg-white/5 transition-all cursor-pointer transform hover:scale-[0.99]"
                  onClick={() => navigate('/diet')}
                >
                  <div className="w-12 h-12 bg-primary-500/10 rounded-xl flex items-center justify-center glow-effect">
                    <Icon className="text-primary-500" size={20} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium">{meal.title}</h3>
                      <ChevronRight size={20} className="text-gray-400" />
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span>{meal.time}</span>
                      <span>{meal.calories} kcal</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Workout Section */}
        <div 
          onClick={() => navigate('/goals')}
          className="glass-morphism rounded-2xl overflow-hidden animate-slide-up delay-200 cursor-pointer hover:shadow-lg transition-all"
        >
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 bg-primary-500/10 rounded-2xl flex items-center justify-center float-effect">
                  <Dumbbell className="text-primary-500" size={24} />
                </div>
                <div>
                  <h3 className="font-semibold">Treino de Hoje</h3>
                  <p className="text-sm text-gray-500">
                    {userData?.goals?.type === 'loss' 
                      ? '45min Cardio' 
                      : userData?.goals?.type === 'gain'
                      ? 'Musculação: Costas e Bíceps'
                      : '30min Cardio + Força'}
                  </p>
                </div>
              </div>
              <ChevronRight size={20} className="text-gray-400 transition-transform group-hover:translate-x-1" />
            </div>
            
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-100">
              <div>
                <p className="text-sm text-gray-500 mb-1">Calorias</p>
                <p className="font-medium">
                  {userData?.goals?.type === 'loss' ? '400' : '300'} kcal
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">Duração</p>
                <p className="font-medium">
                  {userData?.goals?.type === 'loss' ? '45' : '30'} min
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">Intensidade</p>
                <p className="font-medium">
                  {userData?.goals?.type === 'loss' ? 'Alta' : 'Moderada'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <BottomNav />
    </div>
  );
}

export default Dashboard