import React, { useState, useEffect } from 'react';
import BottomNav from '../components/BottomNav';
import { Settings, Bell, Shield, HelpCircle, LogOut, Camera, Upload, X, ChevronRight, Coins, Calendar, Crown, Heart } from 'lucide-react';
import { auth, db, storage } from '../lib/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { useNavigate } from 'react-router-dom';
import type { UserProfile, Gender, DietType } from '../types/user';

const DIET_OPTIONS: { value: DietType; label: string }[] = [
  { value: 'omnivoro', label: 'Onívoro' },
  { value: 'vegetariano', label: 'Vegetariano' },
  { value: 'vegano', label: 'Vegano' },
  { value: 'low-carb', label: 'Low Carb' },
  { value: 'cetogenica', label: 'Cetogênica' },
  { value: 'mediterranea', label: 'Mediterrânea' }
];

function Profile() {
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [userData, setUserData] = useState<Partial<UserProfile>>({});
  const [editData, setEditData] = useState<Partial<UserProfile>>({});
  const [showSettings, setShowSettings] = useState(false);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>('default');
  const [showFavorites, setShowFavorites] = useState(false);

  useEffect(() => {
    const loadUserData = async () => {
      if (!auth.currentUser) {
        navigate('/login');
        return;
      }

      try {
        const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
        if (userDoc.exists()) {
          const data = userDoc.data() as UserProfile;
          setUserData(data);
          setEditData(data);
        }
        
        // Check notification permission
        if ('Notification' in window) {
          setNotificationPermission(Notification.permission);
        }
      } catch (error) {
        console.error('Erro ao carregar dados:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadUserData();
  }, [navigate]);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !auth.currentUser) return;

    setIsUploading(true);
    setUploadError('');

    try {
      if (file.size > 5 * 1024 * 1024) {
        throw new Error('A foto deve ter no máximo 5MB');
      }

      if (!file.type.startsWith('image/')) {
        throw new Error('O arquivo deve ser uma imagem');
      }

      const storageRef = ref(storage, `profile-photos/${auth.currentUser.uid}`);
      await uploadBytes(storageRef, file);
      const photoURL = await getDownloadURL(storageRef);

      setEditData(prev => ({ ...prev, photoURL }));
      
      // Atualizar imediatamente no Firestore
      const userRef = doc(db, 'users', auth.currentUser.uid);
      await updateDoc(userRef, { photoURL });
      
      setUserData(prev => ({ ...prev, photoURL }));
    } catch (error) {
      console.error('Erro ao fazer upload da foto:', error);
      setUploadError(
        error instanceof Error 
          ? error.message 
          : 'Erro ao fazer upload da foto. Tente novamente.'
      );
    } finally {
      setIsUploading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setEditData(prev => ({
      ...prev,
      [name]: type === 'number' ? (value ? Number(value) : undefined) : value
    }));
  };

  const handleGenderSelect = (gender: Gender) => {
    setEditData(prev => ({ ...prev, gender }));
  };

  const handleDietSelect = (dietType: DietType) => {
    setEditData(prev => ({ ...prev, dietType }));
  };

  const handleSave = async () => {
    if (!auth.currentUser) return;

    setIsSaving(true);
    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      await updateDoc(userRef, editData);
      setUserData(editData);
      setIsEditing(false);
    } catch (error) {
      console.error('Erro ao salvar alterações:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleLogout = async () => {
    try {
      await auth.signOut();
      navigate('/login');
    } catch (error) {
      console.error('Erro ao fazer logout:', error);
    }
  };

  const requestNotificationPermission = async () => {
    if (!('Notification' in window)) {
      alert('Este navegador não suporta notificações.');
      return;
    }

    try {
      const permission = await Notification.requestPermission();
      setNotificationPermission(permission);
      
      if (permission === 'granted') {
        new Notification('Notificações Ativadas!', {
          body: 'Você receberá lembretes diários do check-in às 10h.',
          icon: '/vite.svg'
        });
      }
    } catch (error) {
      console.error('Erro ao solicitar permissão:', error);
    }
  };

  const calculateDaysActive = () => {
    if (!userData.createdAt) return 0;
    
    try {
      const createdDate = userData.createdAt instanceof Date 
        ? userData.createdAt 
        : new Date(userData.createdAt);
        
      const now = new Date();
      const diffTime = Math.abs(now.getTime() - createdDate.getTime());
      return Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 0;
    } catch (error) {
      console.error('Error calculating days active:', error);
      return 0;
    }
  };

  const getPlanLabel = (tier?: string) => {
    switch (tier) {
      case 'basic':
        return 'Plano Basic';
      case 'premium':
        return 'Plano Premium';
      case 'premium-plus':
        return 'Plano Premium Plus';
      default:
        return 'Plano não definido';
    }
  };

  const renderSettings = () => {
    if (!showSettings) return null;

    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50">
        <div className="bg-white min-h-screen max-w-lg mx-auto">
          <div className="p-4 border-b border-gray-100 flex items-center justify-between sticky top-0 bg-white z-10">
            <h2 className="text-xl font-semibold">Configurações</h2>
            <button
              onClick={() => setShowSettings(false)}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          <div className="p-4 space-y-6">
            {/* Informações Pessoais */}
            <div>
              <h3 className="text-lg font-medium mb-4">Informações Pessoais</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="text-sm text-gray-600">Altura</p>
                    <p className="font-medium">{editData.height || '-'}cm</p>
                  </div>
                  <ChevronRight size={20} className="text-gray-400" />
                </div>

                <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="text-sm text-gray-600">Peso</p>
                    <p className="font-medium">{editData.weight || '-'}kg</p>
                  </div>
                  <ChevronRight size={20} className="text-gray-400" />
                </div>

                <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="text-sm text-gray-600">Dieta</p>
                    <p className="font-medium">
                      {DIET_OPTIONS.find(opt => opt.value === editData.dietType)?.label || '-'}
                    </p>
                  </div>
                  <ChevronRight size={20} className="text-gray-400" />
                </div>

                {editData.allergies && editData.allergies.length > 0 && (
                  <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-600">Alergias</p>
                      <p className="font-medium">{editData.allergies.join(', ')}</p>
                    </div>
                    <ChevronRight size={20} className="text-gray-400" />
                  </div>
                )}
              </div>
            </div>

            {/* Notificações */}
            <div>
              <h3 className="text-lg font-medium mb-4">Notificações</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">Lembrete de Check-in</p>
                    <p className="text-sm text-gray-600">Receba lembretes diários às 10h</p>
                  </div>
                  <button
                    onClick={requestNotificationPermission}
                    className={`px-4 py-2 rounded-lg ${
                      notificationPermission === 'granted'
                        ? 'bg-green-500 text-white'
                        : 'bg-primary-500 text-white'
                    }`}
                  >
                    {notificationPermission === 'granted' ? 'Ativado' : 'Ativar'}
                  </button>
                </div>
              </div>
            </div>

            {/* Estatísticas */}
            <div>
              <h3 className="text-lg font-medium mb-4">Estatísticas</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar size={20} className="text-primary-500" />
                    <p className="font-medium">Dias Ativos</p>
                  </div>
                  <p className="text-2xl font-semibold">{calculateDaysActive()}</p>
                </div>

                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Coins size={20} className="text-primary-500" />
                    <p className="font-medium">Moedas</p>
                  </div>
                  <p className="text-2xl font-semibold">{userData.totalCoins || 0}</p>
                </div>

                <div className="p-4 bg-gray-50 rounded-lg col-span-2">
                  <div className="flex items-center gap-2 mb-2">
                    <Crown size={20} className="text-primary-500" />
                    <p className="font-medium">Plano Atual</p>
                  </div>
                  <p className="text-lg font-semibold">{getPlanLabel(userData.subscriptionTier)}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderFavorites = () => {
    if (!showFavorites) return null;

    const favorites = userData.favoriteMeals || {};
    const sortedFavorites = Object.entries(favorites)
      .sort(([, a], [, b]) => 
        new Date(b.savedAt).getTime() - new Date(a.savedAt).getTime()
      );

    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50">
        <div className="bg-white min-h-screen max-w-lg mx-auto flex flex-col">
          <div className="p-4 border-b border-gray-100 flex items-center justify-between sticky top-0 bg-white z-10">
            <h2 className="text-xl font-semibold">Refeições Favoritas</h2>
            <button
              onClick={() => setShowFavorites(false)}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          <div className="p-4 overflow-y-auto mobile-scroll">
            {sortedFavorites.length > 0 ? (
              <div className="space-y-4">
                {sortedFavorites.map(([id, meal]) => (
                  <div key={id} className="bg-white rounded-xl border border-gray-100 p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium">{meal.name}</h3>
                      <span className="text-sm text-gray-500">
                        {new Date(meal.savedAt).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600">
                      <p>{meal.calories} kcal</p>
                      <p>
                        P: {meal.protein}g • C: {meal.carbs}g • G: {meal.fat}g
                      </p>
                    </div>
                    <div className="mt-3 pt-3 border-t border-gray-100">
                      <p className="text-sm font-medium text-gray-700 mb-2">
                        Alimentos:
                      </p>
                      <div className="space-y-1">
                        {meal.foods.map((food, index) => (
                          <p key={index} className="text-sm text-gray-600">
                            • {food.name} ({food.portion})
                          </p>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart size={32} className="text-gray-400" />
                </div>
                <p className="text-gray-600">
                  Você ainda não tem refeições favoritas
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 overflow-y-auto overscroll-contain">
      <div className="max-w-lg mx-auto px-4 py-6 pb-[calc(5rem+env(safe-area-inset-bottom))]">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-semibold text-gray-800">Perfil</h1>
          {!isEditing && (
            <button
              onClick={() => setIsEditing(true)}
              className="text-primary-500 hover:text-primary-600"
            >
              Editar
            </button>
          )}
        </div>

        {/* Profile Info */}
        <div className="bg-white rounded-2xl p-6 shadow-sm mb-6">
          <div className="text-center mb-6">
            <div className="w-24 h-24 bg-primary-100 rounded-full mx-auto mb-4 flex items-center justify-center relative">
              {userData.photoURL ? (
                <img
                  src={userData.photoURL}
                  alt="Foto de perfil"
                  className="w-full h-full object-cover rounded-full"
                />
              ) : (
                <Camera size={32} className="text-primary-500" />
              )}
              {isUploading && (
                <div className="absolute inset-0 bg-black bg-opacity-50 rounded-full flex items-center justify-center">
                  <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
            </div>
            <input
              type="file"
              accept="image/*"
              onChange={handlePhotoUpload}
              className="hidden"
              id="photo-upload"
              disabled={isUploading}
            />
            <label
              htmlFor="photo-upload"
              className={`inline-flex items-center gap-2 ${
                isUploading 
                  ? 'text-gray-400 cursor-not-allowed' 
                  : 'text-primary-500 cursor-pointer hover:text-primary-600'
              }`}
            >
              <Upload size={20} />
              <span>{isUploading ? 'Enviando...' : 'Alterar foto'}</span>
            </label>
            {uploadError && (
              <p className="text-red-500 text-sm mt-2">{uploadError}</p>
            )}
          </div>

          {/* Stats Summary */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="text-center p-3 bg-gray-50 rounded-xl">
              <div className="flex items-center justify-center mb-1">
                <Coins className="text-primary-500" size={20} />
              </div>
              <p className="text-sm text-gray-600">Moedas</p>
              <p className="font-semibold">{userData.totalCoins || 0}</p>
            </div>
            
            <div className="text-center p-3 bg-gray-50 rounded-xl">
              <div className="flex items-center justify-center mb-1">
                <Crown className="text-primary-500" size={20} />
              </div>
              <p className="text-sm text-gray-600">Plano</p>
              <p className="font-semibold capitalize">{userData.subscriptionTier || 'Basic'}</p>
            </div>

            <div className="text-center p-3 bg-gray-50 rounded-xl">
              <div className="flex items-center justify-center mb-1">
                <Calendar className="text-primary-500" size={20} />
              </div>
              <p className="text-sm text-gray-600">Dias Ativos</p>
              <p className="font-semibold">{calculateDaysActive()}</p>
            </div>
          </div>

          {isEditing ? (
            <div className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Nome
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={editData.name || ''}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <div>
                <label htmlFor="age" className="block text-sm font-medium text-gray-700 mb-1">
                  Idade
                </label>
                <input
                  type="number"
                  id="age"
                  name="age"
                  value={editData.age || ''}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Gênero
                </label>
                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => handleGenderSelect('feminino')}
                    className={`flex-1 py-3 px-4 rounded-lg border ${
                      editData.gender === 'feminino'
                        ? 'bg-primary-500 text-white border-primary-500'
                        : 'border-gray-300 text-gray-700 hover:border-primary-500'
                    }`}
                  >
                    Feminino
                  </button>
                  <button
                    type="button"
                    onClick={() => handleGenderSelect('masculino')}
                    className={`flex-1 py-3 px-4 rounded-lg border ${
                      editData.gender === 'masculino'
                        ? 'bg-primary-500 text-white border-primary-500'
                        : 'border-gray-300 text-gray-700 hover:border-primary-500'
                    }`}
                  >
                    Masculino
                  </button>
                  <button
                    type="button"
                    onClick={() => handleGenderSelect('nao-binario')}
                    className={`flex-1 py-3 px-4 rounded-lg border ${
                      editData.gender === 'nao-binario'
                        ? 'bg-primary-500 text-white border-primary-500'
                        : 'border-gray-300 text-gray-700 hover:border-primary-500'
                    }`}
                  >
                    Não Binário
                  </button>
                </div>
              </div>

              <div>
                <label htmlFor="height" className="block text-sm font-medium text-gray-700 mb-1">
                  Altura (cm)
                </label>
                <input
                  type="number"
                  id="height"
                  name="height"
                  value={editData.height || ''}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <div>
                <label htmlFor="weight" className="block text-sm font-medium text-gray-700 mb-1">
                  Peso (kg)
                </label>
                <input
                  type="number"
                  id="weight"
                  name="weight"
                  value={editData.weight || ''}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tipo de Dieta
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {DIET_OPTIONS.map(({ value, label }) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => handleDietSelect(value)}
                      className={`py-3 px-4 rounded-lg border ${
                        editData.dietType === value
                          ? 'bg-primary-500 text-white border-primary-500'
                          : 'border-gray-300 text-gray-700 hover:border-primary-500'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => {
                    setEditData(userData);
                    setIsEditing(false);
                  }}
                  className="flex-1 py-3 px-4 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleSave}
                  disabled={isSaving}
                  className="flex-1 py-3 px-4 rounded-lg bg-primary-500 text-white hover:bg-primary-600 disabled:opacity-50"
                >
                  {isSaving ? 'Salvando...' : 'Salvar'}
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-600">Nome</p>
                <p className="text-lg font-medium">{userData.name || '-'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Email</p>
                <p className="text-lg font-medium">{userData.email}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Idade</p>
                  <p className="text-lg font-medium">{userData.age || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Gênero</p>
                  <p className="text-lg font-medium capitalize">{userData.gender || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Altura</p>
                  <p className="text-lg font-medium">{userData.height ? `${userData.height}cm` : '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Peso</p>
                  <p className="text-lg font-medium">{userData.weight ? `${userData.weight}kg` : '-'}</p>
                </div>
              </div>
              <div>
                <p className="text-sm text-gray-600">Tipo de Dieta</p>
                <p className="text-lg font-medium">
                  {DIET_OPTIONS.find(opt => opt.value === userData.dietType)?.label || '-'}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Settings Menu */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <div className="divide-y divide-gray-100">
            <button 
              onClick={() => setShowSettings(true)}
              className="w-full flex items-center p-4 hover:bg-gray-50 transition-colors"
            >
              <Settings size={20} className="text-primary-500 mr-3" />
              <span className="text-gray-700">Configurações</span>
            </button>
            
            <button 
              onClick={requestNotificationPermission}
              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center">
                <Bell size={20} className="text-primary-500 mr-3" />
                <span className="text-gray-700">Notificações</span>
              </div>
              <span className={`text-sm ${
                notificationPermission === 'granted' 
                  ? 'text-green-500' 
                  : 'text-gray-500'
              }`}>
                {notificationPermission === 'granted' ? 'Ativadas' : 'Desativadas'}
              </span>
            </button>
            
            <button className="w-full flex items-center p-4 hover:bg-gray-50 transition-colors">
              <Shield size={20} className="text-primary-500 mr-3" />
              <span className="text-gray-700">Privacidade</span>
            </button>
            
            <button 
              onClick={() => setShowFavorites(true)}
              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center">
                <Heart size={20} className="text-primary-500 mr-3" />
                <span className="text-gray-700">Refeições Favoritas</span>
              </div>
              <span className="text-sm text-gray-500">
                {Object.keys(userData.favoriteMeals || {}).length}
              </span>
            </button>
            
            <button className="w-full flex items-center p-4 hover:bg-gray-50 transition-colors">
              <HelpCircle size={20} className="text-primary-500 mr-3" />
              <span className="text-gray-700">Ajuda</span>
            </button>
            
            <button
              onClick={handleLogout}
              className="w-full flex items-center p-4 hover:bg-gray-50 transition-colors text-red-600"
            >
              <LogOut size={20} className="mr-3" />
              <span>Sair</span>
            </button>
          </div>
        </div>
      </div>

      {showSettings && renderSettings()}
      {showFavorites && renderFavorites()}
      <BottomNav />
    </div>
  );
}

export default Profile;