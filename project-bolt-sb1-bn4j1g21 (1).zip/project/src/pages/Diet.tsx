import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { generateMeals, generateFuturePlans, generateShoppingList } from '../utils/dietGenerator';
import { 
  Utensils, 
  ChevronRight, 
  ShoppingCart,
  Activity, 
  TrendingUp, 
  Target, 
  RefreshCw, 
  Calculator, 
  Apple, 
  AlertCircle,
  Calendar as CalendarIcon
} from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { calculateMacros } from '../lib/diet';
import MacroCalculator from '../components/MacroCalculator';
import DietCalendar from '../components/DietCalendar';
import MealCard from '../components/MealCard';
import DietProgress from '../components/DietProgress';
import MealSuggestions from '../components/MealSuggestions';
import BottomNav from '../components/BottomNav';
import ShoppingList from '../components/ShoppingList';
import type { UserProfile, Meal, DietPlan } from '../types/user';

function Diet() {
  const navigate = useNavigate();
  const [userData, setUserData] = useState<UserProfile | null>(null);
  const [dietPlan, setDietPlan] = useState<DietPlan | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const [error, setError] = useState('');
  const [completedMeals, setCompletedMeals] = useState<string[]>([]);
  const [showCalendar, setShowCalendar] = useState<boolean | null>(null);
  const [showSuggestions, setShowSuggestions] = useState<string | null>(null);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [dietHistory, setDietHistory] = useState<DietPlan[]>([]);
  const [futurePlans, setFuturePlans] = useState<Record<string, DietPlan>>({});
  const [shoppingList, setShoppingList] = useState<ShoppingList | null>(null);
  const [showShoppingList, setShowShoppingList] = useState(false);

  const loadUserData = useCallback(async () => {
    if (!auth.currentUser) {
      navigate('/login');
      return;
    }

    try {
      const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
      if (userDoc.exists()) {
        const data = userDoc.data() as UserProfile;
        setUserData(data);
        
        // Combine current plan with diet history
        const allPlans: DietPlan[] = [];
        
        if (data.currentDietPlan) {
          allPlans.push({
            ...data.currentDietPlan,
            date: new Date().toISOString().split('T')[0]
          });
          setDietPlan(data.currentDietPlan);
          
          // Load completed meals for today
          const today = new Date().toISOString().split('T')[0];
          const todayMeals = data.dailyStats?.completedMeals?.[today] || [];
          setCompletedMeals(todayMeals);
        }
        
        if (data.dietHistory?.plans) {
          const cutoffDate = new Date();
          cutoffDate.setDate(cutoffDate.getDate() - 120);
          
          allPlans.push(
            ...data.dietHistory.plans.filter(plan => 
              new Date(plan.date || plan.createdAt) > cutoffDate
            )
          );
        }
        
        // Sort by date descending
        allPlans.sort((a, b) => 
          new Date(b.date || b.createdAt).getTime() - 
          new Date(a.date || a.createdAt).getTime()
        );
        
        setDietHistory(allPlans);
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      setError('Erro ao carregar seu plano alimentar');
    } finally {
      setIsLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    loadUserData();
  }, [loadUserData]);

  // Load future plans and shopping list
  useEffect(() => {
    if (dietPlan) {
      generateFuturePlans(userData!, dietPlan, 15).then(plans => {
        setFuturePlans(plans);
        generateShoppingList(plans).then(list => {
          setShoppingList(list);
        });
      });
    }
  }, [dietPlan]);

  const handleGenerateNewPlan = async () => {
    if (!userData || isGenerating) return;
    
    // Validate required data first
    if (!userData.weight || !userData.height || !userData.age || !userData.gender) {
      setError('Complete seu perfil antes de gerar um plano alimentar');
      return;
    }

    if (!userData.goals?.type) {
      setError('Configure suas metas antes de gerar um plano alimentar');
      return;
    }

    if (!userData.dietType) {
      setError('Selecione um tipo de dieta no seu perfil');
      return;
    }

    setIsGenerating(true);
    setGenerationProgress(0);
    setError('');

    const now = new Date().toISOString();
    const today = now.split('T')[0];

    // Start progress animation
    const duration = 15000; // 15 seconds total
    const interval = 100; // Update every 100ms
    const steps = duration / interval;
    let currentStep = 0;

    const progressTimer = setInterval(() => {
      currentStep++;
      const progress = Math.min((currentStep / steps) * 100, 95);
      setGenerationProgress(progress);
    }, interval);

    try {
      const newPlan = await generateMeals(userData);

      // Complete progress bar at the end
      setGenerationProgress(100);
      await new Promise(resolve => setTimeout(resolve, 500)); // Show 100% briefly
      
      const resetStats = {
        caloriesConsumed: 0,
        proteinConsumed: 0,
        carbsConsumed: 0,
        fatConsumed: 0,
        waterIntake: 0,
        macroDistribution: {
          protein: 0,
          carbs: 0,
          fat: 0
        },
        completedMeals: {
          [today]: []
        },
        lastUpdated: now
      };
      
      // Reset completed meals and local state
      setCompletedMeals([]);
      setUserData(prev => ({
        ...prev!,
        dailyStats: resetStats,
        currentDietPlan: newPlan
      }));
      setDietPlan(newPlan);

      // Update user document
      if (auth.currentUser) {
        await updateDoc(doc(db, 'users', auth.currentUser.uid), {
          currentDietPlan: newPlan,
          lastPlanGenerated: now,
          dailyStats: resetStats,
          'currentDietPlan.dailyStats': resetStats
        });
      }
      
    } catch (error) {
      console.error('Erro ao gerar plano:', error);
      setError(
        error instanceof Error 
          ? error.message.includes('API key') 
            ? error.message // Use the actual API key error message
            : error.message
          : 'Erro ao gerar plano. Por favor, tente novamente.'
      );
    } finally {
      clearInterval(progressTimer);
      setIsGenerating(false);
      setTimeout(() => setGenerationProgress(0), 800);
    }
  };

  const handleMealCheckIn = async (mealId: string) => {
    if (!auth.currentUser || !userData || !dietPlan) return;

    const meal = dietPlan.meals.find(m => m.id === mealId);
    if (!meal) return;

    const now = new Date();
    const today = now.toISOString().split('T')[0];
    const isCurrentPlan = dietPlan === userData.currentDietPlan;

    // Calculate new stats
    const currentStats = userData.dailyStats || {
      caloriesConsumed: 0,
      proteinConsumed: 0,
      carbsConsumed: 0,
      fatConsumed: 0,
      waterIntake: 0,
      completedMeals: {},
      lastUpdated: now.toISOString()
    };

    const newCompletedMeals = [...completedMeals, mealId];

    const newStats = {
      caloriesConsumed: currentStats.caloriesConsumed + meal.calories,
      proteinConsumed: currentStats.proteinConsumed + meal.protein,
      carbsConsumed: currentStats.carbsConsumed + meal.carbs,
      fatConsumed: currentStats.fatConsumed + meal.fat,
      waterIntake: currentStats.waterIntake,
      completedMeals: {
        ...currentStats.completedMeals,
        [today]: newCompletedMeals
      },
      lastUpdated: now.toISOString()
    };

    // Update local state immediately
    setCompletedMeals(newCompletedMeals);
    setUserData(prev => ({
      ...prev!,
      dailyStats: newStats,
      currentDietPlan: prev?.currentDietPlan 
        ? {
            ...prev.currentDietPlan,
            dailyStats: newStats
          }
        : undefined
    }));

    // Update Firestore
    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      
      if (isCurrentPlan) {
        // Update current plan stats
        await updateDoc(userRef, {
          dailyStats: newStats,
          'currentDietPlan.dailyStats': newStats
        });
      } else {
        // Update history plan stats
        const updatedHistory = {
          ...userData.dietHistory,
          plans: userData.dietHistory?.plans.map(p => 
            p.id === dietPlan.id 
              ? { ...p, dailyStats: newStats }
              : p
          )
        };
        
        await updateDoc(userRef, {
          'dietHistory': updatedHistory
        });
      }
      
      // Refresh diet history
      loadUserData();
    } catch (error) {
      console.error('Error updating meal stats:', error);
      // Revert local state on error
      setCompletedMeals(completedMeals);
      setUserData(userData);
      setError('Erro ao atualizar refeição. Tente novamente.');
    }
  };

  const handleMealUpdate = async (updatedMeal: Meal) => {
    if (!auth.currentUser || !dietPlan) return;
    const isCurrentPlan = dietPlan === userData?.currentDietPlan;

    try {
      const updatedPlan = {
        ...dietPlan,
        meals: dietPlan.meals.map(meal =>
          meal.id === updatedMeal.id ? updatedMeal : meal
        )
      };

      const userRef = doc(db, 'users', auth.currentUser.uid);
      
      if (isCurrentPlan) {
        await updateDoc(userRef, {
          currentDietPlan: updatedPlan
        });
      } else {
        // Update plan in history
        const updatedHistory = {
          ...userData?.dietHistory,
          plans: userData?.dietHistory?.plans.map(p => 
            p.id === dietPlan.id ? updatedPlan : p
          )
        };
        
        await updateDoc(userRef, {
          'dietHistory': updatedHistory
        });
      }

      setDietPlan(updatedPlan);
      setShowSuggestions(null);
      
      // Refresh data to ensure consistency
      loadUserData();
    } catch (error) {
      console.error('Erro ao atualizar refeição:', error);
      setError('Erro ao atualizar refeição. Por favor, tente novamente.');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 via-white to-gray-50 relative overflow-y-auto overscroll-contain">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-primary-500/5 blur-3xl animate-pulse-slow" />
        <div className="absolute top-60 -left-40 w-[32rem] h-[32rem] rounded-full bg-secondary-500/5 blur-3xl animate-pulse-slow delay-300" />
        <div className="absolute bottom-20 right-20 w-64 h-64 rounded-full bg-blue-500/5 blur-3xl animate-pulse-slow delay-700" />
      </div>

      <div className="max-w-lg mx-auto px-4 py-6 pb-[calc(5rem+env(safe-area-inset-bottom))]">
        <div className="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-0 justify-between mb-6">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Plano Alimentar</h1>
            <div className="text-gray-600 flex items-center gap-2">
              <span>Dieta personalizada</span>
              <span className="inline-block animate-bounce-subtle">🥗</span>
            </div>
          </div>
          <div className="flex items-center gap-3 p-2 -mx-2 overflow-x-auto hide-scrollbar">
            <button
              onClick={() => setShowShoppingList(true)}
              className="p-3 bg-white rounded-xl shadow-sm hover:shadow-lg transition-all active:scale-95 flex-shrink-0"
              title="Lista de Compras"
            >
              <ShoppingCart size={20} />
            </button>
            <button
              onClick={() => setShowCalendar(true)}
              className="p-3 bg-white rounded-xl shadow-sm hover:shadow-lg transition-all active:scale-95 flex-shrink-0"
              title="Histórico"
            >
              <CalendarIcon size={20} />
            </button>
            <button
              onClick={() => setShowCalculator(true)}
              className="p-3 bg-white rounded-xl shadow-sm hover:shadow-lg transition-all active:scale-95 flex-shrink-0"
              title="Calculadora de Macros"
            >
              <Calculator size={20} />
            </button>
            <button
              onClick={handleGenerateNewPlan}
              disabled={isGenerating}
              className="p-3 bg-white rounded-xl shadow-sm hover:shadow-lg transition-all active:scale-95 disabled:opacity-50 flex-shrink-0"
              title="Gerar Novo Plano"
            >
              <RefreshCw size={20} className={isGenerating ? 'animate-spin' : ''} />
            </button>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 rounded-xl p-4 mb-6">
            <div className="flex items-center gap-3">
              <AlertCircle className="text-red-500 flex-shrink-0" size={28} />
              <div className="flex-1">
                <h3 className="font-medium text-red-800">
                  {error.toLowerCase().includes('api') ? 'Configuração da API OpenAI' : 'Erro ao Gerar Plano'}
                </h3>
                <p className="text-red-600 whitespace-pre-line">{error}</p>
                {error.toLowerCase().includes('api') && (
                  <div className="mt-4 space-y-3">
                    <p className="text-sm text-gray-600">
                      Para gerar planos alimentares, você precisa:
                    </p>
                    <ol className="list-decimal list-inside text-sm text-gray-600 space-y-2">
                      <li>Obter uma chave da API OpenAI</li>
                      <li>Copiar a chave (começa com 'sk-')</li>
                      <li>Colar a chave no arquivo .env</li>
                    </ol>
                    <a 
                      href="https://platform.openai.com/account/api-keys"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-white bg-primary-500 hover:bg-primary-600 px-6 py-3 rounded-xl shadow-sm hover:shadow transition-all"
                    >
                      <span>Obter chave da API OpenAI</span>
                      <ChevronRight size={18} />
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
        
        {/* Generation Progress */}
        {isGenerating && (
          <div className="bg-white rounded-2xl p-6 shadow-sm mb-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium">Gerando Plano Alimentar</h3>
              <span className="text-primary-500 font-medium">{Math.round(generationProgress)}%</span>
            </div>
            <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-primary-500 to-secondary-500 transition-all duration-300 ease-out"
                style={{ width: `${generationProgress}%` }}
              />
            </div>
            <p className="text-sm text-gray-500 mt-4">
              {generationProgress < 25 && "Analisando suas preferências..."}
              {generationProgress >= 25 && generationProgress < 50 && "Calculando macronutrientes..."}
              {generationProgress >= 50 && generationProgress < 75 && "Montando refeições balanceadas..."}
              {generationProgress >= 75 && generationProgress < 98 && "Finalizando seu plano..."}
              {generationProgress >= 98 && "Plano gerado com sucesso!"}
            </p>
          </div>
        )}

        {dietPlan ? (
          <>
            {/* Progress Charts */}
            <DietProgress 
              plans={dietHistory}
              currentPlan={dietPlan}
            />

            {/* Meal Cards */}
            <div className="space-y-4 mt-6">
              {dietPlan.meals.map((meal) => (
                <React.Fragment key={meal.id}>
                  {showSuggestions === meal.id ? (
                    <MealSuggestions
                      meal={meal}
                      onSelect={handleMealUpdate}
                      onFavorite={async (favoriteMeal) => {
                        if (!auth.currentUser || !userData) return;
                        
                        try {
                          await updateDoc(doc(db, 'users', auth.currentUser.uid), {
                            [`favoriteMeals.${favoriteMeal.id}`]: {
                              ...favoriteMeal,
                              savedAt: new Date().toISOString()
                            }
                          });
                        } catch (error) {
                          console.error('Erro ao favoritar refeição:', error);
                        }
                      }}
                    />
                  ) : (
                    <div className="relative">
                      <MealCard 
                        meal={meal}
                        onCheckIn={handleMealCheckIn}
                        isCompleted={completedMeals.includes(meal.id)}
                      />
                      <button
                        onClick={() => setShowSuggestions(meal.id)}
                        className="absolute top-4 right-4 p-2 bg-white rounded-lg shadow-sm hover:bg-gray-50 transition-colors"
                      >
                        <ChevronRight size={20} />
                      </button>
                    </div>
                  )}
                </React.Fragment>
              ))}
            </div>
          </>
        ) : (
          <div className="bg-white rounded-2xl p-6 shadow-sm text-center">
            <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Apple className="text-primary-500" size={32} />
            </div>
            <h2 className="text-xl font-semibold mb-2">Nenhum plano encontrado</h2>
            <p className="text-gray-600 mb-6">
              Gere seu primeiro plano alimentar personalizado
            </p>
            <button
              onClick={handleGenerateNewPlan}
              disabled={isGenerating}
              className="w-full bg-primary-500 text-white rounded-lg py-3 hover:bg-primary-600 transition-colors disabled:opacity-50"
            >
              {isGenerating ? 'Gerando plano...' : 'Gerar Plano Alimentar'}
            </button>
          </div>
        )}
      </div>

      {showCalculator && (
        <MacroCalculator onClose={() => setShowCalculator(false)} />
      )}
      
      {showCalendar && dietHistory.length > 0 && (
        <DietCalendar
          plans={dietHistory}
          futurePlans={futurePlans}
          onSelectPlan={(plan) => {
            setDietPlan(plan);
            setShowCalendar(null);
          }}
          onClose={() => setShowCalendar(null)}
        />
      )}
      
      {showShoppingList && shoppingList && (
        <ShoppingList
          list={shoppingList}
          onClose={() => setShowShoppingList(false)}
          onUpdate={(updatedList) => setShoppingList(updatedList)}
        />
      )}
      
      <BottomNav />
    </div>
  );
}

export default Diet;