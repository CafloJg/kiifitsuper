/*
  # Add food images table and data

  1. New Tables
    - `food_images`
      - `id` (uuid, primary key)
      - `food_name` (text, unique)
      - `image_url` (text)
      - `thumbnail_url` (text) 
      - `category` (text)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on `food_images` table
    - Add policy for public read access
    - Restrict write access to authenticated admin users

  3. Initial Data
    - Insert curated food images for common foods
*/

-- Create food_images table
CREATE TABLE IF NOT EXISTS food_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  food_name text UNIQUE NOT NULL,
  image_url text NOT NULL,
  thumbnail_url text NOT NULL,
  category text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE food_images ENABLE ROW LEVEL SECURITY;

-- Add policies
CREATE POLICY "Food images are publicly readable"
  ON food_images
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Only admins can modify food images"
  ON food_images
  FOR ALL
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

-- Insert curated food images
INSERT INTO food_images (food_name, image_url, thumbnail_url, category)
VALUES
  -- Grãos e Cereais
  ('arroz integral', 
   'https://images.unsplash.com/photo-1516684732162-798a0062be99?q=80&w=2000',
   'https://images.unsplash.com/photo-1516684732162-798a0062be99?q=80&w=400',
   'grains'),
  ('arroz branco',
   'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?q=80&w=2000',
   'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?q=80&w=400',
   'grains'),
  ('quinoa',
   'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?q=80&w=2000',
   'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?q=80&w=400',
   'grains'),
  ('aveia',
   'https://images.unsplash.com/photo-1471193945509-9ad0617afabf?q=80&w=2000',
   'https://images.unsplash.com/photo-1471193945509-9ad0617afabf?q=80&w=400',
   'grains'),
  ('pão integral',
   'https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?q=80&w=2000',
   'https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?q=80&w=400',
   'grains'),

  -- Proteínas
  ('frango grelhado',
   'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?q=80&w=2000',
   'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?q=80&w=400',
   'proteins'),
  ('peito de frango',
   'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?q=80&w=2000',
   'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?q=80&w=400',
   'proteins'),
  ('ovo',
   'https://images.unsplash.com/photo-1608834461132-7de16c97766e?q=80&w=2000',
   'https://images.unsplash.com/photo-1608834461132-7de16c97766e?q=80&w=400',
   'proteins'),
  ('atum',
   'https://images.unsplash.com/photo-1597733153203-a54d0fbc47de?q=80&w=2000',
   'https://images.unsplash.com/photo-1597733153203-a54d0fbc47de?q=80&w=400',
   'proteins'),

  -- Laticínios
  ('iogurte',
   'https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?q=80&w=2000',
   'https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?q=80&w=400',
   'dairy'),

  -- Frutas
  ('banana',
   'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?q=80&w=2000',
   'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?q=80&w=400',
   'fruits'),
  ('maçã',
   'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?q=80&w=2000',
   'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?q=80&w=400',
   'fruits'),

  -- Vegetais
  ('salada',
   'https://images.unsplash.com/photo-1546793665-c74683f339c1?q=80&w=2000',
   'https://images.unsplash.com/photo-1546793665-c74683f339c1?q=80&w=400',
   'vegetables'),
  ('legumes',
   'https://images.unsplash.com/photo-1540420773420-3366772f4999?q=80&w=2000',
   'https://images.unsplash.com/photo-1540420773420-3366772f4999?q=80&w=400',
   'vegetables'),
  ('feijão',
   'https://images.unsplash.com/photo-1628889211163-95a840e0e3ad?q=80&w=2000',
   'https://images.unsplash.com/photo-1628889211163-95a840e0e3ad?q=80&w=400',
   'legumes')
ON CONFLICT (food_name) DO UPDATE SET
  image_url = EXCLUDED.image_url,
  thumbnail_url = EXCLUDED.thumbnail_url,
  category = EXCLUDED.category;