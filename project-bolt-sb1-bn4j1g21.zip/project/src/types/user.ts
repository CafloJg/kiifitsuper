export interface WeightProgress {
  weight: number;
  date: string; // Store as ISO string
  difference: number;
}

export interface DietHistory {
  plans: DietPlan[];
  lastUpdated: string;
  stats: {
    [date: string]: {
      caloriesConsumed: number;
      proteinConsumed: number;
      carbsConsumed: number;
      fatConsumed: number;
      completedMeals: string[];
      waterIntake: number;
    };
  };
}

export interface DietPlan {
  id: string;
  userId: string;
  createdAt: string;
  completedOnboarding: boolean;
  dailyStats?: DailyStats;
  foodPreferences?: {
    [foodId: string]: {
      name: string;
      type: 'like' | 'dislike';
      score: number; // 1 to 5 for likes, -5 to -1 for dislikes
      calories: number;
      protein: number;
      carbs: number;
      fat: number;
      portion: string;
      updatedAt: string;
    };
  };
  goals?: {
    type: GoalType;
    targetWeight?: number;
  };
  date?: string;
  name?: string;
  description?: string;
  rating?: number;
  totalCalories: number;
  proteinTarget: number;
  carbsTarget: number;
  fatTarget: number;
  meals: Meal[];
  completedMeals?: string[];
  dailyStats?: {
    macroDistribution?: {
      protein: number;
      carbs: number;
      fat: number;
    };
    caloriesConsumed: number;
    proteinConsumed: number;
    carbsConsumed: number;
    fatConsumed: number;
    waterIntake: number;
    completedMeals?: {
      [date: string]: string[];
    };
    lastUpdated: string;
  };
  tags?: string[];
  isArchived?: boolean;
}

export interface Meal {
  id: string;
  name: string;
  time: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  foods: {
    name: string;
    portion: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    thumbnailUrl?: string;
    imageUrl?: string;
    alternatives?: Array<{
      name: string;
      portion: string;
      calories: number;
      protein: number;
      carbs: number;
      fat: number;
      thumbnailUrl?: string;
      imageUrl?: string;
    }>;
  }[];
}