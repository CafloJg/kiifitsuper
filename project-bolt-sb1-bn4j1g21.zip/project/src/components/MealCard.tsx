import React, { useState, useEffect } from 'react';
import { Camera, X, Check, Heart, Clock, ThumbsUp, ThumbsDown, Utensils } from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { getImage } from '../utils/imageService';
import type { Meal } from '../types/user';

interface FoodPreference {
  type: 'like' | 'dislike';
  score: number;
  updatedAt: string;
}

interface MealCardProps {
  meal: Meal;
  onCheckIn: (mealId: string) => void;
  isCompleted: boolean;
}

function MealCard({ meal, onCheckIn, isCompleted }: MealCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [showNutrients, setShowNutrients] = useState(false);
  const [foodPreferences, setFoodPreferences] = useState<Record<string, FoodPreference>>({});

  const loadPreferences = async () => {
    if (!auth.currentUser) return;
    
    try {
      const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
      const userData = userDoc.data();
      const preferences = userData?.foodPreferences || {};
      
      // Convert preferences to local state format
      const formattedPrefs = Object.entries(preferences).reduce((acc, [id, pref]) => ({
        ...acc,
        [id]: {
          type: pref.type as 'like' | 'dislike',
          score: pref.score || 0,
          updatedAt: pref.updatedAt
        }
      }), {});
      
      setFoodPreferences(formattedPrefs);
    } catch (error) {
      console.error('Error loading food preferences:', error);
    }
  };

  // Load existing preferences when component mounts
  useEffect(() => {
    loadPreferences();
  }, []);

  const handleFavorite = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!auth.currentUser || isUpdating) return;

    setIsUpdating(true);
    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const userDoc = await getDoc(userRef);
      const userData = userDoc.data();
      
      if (isFavorite) {
        // Remove from favorites
        const { [meal.id]: removed, ...remaining } = userData?.favoriteMeals || {};
        await updateDoc(userRef, {
          favoriteMeals: remaining
        });
      } else {
        // Add to favorites
        await updateDoc(userRef, {
          [`favoriteMeals.${meal.id}`]: {
            ...meal,
            savedAt: new Date().toISOString()
          }
        });
      }
      
      setIsFavorite(!isFavorite);
    } catch (error) {
      console.error('Error updating favorite:', error);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleMealCheckIn = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!auth.currentUser || isCompleted) return;

    try {
      // Call parent handler first for immediate UI update
      onCheckIn(meal.id);
    } catch (error) {
      console.error('Error updating meal stats:', error);
    }
  };

  const handleFoodFeedback = async (foodId: string, type: 'like' | 'dislike') => {
    if (!auth.currentUser) return;

    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const userDoc = await getDoc(userRef);
      const userData = userDoc.data();
      const food = meal.foods.find(f => f.id === foodId);

      if (!food) {
        throw new Error('Alimento não encontrado');
      }

      const currentPref = userData?.foodPreferences?.[foodId];
      const newScore = type === 'like' ? 
        Math.min(5, (currentPref?.score || 0) + 1) : 
        Math.max(-5, (currentPref?.score || 0) - 1);

      // Update local state immediately for better UX
      setFoodPreferences(prev => ({
        ...prev,
        [foodId]: { 
          type,
          score: newScore,
          updatedAt: new Date().toISOString()
        }
      }));

      // Update user preferences in Firestore
      await updateDoc(userRef, {
        [`foodPreferences.${foodId}`]: {
          name: food.name,
          type,
          score: newScore,
          updatedAt: new Date().toISOString(),
          calories: food.calories,
          protein: food.protein,
          carbs: food.carbs,
          fat: food.fat,
          portion: food.portion
        }
      });

    } catch (error) {
      console.error('Error updating food preference:', error);
      // Show error to user
      const errorMessage = error instanceof Error ? error.message : 'Erro ao salvar preferência';
      alert(errorMessage);
      // Revert local state on error by reloading preferences
      loadPreferences();
    }
  };

  const getMealIcon = () => {
    switch (meal.name.toLowerCase()) {
      case 'café da manhã':
        return '☕️';
      case 'lanche da manhã':
        return '🍎';
      case 'almoço':
        return '🍽️';
      case 'lanche da tarde':
        return '🥪';
      case 'jantar':
        return '🍳';
      case 'ceia':
        return '🥛';
      default:
        return '🍴';
    }
  };

  return (
    <div className={`bg-white rounded-2xl shadow-sm overflow-hidden transition-all duration-300 ${
      isCompleted ? 'border-2 border-green-500' : ''
    }`}>
      <div className="p-6 cursor-pointer hover:bg-gray-50 transition-colors" onClick={() => setIsExpanded(!isExpanded)}>
        <div className="flex items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-primary-50 to-primary-100 rounded-2xl flex items-center justify-center text-2xl shadow-sm transform hover:scale-105 transition-transform">
              <span className="text-2xl">{getMealIcon()}</span>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-1">{meal.name}</h3>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 text-sm text-gray-500">
                  <Clock size={14} className="text-primary-400" />
                  <span>{meal.time}</span>
                </div>
                <div className="flex items-center gap-1 text-sm text-gray-500">
                  <Utensils size={14} className="text-primary-400" />
                  <span>{meal.foods.length} itens</span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-semibold text-lg">{meal.calories} kcal</p>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowNutrients(!showNutrients);
                }}
                className="text-sm text-gray-500 hover:text-primary-500 transition-colors"
              >
                {showNutrients ? (
                  <>P: {meal.protein}g • C: {meal.carbs}g • G: {meal.fat}g</>
                ) : (
                  'Ver nutrientes'
                )}
              </button>
            </div>
            <button
              onClick={handleFavorite}
              className={`p-3 rounded-full transition-all transform hover:scale-110 ${
                isUpdating 
                  ? 'opacity-50 cursor-not-allowed'
                  : isFavorite
                  ? 'text-red-500 hover:bg-red-50 hover:shadow-lg'
                  : 'text-gray-400 hover:bg-gray-100 hover:text-primary-500'
              }`}
              disabled={isUpdating}
            >
              <Heart
                size={24}
                className={`transition-transform ${
                  isFavorite ? 'fill-current animate-pulse' : 'scale-100'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Expanded Content */}
        {isExpanded && (
          <div className="mt-4 space-y-2">
            {meal.foods.map((food, index) => (
              <div 
                key={index}
                className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl"
              >
                {food.thumbnailUrl && (
                  <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 shadow-sm relative">
                    <img
                      src={food.thumbnailUrl}
                      alt={food.name}
                      className="w-full h-full object-cover hover:scale-105 transition-transform"
                      loading="lazy"
                      onError={async (e) => {
                        // Fallback: try to get a new image if the current one fails
                        try {
                          const newImage = await getImage(`${food.name} food plated`, true);
                          if (newImage) {
                            (e.target as HTMLImageElement).src = newImage.thumbnailUrl;
                          }
                        } catch (error) {
                          console.warn('Error loading fallback image:', error);
                          // Use a default food image as final fallback
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200';
                        }
                      }}
                    />
                  </div>
                )}
                <div className="flex-1 min-w-0 flex flex-col">
                  <p className="font-medium text-gray-800 mb-1">{food.name}</p>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <span>{food.portion}</span>
                    <span>•</span>
                    <span>{food.calories} kcal</span>
                    {showNutrients && (
                      <>
                        <span>•</span>
                        <span>P: {food.protein}g</span>
                        <span>•</span>
                        <span>C: {food.carbs}g</span>
                        <span>•</span>
                        <span>G: {food.fat}g</span>
                      </>
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleFoodFeedback(food.id, 'like');
                      }} 
                      className={`p-1.5 rounded-lg transition-colors ${
                        foodPreferences[food.id]?.type === 'like'
                          ? 'bg-green-100 text-green-600'
                          : 'hover:bg-gray-100 text-gray-400'
                      }`}
                    >
                      <ThumbsUp size={16} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleFoodFeedback(food.id, 'dislike');
                      }}
                      className={`p-1.5 rounded-lg transition-colors ${
                        foodPreferences[food.id]?.type === 'dislike'
                          ? 'bg-red-100 text-red-600'
                          : 'hover:bg-gray-100 text-gray-400'
                      }`}
                    >
                      <ThumbsDown size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Action Button */}
        <div className="mt-6">
          {!isCompleted ? (
            <button
              onClick={handleMealCheckIn}
              className={`w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-primary-500 to-secondary-500 text-white font-medium shadow-sm hover:shadow-lg transform hover:translate-y-[-2px] transition-all active:scale-[0.98] ${
                'hover:opacity-90'
              }`}
            >
              <div className="flex items-center justify-center gap-2">
                <Utensils size={20} />
                <span>Marcar como Concluída</span>
              </div>
            </button>
          ) : (
            <div className="flex items-center justify-center gap-2 py-3 bg-green-50 rounded-2xl text-green-500 font-medium animate-fade-in">
              <Check size={20} />
              <span>Refeição Concluída</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default MealCard