import React, { useState, useEffect } from 'react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Star, ArrowLeft } from 'lucide-react';
import type { DietPlan } from '../types/user';

interface DietCalendarProps {
  plans: DietPlan[];
  onSelectPlan: (plan: DietPlan) => void;
  onClose: () => void;
  currentDate?: string;
}

function DietCalendar({ plans, onSelectPlan, onClose, currentDate }: DietCalendarProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [showingCurrentPlan, setShowingCurrentPlan] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<DietPlan | null>(null);
  const [hoveredDate, setHoveredDate] = useState<Date | null>(null); 
  const [isLoading, setIsLoading] = useState(false);
  const [dateRange] = useState(() => {
    const start = new Date();
    start.setDate(start.getDate() - 120);
    
    const end = new Date();
    end.setHours(23, 59, 59, 999);
    
    return { start, end };
  });
  const [stats, setStats] = useState<{
    totalDays: number;
    completedDays: number;
    averageCalories: number;
  }>(() => {
    const filteredPlans = plans.filter(plan => {
      const planDate = new Date(plan.date || plan.createdAt);
      return planDate >= dateRange.start && planDate <= dateRange.end;
    });

    const completedDays = filteredPlans.filter(plan => 
      plan.completedMeals && plan.completedMeals.length > 0
    ).length;

    const totalCalories = filteredPlans.reduce((sum, plan) => 
      sum + (plan.dailyStats?.caloriesConsumed || 0), 0
    );

    return {
      totalDays: filteredPlans.length,
      completedDays,
      averageCalories: filteredPlans.length ? Math.round(totalCalories / filteredPlans.length) : 0
    };
  });

  // Load and cache plan data
  useEffect(() => {
    // Update stats when plans change
    const date = new Date();
    date.setDate(date.getDate() - 120);

    const filteredPlans = plans.filter(plan => {
      const planDate = new Date(plan.date || plan.createdAt);
      return planDate >= date;
    });

    const completedDays = filteredPlans.filter(plan => 
      plan.completedMeals && plan.completedMeals.length > 0
    ).length;

    const totalCalories = filteredPlans.reduce((sum, plan) => 
      sum + (plan.dailyStats?.caloriesConsumed || 0), 0
    );

    setStats({
      totalDays: filteredPlans.length,
      completedDays,
      averageCalories: filteredPlans.length ? Math.round(totalCalories / filteredPlans.length) : 0
    });
  }, [plans]);

  useEffect(() => {
    if (currentDate) {
      const date = new Date(currentDate);
      setCurrentMonth(date);
      setSelectedDate(date);
      setShowingCurrentPlan(true);
    }
  }, [currentDate]);

  // Optimize plan loading
  const loadPlanData = async (date: Date) => {
    setIsLoading(true);
    try {
      const plan = getPlanForDate(date);
      if (plan) {
        setSelectedPlan(plan);
        const today = new Date().toISOString().split('T')[0];
        const planDate = date.toISOString().split('T')[0];
        if (planDate !== today) {
          onSelectPlan(plan);
          onClose();
        }
      }
    } finally {
      setIsLoading(false);
    }
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDayOfMonth = new Date(year, month, 1).getDay();
    
    const days = [];
    for (let i = 0; i < firstDayOfMonth; i++) {
      days.push(null);
    }
    
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(new Date(year, month, i));
    }
    
    return days;
  };

  const getPlanForDate = (date: Date): DietPlan | null => {
    const plan = plans.find(plan => {
      const planDate = new Date(plan.date || plan.createdAt);
      return (
        planDate.getDate() === date.getDate() &&
        planDate.getMonth() === date.getMonth() &&
        planDate.getFullYear() === date.getFullYear()
      );
    });

      // Format date string
      const dateStr = date.toISOString().split('T')[0];
      
      // Get stats for this date if they exist
      const stats = plans.find(p => p.date === dateStr)?.dailyStats;
      
      if (stats) {
        return {
          ...plan,
          dailyStats: stats
        };
      }

    return plan;
  };

  const nextMonth = () => {
    setCurrentMonth(prev => new Date(prev.getFullYear(), prev.getMonth() + 1));
  };

  const prevMonth = () => {
    const newDate = new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1);
    if (newDate >= dateRange.start) {
      setCurrentMonth(newDate);
    }
  };

  const handleDateClick = async (date: Date) => {
    if (date < dateRange.start || date > dateRange.end) return;
    await loadPlanData(date);
  };

  const days = getDaysInMonth(currentMonth);
  const weekDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full">
        <div className="p-6">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              {showingCurrentPlan && (
                <button
                  onClick={() => {
                    setShowingCurrentPlan(false);
                    setSelectedDate(null);
                    setCurrentMonth(new Date());
                  }}
                  className="p-2 hover:bg-gray-100 rounded-lg mr-2"
                >
                  <ArrowLeft size={20} />
                </button>
              )}
              <div className="w-12 h-12 bg-primary-50 rounded-xl flex items-center justify-center">
                <CalendarIcon className="text-primary-500" size={24} />
              </div>
              <div>
                <h3 className="text-xl font-semibold">
                  {showingCurrentPlan ? 'Plano Atual' : 'Histórico de Dietas'}
                </h3>
                <p className="text-sm text-gray-500">
                  {showingCurrentPlan 
                    ? new Date(currentDate!).toLocaleDateString('pt-BR', { 
                        day: '2-digit',
                        month: 'long',
                        year: 'numeric'
                      })
                    : 'Selecione uma data para ver o plano'
                  }
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
            >
              ×
            </button>
          </div>

          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <button
                onClick={prevMonth}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <ChevronLeft size={20} />
              </button>
              <h4 className="font-medium">
                {currentMonth.toLocaleDateString('pt-BR', {
                  month: 'long',
                  year: 'numeric'
                })}
              </h4>
              <button
                onClick={nextMonth}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <ChevronRight size={20} />
              </button>
            </div>

            <div className="grid grid-cols-7 gap-1">
              {weekDays.map(day => (
                <div
                  key={day}
                  className="text-center text-sm font-medium text-gray-500 py-2"
                >
                  {day}
                </div>
              ))}
              
              {days.map((date, index) => {
                if (!date) {
                  return <div key={`empty-${index}`} />;
                }

                const plan = getPlanForDate(date);
                const isSelected = selectedDate && 
                  date.getDate() === selectedDate.getDate() &&
                  date.getMonth() === selectedDate.getMonth() &&
                  date.getFullYear() === selectedDate.getFullYear();
                const isToday = date.toDateString() === new Date().toDateString();
                const isDisabled = date < dateRange.start || !plan;
                const isHovered = hoveredDate && 
                  date.getDate() === hoveredDate.getDate() &&
                  date.getMonth() === hoveredDate.getMonth() &&
                  date.getFullYear() === hoveredDate.getFullYear();

                return (
                  <button
                    key={date.getTime()}
                    onClick={() => handleDateClick(date)}
                    onMouseEnter={() => setHoveredDate(date)}
                    onMouseLeave={() => setHoveredDate(null)}
                    disabled={isDisabled}
                    className={`aspect-square p-2 rounded-lg relative ${
                      date < dateRange.start || date > dateRange.end
                        ? 'opacity-50 cursor-not-allowed'
                        : plan
                        ? 'hover:bg-primary-100 cursor-pointer transition-colors duration-200'
                        : 'cursor-default'
                    } ${
                      isSelected
                        ? 'bg-primary-500 text-white shadow-lg ring-2 ring-primary-300'
                        : isToday
                        ? 'bg-primary-50 font-bold'
                        : 'text-gray-700'
                    }`}
                  >
                    <span className={`text-sm font-medium ${isToday ? 'text-primary-700' : ''}`}>
                      {date.getDate()}
                    </span>
                    {plan && (
                      <div className={`absolute bottom-1 left-1/2 -translate-x-1/2 flex items-center gap-1 transition-all duration-200 ${
                        isHovered ? 'transform scale-110' : ''
                      }`}>
                        {plan.dailyStats && (
                          <div className="flex items-center gap-1">
                            <span className={`text-[10px] font-medium ${
                              isSelected ? 'text-white' : 'text-primary-500'
                            }`}>
                              {Math.round((plan.dailyStats.caloriesConsumed / plan.totalCalories) * 100)}%
                            </span>
                          </div>
                        )}
                        {plan.completedMeals?.length > 0 && (
                          <Star 
                            size={10} 
                            className={`${
                              isSelected 
                                ? 'fill-white text-white' 
                                : 'fill-primary-500 text-primary-500'
                            } ${isHovered ? 'animate-pulse' : ''}`} 
                          />
                        )}
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          isSelected ? 'bg-white' : 'bg-primary-500'
                        }`} />
                      </div>
                    )}
                    {plan && isHovered && (
                      <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-xs py-1 px-2 rounded whitespace-nowrap z-10">
                        {plan.completedMeals?.length || 0} refeições • {Math.round(plan.dailyStats?.caloriesConsumed || 0)} kcal
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Stats Summary */}
          <div className="grid grid-cols-3 gap-4 mb-6 bg-gray-50 p-4 rounded-2xl">
            <div className="text-center p-3 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <p className="text-sm text-gray-600">Total de Dias</p>
              <p className="text-lg font-semibold">{stats.totalDays}</p>
            </div>
            <div className="text-center p-3 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <p className="text-sm text-gray-600">Dias Completos</p>
              <p className="text-lg font-semibold">{stats.completedDays}</p>
            </div>
            <div className="text-center p-3 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <p className="text-sm text-gray-600">Média Calorias</p>
              <p className="text-lg font-semibold">{stats.averageCalories}</p>
            </div>
          </div>

          <div className="flex items-center justify-center gap-4 text-sm text-gray-500 mt-6">
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 bg-primary-500 rounded-full"></span>
              <span>Plano salvo</span>
            </div>
            <div className="flex items-center gap-1">
              <Star size={12} className="fill-primary-500 text-primary-500" />
              <span>Refeições completas</span>
            </div>
          </div>
          <p className="text-sm text-gray-500 text-center mt-2">
            {showingCurrentPlan ? (
              'Volte ao histórico para ver outros dias'
            ) : (
              'Histórico limitado aos últimos 120 dias'
            )}
          </p>
        </div>
      </div>
    </div>
  );
}

export default DietCalendar;