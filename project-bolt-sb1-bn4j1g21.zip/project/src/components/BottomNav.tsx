import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, Utensils, Target, MessageSquare, User } from 'lucide-react';

function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  
  const navItems = [
    { path: '/dashboard', icon: Home, label: 'Inicio' },
    { path: '/diet', icon: Utensils, label: 'Dieta' },
    { path: '/goals', icon: Target, label: 'Metas' },
    { path: '/chat', icon: MessageSquare, label: 'Chat' },
    { path: '/profile', icon: User, label: 'Perfil' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bottom-nav z-50">
      <div className="flex justify-around items-center h-16 max-w-lg mx-auto px-2">
        {navItems.map(({ path, icon: Icon, label }) => {
          const isActive = location.pathname === path;
          return (
            <button
              key={path}
              onClick={() => navigate(path)}
              className={`
                relative flex flex-col items-center justify-center 
                min-w-[64px] h-full touch-feedback
                ${isActive ? 'text-primary-500' : 'text-gray-500'}
              `}
            >
              {/* Active Indicator */}
              {isActive && (
                <span className="absolute -top-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary-500" />
              )}

              {/* Icon */}
              <div className={`relative ${isActive ? 'scale-110 animate-bounce-subtle' : ''}`}>
                <Icon size={24} strokeWidth={isActive ? 2.5 : 2} />
                
                {/* Ripple Effect */}
                <span className={`
                  absolute inset-0 rounded-full bg-primary-100 opacity-0
                  ${isActive ? 'animate-ping' : ''}
                `} />
              </div>

              {/* Label */}
              <span className={`
                text-xs mt-1 font-medium transition-all
                ${isActive ? 'opacity-100 transform translate-y-0' : 'opacity-70 transform translate-y-0.5'}
              `}>
                {label}
              </span>
            </button>
          );
        })}
      </div>

      {/* Safe Area Spacer */}
      <div className="h-[env(safe-area-inset-bottom)]" />
    </nav>
  );
}

export default BottomNav;