import React, { useState, useEffect } from 'react';
import { Wifi, WifiOff, Loader2 } from 'lucide-react';
import { db } from '../lib/firebase';
import { enableNetwork, disableNetwork } from 'firebase/firestore';

function NetworkStatus() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isReconnecting, setIsReconnecting] = useState(false);
  const [showStatus, setShowStatus] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [hideTimeout, setHideTimeout] = useState<NodeJS.Timeout>();
  const MAX_RETRIES = 3;
  const RETRY_DELAY = 2000;
  const BACKOFF_FACTOR = 2;

  useEffect(() => {
    const handleOnline = async () => {
      setIsReconnecting(true);
      setRetryCount(0);
      try {
        const delay = RETRY_DELAY * Math.pow(BACKOFF_FACTOR, retryCount);
        await enableNetwork(db);
        setIsOnline(true);
        setShowStatus(true);
        
        const timeout = setTimeout(() => setShowStatus(false), 3000);
        setHideTimeout(timeout);
      } catch (error) {
        console.error('Error reconnecting:', error);
        if (retryCount < MAX_RETRIES) {
          setRetryCount(prev => prev + 1);
          setTimeout(handleOnline, delay + Math.random() * 1000);
        }
      } finally {
        setIsReconnecting(false);
      }
    };

    const handleOffline = async () => {
      try {
        await disableNetwork(db);
      } catch (error) {
        console.error('Error disabling network:', error);
      }
      setIsOnline(false);
      setShowStatus(true);
      if (hideTimeout) {
        clearTimeout(hideTimeout);
      }
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial check
    if (!navigator.onLine) {
      handleOffline();
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      if (hideTimeout) {
        clearTimeout(hideTimeout);
      }
    };
  }, []);

  if (!showStatus) return null;

  return (
    <div className={`fixed bottom-20 left-1/2 -translate-x-1/2 px-4 py-2 rounded-full shadow-lg transition-all duration-300 animate-fade-in ${
      isOnline ? 'bg-green-500' : isReconnecting ? 'bg-yellow-500' : 'bg-red-500'
    } z-50`}>
      <div className="flex items-center gap-2 text-white font-medium">
        {isReconnecting ? (
          <>
            <Loader2 size={16} className="animate-spin" />
            <span>Reconectando...</span>
          </>
        ) : isOnline ? (
          <>
            <Wifi size={16} />
            <span>Conexão restaurada</span>
          </>
        ) : (
          <>
            <WifiOff size={16} />
            <span>Sem conexão</span>
          </>
        )}
        {!isOnline && (
          <div className="text-sm opacity-80 ml-2">
            {isReconnecting ? (
              'Tentando reconectar...'
            ) : (
              'Alterações serão sincronizadas quando voltar'
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default NetworkStatus;