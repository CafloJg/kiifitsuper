import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Check, ShoppingCart, ArrowUpDown, Search } from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { doc, updateDoc, getDoc } from 'firebase/firestore';

interface ShoppingItem {
  id: string;
  name: string;
  category: string;
  checked: boolean;
  quantity?: string;
}

interface ShoppingList {
  items: ShoppingItem[];
  lastUpdated: Date;
}

const CATEGORIES = [
  'Proteínas',
  'Vegetais',
  'Frutas',
  'Grãos',
  'Laticínios',
  'Temperos',
  'Outros'
];

function ShoppingList() {
  const [items, setItems] = useState<ShoppingItem[]>([]);
  const [newItem, setNewItem] = useState('');
  const [newItemCategory, setNewItemCategory] = useState('Outros');
  const [newItemQuantity, setNewItemQuantity] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [sortBy, setSortBy] = useState<'category' | 'name' | 'status'>('category');
  const [error, setError] = useState('');

  useEffect(() => {
    loadShoppingList();
  }, []);

  const loadShoppingList = async () => {
    if (!auth.currentUser) return;

    try {
      const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
      if (userDoc.exists() && userDoc.data().shoppingList) {
        setItems(userDoc.data().shoppingList.items || []);
      }
    } catch (error) {
      console.error('Erro ao carregar lista:', error);
      setError('Erro ao carregar sua lista de compras');
    } finally {
      setIsLoading(false);
    }
  };

  const saveShoppingList = async (newItems: ShoppingItem[]) => {
    if (!auth.currentUser) return;

    try {
      await updateDoc(doc(db, 'users', auth.currentUser.uid), {
        shoppingList: {
          items: newItems,
          lastUpdated: new Date()
        }
      });
    } catch (error) {
      console.error('Erro ao salvar lista:', error);
      setError('Erro ao salvar alterações');
    }
  };

  const addItem = async () => {
    if (!newItem.trim()) return;

    const item: ShoppingItem = {
      id: Date.now().toString(),
      name: newItem.trim(),
      category: newItemCategory,
      checked: false,
      quantity: newItemQuantity.trim() || undefined
    };

    const updatedItems = [...items, item];
    setItems(updatedItems);
    await saveShoppingList(updatedItems);
    
    setNewItem('');
    setNewItemQuantity('');
    setNewItemCategory('Outros');
  };

  const toggleItem = async (id: string) => {
    const updatedItems = items.map(item =>
      item.id === id ? { ...item, checked: !item.checked } : item
    );
    setItems(updatedItems);
    await saveShoppingList(updatedItems);
  };

  const removeItem = async (id: string) => {
    const updatedItems = items.filter(item => item.id !== id);
    setItems(updatedItems);
    await saveShoppingList(updatedItems);
  };

  const clearCheckedItems = async () => {
    const updatedItems = items.filter(item => !item.checked);
    setItems(updatedItems);
    await saveShoppingList(updatedItems);
  };

  const getSortedAndFilteredItems = () => {
    let filteredItems = items;
    
    if (filter) {
      filteredItems = items.filter(item =>
        item.name.toLowerCase().includes(filter.toLowerCase()) ||
        item.category.toLowerCase().includes(filter.toLowerCase())
      );
    }

    return filteredItems.sort((a, b) => {
      switch (sortBy) {
        case 'category':
          return a.category.localeCompare(b.category);
        case 'name':
          return a.name.localeCompare(b.name);
        case 'status':
          return Number(a.checked) - Number(b.checked);
        default:
          return 0;
      }
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="ptr-indicator animate-spin" />
      </div>
    );
  }

  return (
    <div className="mobile-card">
      {/* Header */}
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-primary-50 rounded-xl flex items-center justify-center">
              <ShoppingCart className="text-primary-500" size={24} />
            </div>
            <div>
              <h2 className="text-lg font-semibold">Lista de Compras</h2>
              <p className="text-sm text-gray-500">
                {items.length} {items.length === 1 ? 'item' : 'itens'} •{' '}
                {items.filter(i => i.checked).length} marcados
              </p>
            </div>
          </div>
          {items.some(i => i.checked) && (
            <button
              onClick={clearCheckedItems}
              className="text-red-500 hover:text-red-600 text-sm touch-feedback"
            >
              Limpar marcados
            </button>
          )}
        </div>

        {/* Add Item Form */}
        <div className="flex flex-col gap-3">
          <div className="flex gap-3">
            <div className="flex-1">
              <input
                type="text"
                value={newItem}
                onChange={(e) => setNewItem(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addItem()}
                placeholder="Adicionar item..."
                className="mobile-input"
              />
            </div>
            <button
              onClick={addItem}
              disabled={!newItem.trim()}
              className="p-3 bg-primary-500 text-white rounded-xl hover:bg-primary-600 transition-colors disabled:opacity-50 touch-feedback"
            >
              <Plus size={24} />
            </button>
          </div>
          <div className="flex gap-3">
            <input
              type="text"
              value={newItemQuantity}
              onChange={(e) => setNewItemQuantity(e.target.value)}
              placeholder="Qtd"
              className="w-24 mobile-input"
            />
            <select
              value={newItemCategory}
              onChange={(e) => setNewItemCategory(e.target.value)}
              className="flex-1 mobile-input"
            >
              {CATEGORIES.map(category => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="p-4 bg-gray-50 border-b border-gray-100">
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <Search size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              placeholder="Buscar itens..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          <button
            onClick={() => setSortBy(prev => 
              prev === 'category' ? 'name' : 
              prev === 'name' ? 'status' : 'category'
            )}
            className="flex items-center gap-2 px-4 py-2 bg-white rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 touch-feedback"
          >
            <ArrowUpDown size={16} />
            <span className="text-sm">
              {sortBy === 'category' ? 'Categoria' : 
               sortBy === 'name' ? 'Nome' : 'Status'}
            </span>
          </button>
        </div>
      </div>

      {/* Items List */}
      <div className="mobile-list">
        {getSortedAndFilteredItems().map(item => (
          <div
            key={item.id}
            className={`mobile-list-item flex items-center gap-4 ${
              item.checked ? 'bg-gray-50' : ''
            }`}
          >
            <button
              onClick={() => toggleItem(item.id)}
              className={`w-6 h-6 rounded-full border-2 flex items-center justify-center touch-feedback ${
                item.checked
                  ? 'bg-primary-500 border-primary-500'
                  : 'border-gray-300'
              }`}
            >
              {item.checked && <Check size={14} className="text-white" />}
            </button>
            <div className="flex-1">
              <p className={`font-medium ${item.checked ? 'line-through text-gray-400' : ''}`}>
                {item.name}
                {item.quantity && (
                  <span className="text-sm text-gray-500 ml-2">
                    ({item.quantity})
                  </span>
                )}
              </p>
              <p className="text-sm text-gray-500">{item.category}</p>
            </div>
            <button
              onClick={() => removeItem(item.id)}
              className="p-2 text-gray-400 hover:text-red-500 rounded-lg hover:bg-red-50 transition-colors touch-feedback"
            >
              <Trash2 size={20} />
            </button>
          </div>
        ))}

        {items.length === 0 && (
          <div className="p-8 text-center text-gray-500">
            <ShoppingCart size={48} className="mx-auto mb-4 text-gray-300" />
            <p>Sua lista está vazia</p>
            <p className="text-sm">Adicione itens usando o campo acima</p>
          </div>
        )}
      </div>

      {error && (
        <div className="p-4 bg-red-50 text-red-500 text-center">
          {error}
        </div>
      )}
    </div>
  );
}

export default ShoppingList;