import React, { useEffect, useRef, useState } from 'react';
import { Camera, X, Loader2, AlertCircle, RefreshCw, Sparkles, Utensils } from 'lucide-react';
import { analyzeImageWithGoogleVision } from '../lib/vision';
import type { FoodAnalysis } from '../types/food';

interface ARCameraProps {
  onClose: () => void;
  onAnalysis: (analysis: FoodAnalysis) => void;
}

function ARCamera({ onClose, onAnalysis }: ARCameraProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isActive, setIsActive] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [analysisProgress, setAnalysisProgress] = useState<string>('');
  const [currentCamera, setCurrentCamera] = useState<'environment' | 'user'>('environment');
  const [imageCache, setImageCache] = useState<Map<string, FoodAnalysis>>(new Map());
  const [connectionStatus, setConnectionStatus] = useState<'online' | 'offline' | 'slow'>('online');
  const [lastAttemptTime, setLastAttemptTime] = useState<number>(0);
  const [showPreview, setShowPreview] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const RETRY_COOLDOWN = 5000; // 5 seconds between retries
  
  const handleAnalysisError = (error: unknown) => {
    let errorMessage = 'Erro ao analisar imagem. Tente novamente.';
    
    if (error instanceof Error && error.message) {
      // Handle specific error messages from OpenAI API
      if (error.message.includes('rate limit')) {
        errorMessage = 'Muitas solicitações. Aguarde um momento e tente novamente.';
      } else if (error.message.includes('quota')) {
        errorMessage = 'Serviço temporariamente indisponível. Tente novamente mais tarde.';
      } else if (error.message.includes('invalid api key')) {
        errorMessage = 'Erro de configuração. Entre em contato com o suporte.';
      } else if (error.message.includes('context length')) {
        errorMessage = 'Imagem muito complexa. Tente uma foto mais simples.';
      } else if (error.message.includes('API key not valid')) {
        errorMessage = 'Erro de configuração. Tentando método alternativo...';
      } else if (error.message.includes('Failed to fetch') || 
                 error.message.includes('network error')) {
        errorMessage = 'Erro de conexão. Verifique sua internet e tente novamente.';
      } else if (error.message.includes('timeout')) {
        errorMessage = 'A análise está demorando muito. Tente uma foto mais simples.';
      } else {
        // Use the error message directly if it's from our controlled error handling
        errorMessage = error.message;
        // Don't show internal errors to user
        if (errorMessage.includes('internal')) {
          errorMessage = 'Erro ao analisar imagem. Tentando método alternativo...';
        }
      }
    }
    
    setError(errorMessage);
    // Clear error after 3 seconds if it's a fallback message
    if (errorMessage.includes('alternativo')) {
      setTimeout(() => setError(''), 3000);
    }
  };

  // Network status monitoring
  useEffect(() => {
    const handleOnline = () => setConnectionStatus('online');
    const handleOffline = () => setConnectionStatus('offline');
    const checkConnection = async () => {
      try {
        const start = performance.now();
        const response = await fetch('https://api.openai.com/v1/models');
        const end = performance.now(); 
        const latency = end - start;
        
        setConnectionStatus(latency > 2000 ? 'slow' : 'online');
      } catch (error) {
        setConnectionStatus('offline');
      }
    };
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    // Check connection every 30 seconds
    const intervalId = setInterval(checkConnection, 30000);
    checkConnection();

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(intervalId);
    };
  }, []);

  // Camera initialization
  useEffect(() => {
    let retryCount = 0;
    const maxRetries = 3;

    const startCamera = async () => {
      if (!videoRef.current) return;
      
      try {
        setError(null);
        const constraints = {
          video: {
            facingMode: currentCamera,
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        };

        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play();
          setIsActive(true);
        };
      } catch (error) {
        console.error('Erro ao acessar câmera:', error);
        
        if (retryCount < maxRetries) {
          retryCount++;
          setTimeout(startCamera, 1000);
          return;
        }

        setError(
          error instanceof Error && error.message.includes('Permission denied')
            ? 'Permissão da câmera negada. Por favor, permita o acesso à câmera.'
            : 'Não foi possível acessar a câmera. Verifique as permissões.'
        );
      }
    };

    startCamera();

    return () => {
      if (videoRef.current?.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach(track => track.stop());
      }
    };
  }, [currentCamera]);

  // Camera controls
  const switchCamera = async () => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
    }
    setCurrentCamera(prev => prev === 'environment' ? 'user' : 'environment');
  };

  // Image capture and analysis
  const captureAndAnalyze = async () => {
    if (!videoRef.current || !canvasRef.current || !isActive || isAnalyzing) {
      setError('Câmera não está pronta. Tente novamente.');
      return;
    }
    
    const now = Date.now();
    if (now - lastAttemptTime < RETRY_COOLDOWN) {
      setError('Aguarde alguns segundos antes de tentar novamente.');
      return;
    }
    setLastAttemptTime(now);

    if (connectionStatus === 'offline') {
      setError('Sem conexão com a internet. Verifique sua conexão.');
      return;
    }

    if (connectionStatus === 'slow') {
      setError('Conexão lenta. A análise pode demorar mais que o normal.');
      return;
    }

    const MAX_IMAGE_SIZE = 4 * 1024 * 1024; // 4MB
    setIsAnalyzing(true);
    setError(null);
    setAnalysisProgress('Capturando imagem...');

    try { 
      const context = canvasRef.current.getContext('2d');
      if (!context) {
        throw new Error('Não foi possível inicializar o contexto de canvas');
      }
      context.save();

      // Adjust canvas dimensions to match video with proper scaling
      const { videoWidth, videoHeight } = videoRef.current; 
      const maxDimension = 1280; // Maximum dimension for better performance
      const scale = Math.min(1, maxDimension / Math.max(videoWidth, videoHeight));
      
      canvasRef.current.width = videoWidth * scale;
      canvasRef.current.height = videoHeight * scale;

      // Capture video frame with proper scaling
      if (currentCamera === 'user') {
        context.scale(-1, 1);
        context.translate(-canvasRef.current.width, 0);
      }

      context.drawImage(
        videoRef.current,
        0, 0,
        canvasRef.current.width,
        canvasRef.current.height
      );
      context.restore();

      // Convert canvas to base64 with optimized quality and compression
      const imageData = canvasRef.current.toDataURL('image/jpeg', 0.85);
      setAnalysisProgress('Analisando alimentos...');
      
      // Analyze image and get ingredients
      try {
        const analysis = await analyzeImageWithGoogleVision(imageData);
        
        if (!analysis?.ingredients?.length) {
          throw new Error('Nenhum alimento detectado na imagem. Tente uma foto mais clara ou de outro ângulo.');
        }

        // Pass complete analysis to parent component
        onAnalysis(analysis);
        onClose();
      } catch (error) {
        console.error('Erro na análise:', error);
        handleAnalysisError(error);
      }
    } catch (error) {
      console.error('Erro ao analisar imagem:', error);
      handleAnalysisError(error);
    } finally {
      setIsAnalyzing(false);
      setAnalysisProgress('');
    }
  };

  const captureImage = async () => {
    if (!videoRef.current || !canvasRef.current || !isActive) return;

    try {
      const context = canvasRef.current.getContext('2d');
      if (!context) throw new Error('Não foi possível inicializar o contexto de canvas');

      // Optimize image capture
      const { videoWidth, videoHeight } = videoRef.current; 
      const maxDimension = 1280; // Maximum dimension for better performance
      const scale = Math.min(1, maxDimension / Math.max(videoWidth, videoHeight));
      
      canvasRef.current.width = videoWidth * scale;
      canvasRef.current.height = videoHeight * scale;

      // Apply image processing for better results
      context.filter = 'contrast(1.2) brightness(1.1) saturate(1.2)';
      context.drawImage(
        videoRef.current, 
        0, 0, 
        canvasRef.current.width, 
        canvasRef.current.height
      );
      context.filter = 'none';

      // Optimize image quality and compression
      const imageData = canvasRef.current.toDataURL('image/jpeg', 0.85);
      setCapturedImage(imageData);
      setShowPreview(true);
    } catch (error) {
      console.error('Erro ao capturar imagem:', error);
      setError('Erro ao capturar imagem. Tente novamente.');
    }
  };

  return (
    <div className="fixed inset-0 bg-black z-50">
      <div className="relative h-full">
        {/* Header Bar */}
        <div className="absolute top-0 inset-x-0 p-4 z-10 animate-fade-in">
          <div className="max-w-lg mx-auto bg-black/50 backdrop-blur-md rounded-3xl p-3 flex items-center justify-between border border-white/10">
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-white/10 text-white transition-all active:scale-95 disabled:opacity-50"
              disabled={isAnalyzing}
            >
              <X size={24} />
            </button>
            <span className="text-white font-medium tracking-wide">
              {isAnalyzing ? analysisProgress : 'Analisar Alimentos'}
            </span>
            <button
              onClick={switchCamera}
              className="p-2 rounded-full hover:bg-white/10 text-white transition-all active:scale-95 disabled:opacity-50"
              disabled={isAnalyzing}
            >
              <RefreshCw size={24} className={isAnalyzing ? 'opacity-50' : ''} />
            </button>
          </div>
        </div>

        {error ? (
          <div className="absolute inset-0 flex items-center justify-center p-4">
            <div className="bg-black/50 backdrop-blur-md rounded-3xl p-8 max-w-sm w-full border border-white/10 animate-scale-in">
              <div className="flex flex-col items-center text-center space-y-4">
                <AlertCircle size={48} className="text-red-500" />
                <p className="text-white">{error}</p>
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      if (connectionStatus !== 'online') {
                        setError(null);
                        return;
                      }
                      onClose();
                    }}
                    className="px-6 py-3 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-all active:scale-95 backdrop-blur-sm"
                  >
                    {connectionStatus !== 'online' ? 'Tentar Novamente' : 'Fechar'}
                  </button>
                  <button
                    onClick={() => {
                      setError(null);
                      setIsActive(false);
                      setLastAttemptTime(0);
                      if (videoRef.current?.srcObject) {
                        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
                        tracks.forEach(track => track.stop());
                      }
                      setTimeout(() => {
                        location.reload();
                      }, 500);
                    }}
                    className="px-6 py-3 bg-white text-black rounded-xl hover:bg-white/90 transition-all active:scale-95 font-medium"
                  >
                    Tentar Novamente
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              style={{
                transform: currentCamera === 'user' ? 'scaleX(-1)' : 'none'
              }}
              className={`w-full h-full object-cover animate-fade-in ${showPreview ? 'hidden' : ''}`}
              muted
            />
            
            {showPreview && capturedImage && (
              <div className="relative w-full h-full">
                <img 
                  src={capturedImage} 
                  alt="Preview" 
                  className="w-full h-full object-cover animate-scale-in bg-black"
                  style={{
                    transform: currentCamera === 'user' ? 'scaleX(-1)' : 'none'
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent">
                  <div className="absolute bottom-0 inset-x-0 p-8 text-white">
                    <div className="flex items-center gap-3 mb-4">
                      <Utensils className="text-primary-500" size={24} />
                      <h3 className="text-xl font-medium">Confirmar Análise</h3>
                    </div>
                    <p className="text-white/80 mb-6">
                      A imagem está clara e o alimento está bem visível?
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            <canvas
              ref={canvasRef}
              className="hidden"
              width="1280"
              height="720"
            />

            {/* Camera Controls */}
            <div className="absolute bottom-0 inset-x-0 p-6 animate-slide-up">
              <div className="max-w-lg mx-auto">
                <div className="bg-black/50 backdrop-blur-md rounded-3xl p-6 border border-white/10 shadow-lg">
                  {isAnalyzing ? (
                    <div className="flex items-center justify-center h-14 space-x-3">
                      <Loader2 size={28} className="animate-spin text-white" />
                      <span className="text-white font-medium">{analysisProgress}</span>
                    </div>
                  ) : (
                    <button
                      onClick={showPreview ? captureAndAnalyze : captureImage}
                      className="relative w-full h-14 bg-white text-black font-medium rounded-2xl flex items-center justify-center space-x-3 disabled:opacity-50 transition-all hover:bg-white/90 active:scale-[0.98] disabled:cursor-not-allowed"
                      disabled={!isActive || isAnalyzing || (showPreview && !capturedImage)}
                    >
                      {showPreview ? (
                        <>
                          <Sparkles size={24} strokeWidth={2.5} />
                          <span className="text-lg">Analisar Alimentos</span>
                        </>
                      ) : (
                        <>
                          <Camera size={24} strokeWidth={2.5} />
                          <span className="text-lg">Capturar</span>
                        </>
                      )}
                      {/* Focus ring effect */}
                      <div className="absolute inset-0 rounded-2xl ring-4 ring-white ring-opacity-25 pointer-events-none" />
                    </button>
                  )}
                  
                  {showPreview && (
                    <button
                      onClick={() => {
                        setShowPreview(false);
                        setCapturedImage(null);
                      }}
                      className="w-full mt-3 py-3 text-white/80 hover:text-white transition-colors"
                    >
                      Tirar Nova Foto
                    </button>
                  )}
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default ARCamera;