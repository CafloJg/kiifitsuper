import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts'; 
import { Activity, TrendingUp, Target, Award, ChevronDown, ChevronUp } from 'lucide-react';
import type { DietPlan } from '../types/user';

interface DietProgressProps extends React.PropsWithChildren {
  plans: DietPlan[];
  days?: number;
  completedMeals?: string[];
  currentPlan: DietPlan | null;
  onUpdate?: () => void;
}

function DietProgress({ plans, days = 7, completedMeals, currentPlan, onUpdate }: DietProgressProps) {
  const [showWeeklyProgress, setShowWeeklyProgress] = useState(false);

  // Sort plans by date and get the last N days
  const sortedPlans = [...plans]
    .sort((a, b) => new Date(b.date || b.createdAt).getTime() - new Date(a.date || a.createdAt).getTime())
    .slice(0, days)
    .reverse(); // Reverse to show oldest to newest

  // Get today's plan and stats
  const today = new Date().toISOString().split('T')[0];
  const todayPlan = currentPlan;
  const todayMeals = todayPlan?.dailyStats?.completedMeals?.[today] || completedMeals || [];
  
  // Calculate total macros from completed meals
  const completedMealMacros = todayPlan?.meals
    .filter(meal => todayMeals.includes(meal.id))
    .reduce((acc, meal) => ({
      calories: acc.calories + meal.calories,
      protein: acc.protein + meal.protein,
      carbs: acc.carbs + meal.carbs,
      fat: acc.fat + meal.fat
    }), {
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0
    });

  const todayStats = {
    totalMeals: todayPlan?.meals.length || 0,
    completedMeals: todayMeals.length,
    nextMeal: todayPlan?.meals.find(meal => !todayMeals.includes(meal.id)),
    calories: completedMealMacros?.calories || 0,
    protein: completedMealMacros?.protein || 0,
    carbs: completedMealMacros?.carbs || 0,
    fat: completedMealMacros?.fat || 0,
    macroDistribution: todayPlan?.dailyStats?.macroDistribution || {
      protein: 0,
      carbs: 0,
      fat: 0
    },
    target: todayPlan?.totalCalories || 0,
    progress: todayPlan ? 
      Math.round((completedMealMacros?.calories || 0) / todayPlan.totalCalories * 100) : 0
  };

  const chartData = sortedPlans.map(plan => ({
    date: new Date(plan.date || plan.createdAt).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit'
    }),
    calories: plan === todayPlan ? completedMealMacros?.calories || 0 : plan.dailyStats?.caloriesConsumed || 0,
    protein: plan === todayPlan ? completedMealMacros?.protein || 0 : plan.dailyStats?.proteinConsumed || 0,
    carbs: plan === todayPlan ? completedMealMacros?.carbs || 0 : plan.dailyStats?.carbsConsumed || 0,
    fat: plan === todayPlan ? completedMealMacros?.fat || 0 : plan.dailyStats?.fatConsumed || 0,
    macroDistribution: plan === todayPlan ? todayStats.macroDistribution : plan.dailyStats?.macroDistribution || {
      protein: 0,
      carbs: 0,
      fat: 0
    },
    target: plan.totalCalories,
    proteinTarget: plan.proteinTarget,
    carbsTarget: plan.carbsTarget,
    fatTarget: plan.fatTarget,
    completedMeals: plan === todayPlan ? todayMeals.length : plan.completedMeals?.length || 0
  }));

  // Calculate targets from current plan
  const targets = {
    calories: todayPlan?.totalCalories || 2000,
    protein: todayPlan?.proteinTarget || 150,
    carbs: todayPlan?.carbsTarget || 250,
    fat: todayPlan?.fatTarget || 70
  };

  // Calculate averages and streaks
  const stats = chartData.reduce((acc, day) => ({
    calories: acc.calories + day.calories,
    protein: acc.protein + day.protein,
    carbs: acc.carbs + day.carbs,
    fat: acc.fat + day.fat,
    onTarget: acc.onTarget + (day.completedMeals > 0 ? 1 : 0),
    streak: day.completedMeals > 0 ? acc.streak + 1 : 0
  }), {
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0,
    onTarget: 0,
    streak: 0
  });

  const averages = {
    calories: Math.round(stats.calories / chartData.length),
    protein: Math.round(stats.protein / chartData.length),
    carbs: Math.round(stats.carbs / chartData.length),
    fat: Math.round(stats.fat / chartData.length),
    adherence: Math.round((stats.onTarget / chartData.length) * 100),
    streak: stats.streak
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload) return null;

    return (
      <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-100">
        <p className="font-medium mb-2">{label}</p>
        <div className="space-y-1">
          <p className="text-sm">
            <span className="text-primary-500">●</span> Consumido: {payload[0]?.value.toLocaleString()} kcal
          </p>
          <p className="text-sm">
            <span className="text-gray-300">●</span> Meta: {payload[1]?.value.toLocaleString()} kcal
          </p>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-medium">Progresso da Dieta</h2>
          <p className="text-sm text-gray-500 flex items-center gap-2">
            <span>{todayStats.completedMeals} de {todayStats.totalMeals} refeições</span>
            <span>•</span>
            <span>{todayStats.calories} / {todayStats.target} kcal</span>
          </p>
        </div>
        <div className="flex items-center gap-2 bg-primary-50 px-3 py-1 rounded-full">
          <Award className="text-primary-500" size={16} />
          <span className="text-sm font-medium text-primary-500">
            {averages.streak} dias na meta
          </span>
        </div>
      </div>

      {/* Today's Progress */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-600">Progresso de Hoje</span>
          <span className="text-sm font-medium">
            {todayStats.progress}%
          </span>
        </div>
        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
          <div 
            className="h-full bg-primary-500 transition-all duration-300"
            style={{ 
              width: `${todayStats.progress}%` 
            }}
          />
        </div>
        {todayStats.nextMeal && (
          <p className="text-sm text-gray-500 mt-2">
            Próxima refeição: {' '}
            <span className="font-medium text-primary-500">
              {todayStats.nextMeal.name} ({todayStats.nextMeal.time})
            </span>
          </p>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="bg-gradient-to-br from-primary-500 to-secondary-500 rounded-2xl p-6 text-white">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
              <Activity size={24} />
            </div>
            <div className="flex-1">
              <p className="text-sm opacity-80">Calorias Diárias</p>
              <p className="text-2xl font-semibold">{todayStats.calories.toLocaleString()}</p>
              <p className="text-sm opacity-80">de {todayStats.target} kcal</p>
            </div>
          </div>
          <div className="h-[60px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorCalories" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FFFFFF" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#FFFFFF" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Area
                  type="monotone"
                  dataKey="calories"
                  stroke="#FFFFFF"
                  fillOpacity={1}
                  fill="url(#colorCalories)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-6 text-white">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
              <TrendingUp size={24} />
            </div>
            <div className="flex-1">
              <p className="text-sm opacity-80">Proteína Diária</p>
              <p className="text-2xl font-semibold">{todayStats.protein}g</p>
              <p className="text-sm opacity-80">média consumida</p>
            </div>
          </div>
          <div className="h-[60px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorProtein" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FFFFFF" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#FFFFFF" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Area
                  type="monotone"
                  dataKey="protein"
                  stroke="#FFFFFF"
                  fillOpacity={1}
                  fill="url(#colorProtein)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Macros Distribution */}
      <div className="mb-6">
        <h3 className="text-sm font-medium text-gray-700 mb-4">Distribuição de Macros</h3>
        <div className="grid grid-cols-3 gap-6">
          <div className="bg-black/5 backdrop-blur-lg rounded-2xl p-4 relative overflow-hidden">
            <div className="flex flex-col">
              <span className="text-sm text-gray-600">Proteínas</span>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-semibold">{todayStats.protein}</span>
                <span className="text-sm text-gray-500">g</span>
              </div>
              <div className="absolute -bottom-2 -left-2 -right-2">
                <ResponsiveContainer width="100%" height={40}>
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="proteinGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#F840BA" stopOpacity={0.2} />
                        <stop offset="100%" stopColor="#F840BA" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <Area
                      type="monotone"
                      dataKey="protein"
                      stroke="#F840BA"
                      strokeWidth={1.5}
                      fill="url(#proteinGradient)"
                      dot={false}
                      activeDot={false}
                      isAnimationActive={false}
                      baseValue={0}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
          
          <div className="bg-black/5 backdrop-blur-lg rounded-2xl p-4 relative overflow-hidden">
            <div className="flex flex-col">
              <span className="text-sm text-gray-600">Carboidratos</span>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-semibold">{todayStats.carbs}</span>
                <span className="text-sm text-gray-500">g</span>
              </div>
              <div className="absolute -bottom-2 -left-2 -right-2">
                <ResponsiveContainer width="100%" height={40}>
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="carbsGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#EE8B60" stopOpacity={0.2} />
                        <stop offset="100%" stopColor="#EE8B60" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <Area
                      type="monotone"
                      dataKey="carbs"
                      stroke="#EE8B60"
                      strokeWidth={1.5}
                      fill="url(#carbsGradient)"
                      dot={false}
                      activeDot={false}
                      isAnimationActive={false}
                      baseValue={0}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
          
          <div className="bg-black/5 backdrop-blur-lg rounded-2xl p-4 relative overflow-hidden">
            <div className="flex flex-col">
              <span className="text-sm text-gray-600">Gorduras</span>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-semibold">{todayStats.fat}</span>
                <span className="text-sm text-gray-500">g</span>
              </div>
              <div className="absolute -bottom-2 -left-2 -right-2">
                <ResponsiveContainer width="100%" height={40}>
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="fatGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#9CA3AF" stopOpacity={0.2} />
                        <stop offset="100%" stopColor="#9CA3AF" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <Area
                      type="monotone"
                      dataKey="fat"
                      stroke="#9CA3AF"
                      strokeWidth={1.5}
                      fill="url(#fatGradient)"
                      dot={false}
                      activeDot={false}
                      isAnimationActive={false}
                      baseValue={0}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Weekly Progress */}
      <div className="pt-4 border-t border-gray-100 space-y-4">
        <button
          onClick={() => setShowWeeklyProgress(!showWeeklyProgress)}
          className="w-full flex items-center justify-between text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors"
        >
          <div className="flex items-center gap-2">
            <TrendingUp size={18} className="text-primary-500" />
            <span>Progresso Semanal</span>
          </div>
          {showWeeklyProgress ? (
            <ChevronUp size={20} className="text-gray-400" />
          ) : (
            <ChevronDown size={20} className="text-gray-400" />
          )}
        </button>

        {showWeeklyProgress && (
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center justify-end gap-2 text-sm text-gray-500">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-primary-500"></span>
                Consumido
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-gray-300"></span>
                Meta
              </span>
            </div>

            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <defs>
                    <linearGradient id="colorProgress" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#F840BA" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#F840BA" stopOpacity={0.05}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                  <XAxis 
                    dataKey="date" 
                    stroke="#9CA3AF"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    padding={{ left: 10, right: 10 }}
                  />
                  <YAxis 
                    stroke="#9CA3AF"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    width={45}
                    tickFormatter={(value) => `${value}k`}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="calories"
                    stroke="#F840BA" 
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorProgress)"
                    animationDuration={1000}
                    dot={{ r: 4, fill: "#F840BA", strokeWidth: 2, stroke: "#fff" }}
                    activeDot={{ r: 6, fill: "#F840BA", strokeWidth: 2, stroke: "#fff" }}
                  />
                  <Line
                    type="monotone"
                    dataKey="target"
                    stroke="#E5E7EB"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={false}
                    animationDuration={1000}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-3 gap-4 text-center text-sm">
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-gray-500">Média</p>
                <p className="font-semibold">{Math.round(averages.calories / 1000)}k kcal</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-gray-500">Menor</p>
                <p className="font-semibold">
                  {Math.round(Math.min(...chartData.map(d => d.calories)) / 1000)}k kcal
                </p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-gray-500">Maior</p>
                <p className="font-semibold">
                  {Math.round(Math.max(...chartData.map(d => d.calories)) / 1000)}k kcal
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default DietProgress;