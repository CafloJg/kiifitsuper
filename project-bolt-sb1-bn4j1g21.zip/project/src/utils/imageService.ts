import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { getPixabayImage } from './pixabay';

const CACHE_DURATION = 7 * 24 * 60 * 60 * 1000; // 7 days
const QUALITY_THRESHOLD = 0.8; // Higher quality threshold

// Food categories for search optimization
const FOOD_CATEGORIES = {
  proteins: ['frango', 'carne', 'peixe', 'ovo', 'queijo', 'iogurte', 'leite'],
  grains: ['arroz', 'pão', 'aveia', 'quinoa', 'tapioca', 'macarrão'],
  vegetables: ['brócolis', 'cenoura', 'alface', 'tomate', 'abobrinha'],
  fruits: ['maçã', 'banana', 'laranja', 'mamão', 'morango'],
  legumes: ['feijão', 'lentilha', 'grão de bico', 'ervilha']
};

// High-quality curated images for common foods
const CURATED_IMAGES: Record<string, { imageUrl: string; thumbnailUrl: string }> = {
  'arroz integral': {
    imageUrl: 'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6',
    thumbnailUrl: 'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?w=200'
  },
  'frango grelhado': {
    imageUrl: 'https://images.unsplash.com/photo-1532550907401-a500c9a57435',
    thumbnailUrl: 'https://images.unsplash.com/photo-1532550907401-a500c9a57435?w=200'
  },
  'salada': {
    imageUrl: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd',
    thumbnailUrl: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=200'
  },
  'ovo': {
    imageUrl: 'https://images.unsplash.com/photo-1482049016688-2d3e1b311543',
    thumbnailUrl: 'https://images.unsplash.com/photo-1482049016688-2d3e1b311543?w=200'
  }
};

function enhanceSearchTerm(query: string): string {
  const normalizedQuery = query.toLowerCase().trim();
  const baseQuality = 'professional food photography gourmet plated dish high resolution';
  
  let category = '';
  for (const [cat, terms] of Object.entries(FOOD_CATEGORIES)) {
    if (terms.some(term => normalizedQuery.includes(term))) {
      category = cat;
      break;
    }
  }
  
  let enhancedQuery = normalizedQuery + ' ' + baseQuality;
  
  switch (category) {
    case 'proteins':
      enhancedQuery += ' cooked served restaurant';
      break;
    case 'grains':
      enhancedQuery += ' cooked served plated';
      break;
    case 'vegetables':
      enhancedQuery += ' fresh organic isolated';
      break;
    case 'fruits':
      enhancedQuery += ' fresh ripe whole';
      break;
    case 'legumes':
      enhancedQuery += ' cooked isolated';
      break;
    default:
      enhancedQuery += ' food isolated';
  }
  
  return enhancedQuery + ' white background';
}

/**
 * Função para pontuar a qualidade de uma imagem com base em aspecto, resolução e popularidade.
 * Retorna um valor entre 0 e 1.
 */
function scoreImage(photo: any): number {
  if (!photo) return 0;
  
  const aspectRatio = photo.width / photo.height;
  const aspectScore = Math.max(0, 1 - Math.abs(aspectRatio - 1.5));
  
  const resolutionScore = Math.min(1, 
    (photo.width >= 1920 ? 0.5 : 0.2) + 
    (photo.height >= 1080 ? 0.5 : 0.2)
  );
  
  const popularityScore = Math.min(1, (photo.likes || 0) / 1000);
  
  return aspectScore * 0.4 + resolutionScore * 0.4 + popularityScore * 0.2;
}

/**
 * Tenta recuperar uma imagem cacheada para a query.
 */
async function getCachedImage(query: string): Promise<{ imageUrl: string; thumbnailUrl: string } | null> {
  if (!auth.currentUser) return null;
  try {
    const cacheRef = doc(db, 'users', auth.currentUser.uid, 'imageCache', query);
    const cacheDoc = await getDoc(cacheRef);
    if (!cacheDoc.exists()) return null;
    
    const cachedResult = cacheDoc.data();
    if (!cachedResult) return null;
    
    const cacheTime = new Date(cachedResult.timestamp);
    const now = new Date();
    if (now.getTime() - cacheTime.getTime() > CACHE_DURATION) return null;
    
    return {
      imageUrl: cachedResult.imageUrl,
      thumbnailUrl: cachedResult.thumbnailUrl
    };
  } catch (error) {
    console.warn('Cache read error:', error);
    return null;
  }
}

/**
 * Armazena a imagem cacheada para a query.
 */
async function cacheImage(query: string, imageUrl: string, thumbnailUrl: string): Promise<void> {
  if (!auth.currentUser) return;
  try {
    const cacheRef = doc(db, 'users', auth.currentUser.uid, 'imageCache', query);
    await setDoc(cacheRef, {
      imageUrl,
      thumbnailUrl,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.warn('Cache write error:', error);
  }
}

/**
 * Obtém uma imagem de alta qualidade para um alimento utilizando apenas a API do Pixabay.
 * A função usa imagens curadas se disponíveis, verifica o cache e, se necessário, busca uma imagem
 * via Pixabay com uma query otimizada. Se a imagem obtida tiver baixa qualidade, retorna uma imagem padrão.
 */
export async function getImage(query: string, forceRefresh = false): Promise<{ imageUrl: string; thumbnailUrl: string }> {
  if (!query) {
    // Retorna imagem padrão se query estiver vazia
    return {
      imageUrl: 'https://cdn.pixabay.com/photo/2015/04/08/13/13/food-712665_1280.jpg',
      thumbnailUrl: 'https://cdn.pixabay.com/photo/2015/04/08/13/13/food-712665_1280.jpg?w=200'
    };
  }
  
  const normalizedQuery = query.toLowerCase().trim();
  
  // Verifica se há imagem curada disponível para a query exata
  const curatedImage = CURATED_IMAGES[normalizedQuery];
  if (curatedImage && !forceRefresh) {
    return curatedImage;
  }
  
  // Verifica se já há imagem cacheada
  const cachedImage = !forceRefresh ? await getCachedImage(normalizedQuery) : null;
  if (cachedImage) {
    return cachedImage;
  }
  
  // Gera uma query otimizada para busca no Pixabay
  const enhancedQuery = enhanceSearchTerm(normalizedQuery);
  
  // Busca a imagem via Pixabay
  const result = await getPixabayImage(enhancedQuery);
  
  // Opcional: verificação da qualidade da imagem
  const qualityScore = scoreImage(result);
  if (qualityScore < QUALITY_THRESHOLD) {
    // Se a qualidade estiver abaixo do esperado, usar imagem padrão (ou tentar outra estratégia)
    return {
      imageUrl: 'https://cdn.pixabay.com/photo/2015/04/08/13/13/food-712665_1280.jpg',
      thumbnailUrl: 'https://cdn.pixabay.com/photo/2015/04/08/13/13/food-712665_1280.jpg?w=200'
    };
  }
  
  // Cacheia o resultado para futuras buscas
  await cacheImage(normalizedQuery, result.imageUrl, result.thumbnailUrl);
  
  return result;
}
