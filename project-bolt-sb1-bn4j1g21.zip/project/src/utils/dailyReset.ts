import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import type { UserProfile } from '../types/user';

const isSameDay = (date1: Date, date2: Date) => {
  return (
    date1.getFullYear() === date2.getFullYear() &&
    date1.getMonth() === date2.getMonth() &&
    date1.getDate() === date2.getDate()
  );
};

export async function resetDailyStats() {
  try {
    if (!auth.currentUser) {
      console.log('No authenticated user');
      return;
    }

    const now = new Date();
    const today = now.toISOString().split('T')[0];

    // Get user data
    const userRef = doc(db, 'users', auth.currentUser.uid);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      console.log('User document not found');
      return;
    }

    const userData = userDoc.data() as UserProfile;
    
    // Check if stats were already reset today
    const lastUpdated = userData.dailyStats?.lastUpdated 
      ? new Date(userData.dailyStats.lastUpdated)
      : null;

    if (lastUpdated && isSameDay(lastUpdated, now)) {
      console.log('Stats already reset today');
      return;
    }

    // Archive current plan if exists
    if (userData.currentDietPlan) {
      const updatedHistory = {
        plans: [
          ...(userData.dietHistory?.plans || []),
          {
            ...userData.currentDietPlan,
            date: today,
            dailyStats: userData.dailyStats || {
              caloriesConsumed: 0,
              proteinConsumed: 0,
              carbsConsumed: 0,
              fatConsumed: 0,
              waterIntake: 0,
              lastUpdated: now.toISOString()
            }
          }
        ],
        lastUpdated: now.toISOString()
      };

      // Keep only last 120 days
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - 120);
      
      updatedHistory.plans = updatedHistory.plans
        .filter(plan => new Date(plan.date || plan.createdAt) > cutoffDate)
        .sort((a, b) => 
          new Date(b.date || b.createdAt).getTime() - 
          new Date(a.date || a.createdAt).getTime()
        );

      // Update user document
      await updateDoc(userRef, {
        dietHistory: updatedHistory,
        dailyStats: {
          waterIntake: 0,
          caloriesConsumed: 0,
          proteinConsumed: 0,
          carbsConsumed: 0,
          fatConsumed: 0,
          stepsCount: 0,
          workoutMinutes: 0,
          completedMeals: {
            [today]: [] // Initialize empty array for today
          },
          lastUpdated: now.toISOString()
        }
      });

      console.log('Daily stats reset successfully');
    }
  } catch (error) {
    console.error('Error resetting daily stats:', error);
    throw error;
  }
}