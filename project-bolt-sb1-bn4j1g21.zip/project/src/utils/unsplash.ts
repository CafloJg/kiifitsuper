import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';

const UNSPLASH_API_URL = 'https://api.unsplash.com/search/photos';
const ACCESS_KEY = 'RYCNVLGRKCaUhXsxrB0mueBVFNVGCw6XXyLWOa0JCs0';
const CACHE_DURATION = 7 * 24 * 60 * 60 * 1000; // 7 days
const MAX_RETRIES = 3;
const RETRY_DELAY = 1000;

const FALLBACK_IMAGES = {
  default: {
    imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c',
    thumbnailUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200'
  },
  food: {
    imageUrl: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836',
    thumbnailUrl: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=200'
  }
};

// Interface definitions
interface UnsplashCache {
  [query: string]: {
    imageUrl: string;
    thumbnailUrl: string;
    timestamp: string;
  };
}

// Get image from cache if available
async function getCachedImage(query: string): Promise<{ imageUrl: string; thumbnailUrl: string } | null> {
  const cacheRef = doc(db, 'system', 'unsplashCache');
  const cacheDoc = await getDoc(cacheRef);
  
  try {
    if (!cacheDoc.exists()) return null;
  
    const cache = cacheDoc.data() as UnsplashCache;
    const cachedResult = cache[query];
  
    if (!cachedResult) return null;
  
    // Cache is valid for 7 days
    const cacheTime = new Date(cachedResult.timestamp);
    const now = new Date();
    const cacheAge = now.getTime() - cacheTime.getTime();
  
    if (cacheAge > CACHE_DURATION) return null;
  
    return {
      imageUrl: cachedResult.imageUrl,
      thumbnailUrl: cachedResult.thumbnailUrl
    };
  } catch (error) {
    console.error('Error getting cached image:', error);
    return null;
  }
}

// Cache image URL and thumbnail
async function cacheImage(query: string, imageUrl: string, thumbnailUrl: string): Promise<void> {
  const cacheRef = doc(db, 'system', 'unsplashCache');
  try {
    const cacheDoc = await getDoc(cacheRef);
    const cache: UnsplashCache = cacheDoc.exists() ? cacheDoc.data() as UnsplashCache : {};
    
    cache[query] = {
      imageUrl,
      thumbnailUrl,
      timestamp: new Date().toISOString()
    };
    
    await setDoc(cacheRef, cache);
  } catch (error) {
    console.error('Error caching image:', error);
  }
}

// Main function to get images from Unsplash
export async function getUnsplashImage(query: string): Promise<{ imageUrl: string; thumbnailUrl: string }> {
  const isFood = query.toLowerCase().includes('food');
  const fallback = isFood ? FALLBACK_IMAGES.food : FALLBACK_IMAGES.default;

  try {
    // Check cache first
    const cachedImage = await getCachedImage(query);
    if (cachedImage) {
      return cachedImage;
    }

    // Make API request with retries
    for (let retries = MAX_RETRIES; retries > 0; retries--) {
      try {
        const response = await fetch(`${UNSPLASH_API_URL}?query=${encodeURIComponent(query)}&per_page=1&orientation=landscape`, {
          headers: {
            'Authorization': `Client-ID ${ACCESS_KEY}`,
            'Accept-Version': 'v1'
          }
        });

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        
        if (!data.results?.[0]) {
          return fallback;
        }

        const result = {
          imageUrl: data.results[0].urls.regular,
          thumbnailUrl: data.results[0].urls.thumb
        };
        
        // Cache successful result
        await cacheImage(query, result.imageUrl, result.thumbnailUrl);
        return result;

      } catch (error) {
        if (retries === 1) throw error; // Last retry, propagate error
        await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
        continue;
      }
    }

    throw new Error('Max retries exceeded');
  } catch (error) {
    console.error('Error fetching Unsplash image:', error);
    
    // Return fallback image and cache it
    await cacheImage(query, fallback.imageUrl, fallback.thumbnailUrl);
    return fallback;
  }
}