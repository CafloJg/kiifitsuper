import { storage } from '../lib/firebase';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { getImage } from '../utils/imageService';

// Food categories with their items
export const foodCategories = {
  grains: {
    title: '🌾 Grãos e Cereais Integrais',
    items: [
      { name: 'Arroz integral', searchTerm: 'cooked brown rice close up isolated' },
      { name: 'Quinoa', searchTerm: 'cooked quinoa grains close up isolated' },
      { name: 'Aveia', searchTerm: 'oatmeal porridge close up isolated' },
      { name: 'Cevada', searchTerm: 'cooked barley grains close up isolated' },
      { name: 'Trigo-sarraceno', searchTerm: 'cooked buckwheat close up isolated' },
      { name: 'Milho', searchTerm: 'cooked corn kernels close up isolated' },
      { name: 'Centeio', searchTerm: 'cooked rye grains close up isolated' },
      { name: 'Espelta', searchTerm: 'cooked spelt grains close up isolated' },
      { name: 'Arroz selvagem', searchTerm: 'cooked wild rice close up isolated' },
      { name: 'Farro', searchTerm: 'cooked farro grains close up isolated' },
      { name: 'Amaranto', searchTerm: 'cooked amaranth grains close up isolated' },
      { name: 'Teff', searchTerm: 'cooked teff grains close up isolated' },
      { name: 'Sorgo', searchTerm: 'cooked sorghum grains close up isolated' },
      { name: 'Trigo integral', searchTerm: 'whole wheat grains close up isolated' },
      { name: 'Bulgur', searchTerm: 'cooked bulgur wheat close up isolated' },
      { name: 'Freekeh', searchTerm: 'cooked freekeh grains close up isolated' },
      { name: 'Kamut', searchTerm: 'cooked kamut grains close up isolated' },
      { name: 'Massa integral', searchTerm: 'whole wheat pasta cooked close up' },
      { name: 'Pão integral', searchTerm: 'whole grain bread sliced close up' }
    ]
  },
  legumes: {
    title: '🫘 Leguminosas e Oleaginosas',
    items: [
      { name: 'Feijão preto', searchTerm: 'cooked black beans close up isolated' },
      { name: 'Grão-de-bico', searchTerm: 'cooked chickpeas close up isolated' },
      { name: 'Lentilhas', searchTerm: 'cooked lentils close up isolated' },
      { name: 'Feijão vermelho', searchTerm: 'cooked red kidney beans close up isolated' },
      { name: 'Feijão branco', searchTerm: 'cooked white beans close up isolated' },
      { name: 'Ervilhas', searchTerm: 'cooked green peas close up isolated' },
      { name: 'Fava', searchTerm: 'cooked fava beans close up isolated' },
      { name: 'Soja', searchTerm: 'cooked soybeans close up isolated' },
      { name: 'Feijão-fradinho', searchTerm: 'cooked black eyed peas close up isolated' },
      { name: 'Feijão-carioca', searchTerm: 'cooked pinto beans close up isolated' },
      { name: 'Castanha-do-pará', searchTerm: 'brazil nuts close up isolated' },
      { name: 'Castanha de caju', searchTerm: 'cashew nuts close up isolated' },
      { name: 'Amêndoas', searchTerm: 'almonds close up isolated' },
      { name: 'Nozes', searchTerm: 'walnuts close up isolated' },
      { name: 'Pistache', searchTerm: 'pistachios close up isolated' },
      { name: 'Macadâmia', searchTerm: 'macadamia nuts close up isolated' },
      { name: 'Avelã', searchTerm: 'hazelnuts close up isolated' },
      { name: 'Amendoim', searchTerm: 'peanuts close up isolated' }
    ]
  },
  fruits: {
    title: '🍎 Frutas',
    items: [
      { name: 'Maçã', searchTerm: 'fresh red apple isolated' },
      { name: 'Banana', searchTerm: 'fresh banana isolated' },
      { name: 'Laranja', searchTerm: 'fresh orange isolated' },
      { name: 'Manga', searchTerm: 'fresh mango isolated' },
      { name: 'Uva', searchTerm: 'fresh grapes bunch isolated' },
      { name: 'Morango', searchTerm: 'fresh strawberries isolated' },
      { name: 'Abacaxi', searchTerm: 'fresh pineapple isolated' },
      { name: 'Melancia', searchTerm: 'fresh watermelon sliced isolated' },
      { name: 'Mamão', searchTerm: 'fresh papaya sliced isolated' },
      { name: 'Kiwi', searchTerm: 'fresh kiwi sliced isolated' },
      { name: 'Pera', searchTerm: 'fresh pear isolated' },
      { name: 'Pêssego', searchTerm: 'fresh peach isolated' },
      { name: 'Ameixa', searchTerm: 'fresh plum isolated' },
      { name: 'Cereja', searchTerm: 'fresh cherries isolated' },
      { name: 'Framboesa', searchTerm: 'fresh raspberries isolated' },
      { name: 'Mirtilo', searchTerm: 'fresh blueberries isolated' },
      { name: 'Goiaba', searchTerm: 'fresh guava isolated' },
      { name: 'Maracujá', searchTerm: 'fresh passion fruit isolated' }
    ]
  },
  vegetables: {
    title: '🥬 Vegetais',
    items: [
      { name: 'Brócolis', searchTerm: 'fresh broccoli isolated' },
      { name: 'Couve-flor', searchTerm: 'fresh cauliflower isolated' },
      { name: 'Espinafre', searchTerm: 'fresh spinach leaves isolated' },
      { name: 'Couve', searchTerm: 'fresh kale leaves isolated' },
      { name: 'Alface', searchTerm: 'fresh lettuce isolated' },
      { name: 'Rúcula', searchTerm: 'fresh arugula leaves isolated' },
      { name: 'Agrião', searchTerm: 'fresh watercress isolated' },
      { name: 'Repolho', searchTerm: 'fresh cabbage isolated' },
      { name: 'Cenoura', searchTerm: 'fresh carrots isolated' },
      { name: 'Beterraba', searchTerm: 'fresh beetroot isolated' },
      { name: 'Pepino', searchTerm: 'fresh cucumber isolated' },
      { name: 'Abobrinha', searchTerm: 'fresh zucchini isolated' },
      { name: 'Berinjela', searchTerm: 'fresh eggplant isolated' },
      { name: 'Pimentão', searchTerm: 'fresh bell peppers isolated' },
      { name: 'Tomate', searchTerm: 'fresh tomato isolated' },
      { name: 'Batata-doce', searchTerm: 'fresh sweet potato isolated' },
      { name: 'Inhame', searchTerm: 'fresh yam isolated' },
      { name: 'Mandioca', searchTerm: 'fresh cassava isolated' }
    ]
  },
  proteins: {
    title: '🥩 Proteínas e Laticínios',
    items: [
      { name: 'Frango grelhado', searchTerm: 'grilled chicken breast fillet close up' },
      { name: 'Carne bovina', searchTerm: 'grilled beef steak close up' },
      { name: 'Ovos', searchTerm: 'fresh eggs close up isolated' },
      { name: 'Peixe branco', searchTerm: 'grilled white fish fillet close up' },
      { name: 'Salmão', searchTerm: 'grilled salmon fillet close up' },
      { name: 'Sardinha', searchTerm: 'grilled sardines close up' },
      { name: 'Atum', searchTerm: 'grilled tuna steak close up' },
      { name: 'Tilápia', searchTerm: 'grilled tilapia fillet close up' },
      { name: 'Queijo cottage', searchTerm: 'cottage cheese close up isolated' },
      { name: 'Ricota', searchTerm: 'ricotta cheese close up isolated' },
      { name: 'Mussarela de búfala', searchTerm: 'buffalo mozzarella cheese close up isolated' },
      { name: 'Queijo de cabra', searchTerm: 'goat cheese close up isolated' },
      { name: 'Iogurte natural', searchTerm: 'plain yogurt close up isolated' },
      { name: 'Iogurte grego', searchTerm: 'greek yogurt close up isolated' },
      { name: 'Coalhada', searchTerm: 'curd cheese close up isolated' },
      { name: 'Queijo minas', searchTerm: 'fresh white cheese close up isolated' },
      { name: 'Queijo feta', searchTerm: 'feta cheese close up isolated' },
      { name: 'Requeijão light', searchTerm: 'light cream cheese close up isolated' }
    ]
  }
};

// Function to download and store a single food image
async function downloadAndStoreFoodImage(
  category: string,
  foodName: string,
  searchTerm: string
): Promise<{ imageUrl: string; thumbnailUrl: string }> {
  try {
    // Get high-quality image
    const image = await getImage(searchTerm);
    
    // Create storage references
    const imagePath = `food-database/${category}/${foodName.toLowerCase().replace(/\s+/g, '-')}.jpg`;
    const storageRef = ref(storage, imagePath);
    
    // Download image and upload to storage
    const response = await fetch(image.imageUrl);
    const blob = await response.blob();
    
    await uploadBytes(storageRef, blob);
    const storedUrl = await getDownloadURL(storageRef);
    
    return {
      imageUrl: storedUrl,
      thumbnailUrl: image.thumbnailUrl
    };
  } catch (error) {
    console.error(`Error downloading image for ${foodName}:`, error);
    throw error;
  }
}

// Function to download all food images
export async function downloadAllFoodImages(
  onProgress?: (current: number, total: number, item: string) => void
): Promise<void> {
  const totalItems = Object.values(foodCategories)
    .reduce((sum, category) => sum + category.items.length, 0);
  let processedItems = 0;

  for (const [category, data] of Object.entries(foodCategories)) {
    for (const item of data.items) {
      try {
        await downloadAndStoreFoodImage(category, item.name, item.searchTerm);
        processedItems++;
        
        if (onProgress) {
          onProgress(processedItems, totalItems, item.name);
        }
      } catch (error) {
        console.warn(`Failed to download image for ${item.name}:`, error);
        continue; // Skip to next item on error
      }
      
      // Add delay to avoid rate limits
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }
}

// Function to get stored food image URL
export async function getFoodImage(
  category: string,
  foodName: string
): Promise<string> {
  try {
    const imagePath = `food-database/${category}/${foodName.toLowerCase().replace(/\s+/g, '-')}.jpg`;
    const storageRef = ref(storage, imagePath);
    return await getDownloadURL(storageRef);
  } catch (error) {
    console.error(`Error getting image for ${foodName}:`, error);
    throw error;
  }
}