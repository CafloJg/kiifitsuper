import type { SubscriptionTier } from '../types/user';

export interface PlanFeature {
  name: string;
  description: string;
  included: boolean;
}

export interface Plan {
  tier: SubscriptionTier;
  name: string;
  price: number;
  features: PlanFeature[];
  limits: {
    monthlyDietPlans: number;
    nutritionistSessions: number;
    customGoals: number;
    supportPriority: 'normal' | 'high' | 'priority';
  };
}

export const plans: Plan[] = [
  {
    tier: 'basic',
    name: 'Basic',
    price: 29.90,
    features: [
      {
        name: 'Plano alimentar personalizado',
        description: '3 planos por mês com refeições balanceadas',
        included: true
      },
      {
        name: 'Controle de metas',
        description: 'Acompanhamento de peso e medidas',
        included: true
      },
      {
        name: 'Check-in diário',
        description: 'Registro diário de progresso',
        included: true
      },
      {
        name: 'Calculadora de macros',
        description: 'Cálculo de proteínas, carboidratos e gorduras',
        included: true
      },
      {
        name: 'Chat com nutricionista',
        description: 'Suporte em horário comercial',
        included: true
      },
      {
        name: 'Análise de alimentos por foto',
        description: 'Reconhecimento automático de alimentos',
        included: false
      },
      {
        name: 'Consultas com nutricionista',
        description: 'Atendimento por vídeo',
        included: false
      },
      {
        name: 'Receitas personalizadas',
        description: 'Receitas baseadas nos seus objetivos',
        included: false
      }
    ],
    limits: {
      monthlyDietPlans: 3,
      nutritionistSessions: 0,
      customGoals: 3,
      supportPriority: 'normal'
    }
  },
  {
    tier: 'premium',
    name: 'Premium',
    price: 59.90,
    features: [
      {
        name: 'Plano alimentar personalizado',
        description: '10 planos por mês com refeições balanceadas',
        included: true
      },
      {
        name: 'Controle de metas',
        description: 'Acompanhamento detalhado de peso e medidas',
        included: true
      },
      {
        name: 'Check-in diário',
        description: 'Registro diário de progresso com análise',
        included: true
      },
      {
        name: 'Calculadora de macros',
        description: 'Cálculo avançado de nutrientes',
        included: true
      },
      {
        name: 'Chat com nutricionista',
        description: 'Suporte estendido (8h às 22h)',
        included: true
      },
      {
        name: 'Consultas com nutricionista',
        description: '3 consultas mensais por vídeo',
        included: true
      },
      {
        name: 'Análise de alimentos por foto',
        description: 'Reconhecimento automático de alimentos',
        included: false
      },
      {
        name: 'Receitas personalizadas',
        description: 'Receitas baseadas nos seus objetivos',
        included: false
      }
    ],
    limits: {
      monthlyDietPlans: 10,
      nutritionistSessions: 3,
      customGoals: 10,
      supportPriority: 'high'
    }
  },
  {
    tier: 'premium-plus',
    name: 'Premium Plus',
    price: 99.90,
    features: [
      {
        name: 'Plano alimentar personalizado',
        description: 'Planos ilimitados com refeições balanceadas',
        included: true
      },
      {
        name: 'Controle de metas',
        description: 'Acompanhamento completo com análises',
        included: true
      },
      {
        name: 'Check-in diário',
        description: 'Registro diário com análise detalhada',
        included: true
      },
      {
        name: 'Calculadora de macros',
        description: 'Cálculo profissional de nutrientes',
        included: true
      },
      {
        name: 'Chat com nutricionista',
        description: 'Suporte 24/7 com prioridade',
        included: true
      },
      {
        name: 'Consultas com nutricionista',
        description: 'Consultas ilimitadas 24/7',
        included: true
      },
      {
        name: 'Análise de alimentos por foto',
        description: 'Reconhecimento e análise detalhada',
        included: true
      },
      {
        name: 'Receitas personalizadas',
        description: 'Receitas exclusivas e personalizadas',
        included: true
      }
    ],
    limits: {
      monthlyDietPlans: -1, // ilimitado
      nutritionistSessions: -1, // ilimitado
      customGoals: -1, // ilimitado
      supportPriority: 'priority'
    }
  }
];

export function getPlanByTier(tier: SubscriptionTier): Plan {
  const plan = plans.find(p => p.tier === tier);
  if (!plan) {
    throw new Error(`Plano não encontrado: ${tier}`);
  }
  return plan;
}

export function checkPlanLimits(
  tier: SubscriptionTier,
  type: keyof Plan['limits'],
  currentUsage: number
): boolean {
  const plan = getPlanByTier(tier);
  const limit = plan.limits[type];
  return limit === -1 || currentUsage < limit;
}

export function getPlanFeatures(tier: SubscriptionTier): PlanFeature[] {
  const plan = getPlanByTier(tier);
  return plan.features;
}

export function getPlanLimits(tier: SubscriptionTier): Plan['limits'] {
  const plan = getPlanByTier(tier);
  return plan.limits;
}

export function formatPlanLimit(limit: number): string {
  return limit === -1 ? 'Ilimitado' : limit.toString();
}