import { collection, query, where, getDocs, addDoc } from 'firebase/firestore';
import { db } from '../firebase';
import type { Food, FoodCategory } from '../../types/food';

// Interface para filtros de busca
export interface FoodFilter {
  category?: FoodCategory;
  dietType?: string;
  tags?: string[];
  minProtein?: number;
  maxCalories?: number;
}

// Funções para interagir com a coleção de alimentos
export const foodsCollection = collection(db, 'foods');

// Buscar alimentos com filtros
export async function getFoods(filters: FoodFilter = {}) {
  let q = query(foodsCollection);

  if (filters.category) {
    q = query(q, where('category', '==', filters.category));
  }

  if (filters.dietType) {
    q = query(q, where('dietTypes', 'array-contains', filters.dietType));
  }

  if (filters.minProtein) {
    q = query(q, where('protein', '>=', filters.minProtein));
  }

  if (filters.maxCalories) {
    q = query(q, where('calories', '<=', filters.maxCalories));
  }

  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  } as Food & { id: string }));
}

// Buscar alimentos por categoria
export async function getFoodsByCategory(category: FoodCategory) {
  const q = query(foodsCollection, where('category', '==', category));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  } as Food & { id: string }));
}

// Buscar alimentos por dieta
export async function getFoodsByDiet(dietType: string) {
  const q = query(foodsCollection, where('dietTypes', 'array-contains', dietType));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  } as Food & { id: string }));
}

// Buscar alimentos por tags
export async function getFoodsByTags(tags: string[]) {
  const q = query(foodsCollection, where('tags', 'array-contains-any', tags));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  } as Food & { id: string }));
}

// Adicionar novo alimento
export async function addFood(food: Omit<Food, 'id'>) {
  return addDoc(foodsCollection, {
    ...food,
    createdAt: new Date()
  });
}

// Função para popular o banco de dados com alimentos iniciais
export async function seedFoodDatabase() {
  const foods: Omit<Food, 'id'>[] = [
    {
      name: 'Frango grelhado',
      portion: '100g',
      calories: 165,
      protein: 31,
      carbs: 0,
      fat: 3.6,
      fiber: 0,
      category: 'meat',
      preparation: ['grelhado', 'assado', 'cozido'],
      tags: ['lean', 'popular'],
      dietTypes: ['omnivoro', 'low-carb', 'mediterranea']
    },
    // Adicione mais alimentos aqui...
  ];

  for (const food of foods) {
    try {
      await addFood(food);
    } catch (error) {
      console.error(`Erro ao adicionar ${food.name}:`, error);
    }
  }
}