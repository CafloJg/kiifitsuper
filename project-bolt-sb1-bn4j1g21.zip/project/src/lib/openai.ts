import type { Message } from '../types/chat';
import type { UserProfile } from '../types/user';
import type { FoodAnalysis } from '../types/food';

const OPENAI_API_URL = 'https://api.openai.com/v1';
const ALLOWED_MODEL = 'gpt-4-turbo-preview';
const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
const MAX_RETRIES = 3;
const RETRY_DELAY = 2000;
const TIMEOUT = 30000; // 30 segundos
const BACKOFF_FACTOR = 1.5;

// Cache configuration
const CACHE_TTL = 10 * 60 * 1000; // 10 minutes
const promptCache = new Map<string, { result: any; timestamp: number }>();

async function fetchWithRetry(url: string, options: RequestInit, retries = MAX_RETRIES): Promise<Response> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), TIMEOUT);

    const headers = {
      'Authorization': `Bearer ${apiKey || ''}`,
      'Content-Type': 'application/json',
      'Accept-Encoding': 'gzip'
    };

    // Check cache first
    const cacheKey = JSON.stringify(options.body);
    const cached = promptCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      return new Response(JSON.stringify(cached.result), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const response = await fetch(url, {
      ...options,
      headers: { ...headers, ...options.headers },
      signal: controller.signal,
      keepalive: true
    });

    clearTimeout(timeoutId);

    // Cache successful responses
    if (response.ok) {
      const data = await response.clone().json();
      promptCache.set(cacheKey, {
        result: data,
        timestamp: Date.now()
      });
    }

    if (response.status === 429) {
      const retryAfter = parseInt(response.headers.get('Retry-After') || '60');
      const waitTime = Math.min(Math.max(retryAfter * 1000, RETRY_DELAY), 30000);
      console.warn(`Rate limit hit, waiting ${waitTime}ms before retry`);
      if (retries > 0) {
        await new Promise(resolve => setTimeout(resolve, waitTime));
        return fetchWithRetry(url, options, retries - 1);
      }
      throw new Error('Muitas solicitações. Por favor, aguarde alguns minutos.');
    }

    if (response.status === 401) {
      throw new Error('Chave da API OpenAI inválida. Por favor, configure uma chave válida.');
    }
    if (response.status === 403) {
      throw new Error('Acesso negado. Verifique as permissões da sua chave API.');
    }
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error?.message || 'Erro ao processar requisição');
    }

    return response;
  } catch (error) {
    if (retries > 0 && error instanceof Error) {
      const isNetworkError = error.name === 'TypeError' && error.message === 'Failed to fetch';
      const isTimeout = error.name === 'AbortError';
      const isConnectionError = error.message.toLowerCase().includes('network') ||
                                error.message.toLowerCase().includes('connection') ||
                                error.message.toLowerCase().includes('internet');
      if (isNetworkError || isTimeout || isConnectionError) {
        const attempt = MAX_RETRIES - retries + 1;
        const delay = RETRY_DELAY * Math.pow(BACKOFF_FACTOR, attempt - 1);
        await new Promise(resolve => setTimeout(resolve, delay));
        return fetchWithRetry(url, options, retries - 1);
      }
    }
    throw error;
  }
}

export async function getChatResponse(messages: Message[], userProfile: UserProfile): Promise<string> {
  try {
    const nutritionist = 'Helena';    
    if (!import.meta.env.VITE_OPENAI_API_KEY?.trim()) {
      throw new Error('Chave da API OpenAI não configurada. Verifique o arquivo .env');
    }

    const response = await fetchWithRetry(`${OPENAI_API_URL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey || ''}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        model: ALLOWED_MODEL,
        messages: [
          {
            role: 'system',
            content: 'You are a professional nutritionist. Return a valid JSON with the following structure: {"ingredients": ["string"], "preparation": ["string"], "confidence": number}'
          },
          {
            role: 'user',
            content: `
Perfil do Paciente:
Nome: ${userProfile.name || 'Paciente'}
Dieta: ${userProfile.dietType || 'Não especificada'}
Objetivo: ${userProfile.goals?.type || 'Não especificado'}
Peso atual: ${userProfile.weight ? `${userProfile.weight}kg` : 'Não especificado'}
Peso desejado: ${userProfile.goals?.targetWeight ? `${userProfile.goals.targetWeight}kg` : 'Não especificado'}
Alergias: ${userProfile.allergies?.join(', ') || 'Nenhuma'}
Restrições: ${userProfile.dislikedIngredients?.join(', ') || 'Nenhuma'}

Mensagem do paciente: ${messages[messages.length - 1].text}
`
          }
        ],
        temperature: 0.1,
        max_tokens: 2048,
        presence_penalty: 0.6,
        frequency_penalty: 0.3,
        top_p: 0.95
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error("OpenAI API error:", errorData);
      const err = errorData.error || { message: 'Erro desconhecido' };
      if (err.code === 'model_not_found' || err.message?.includes('does not have access to model')) {
        throw new Error('Serviço temporariamente indisponível. Por favor, tente novamente mais tarde.');
      } else if (err.code === 'invalid_api_key') {
        throw new Error('A chave da API OpenAI é inválida. Verifique e atualize sua chave no arquivo .env.');
      } else if (err.code === 'insufficient_quota') {
        throw new Error('Sua cota da API OpenAI foi excedida. Verifique seu uso no dashboard da OpenAI.');
      } else if (err.code === 'rate_limit_exceeded') {
        throw new Error('Muitas solicitações. Por favor, aguarde alguns minutos.');
      } else if (err.code === 'context_length_exceeded') {
        throw new Error('Prompt muito longo. Tente reduzir as preferências alimentares.');
      } else if (err.message) {
        throw new Error(`Erro da API: ${err.message}`);
      } else {
        throw new Error('Não foi possível gerar o plano alimentar. Por favor, tente novamente.');
      }
    }

    const data = await response.json();
    const content = data.choices[0]?.message?.content;
    if (!content || typeof content !== 'string' || content.trim().length === 0) {
      throw new Error('Resposta inválida do assistente');
    }
    return content;
  } catch (error) {
    console.error('Error getting response:', error);
    if (error instanceof Error) {
      if (error.message.includes('API key')) {
        throw new Error('Configuração incompleta. Por favor, adicione uma chave de API OpenAI válida no arquivo .env.');
      }
      if (error.message.includes('rate limit')) {
        throw new Error('Muitas solicitações. Aguarde um momento.');
      }
      if (error.message.includes('invalid api key')) {
        throw new Error('Configuração incompleta. Por favor, adicione uma chave de API OpenAI válida no arquivo .env.');
      }
      if (error.message.includes('billing')) {
        throw new Error('Serviço temporariamente indisponível. Tente novamente mais tarde.');
      }
      if (error.message.includes('capacity')) {
        throw new Error('Serviço sobrecarregado. Tente novamente em alguns minutos.');
      }
      throw error;
    }
    throw new Error('Não foi possível processar sua mensagem. Por favor, tente novamente.');
  }
}

export async function analyzeImageWithOpenAI(imageData: string): Promise<FoodAnalysis> {
  try {
    const apiKey = import.meta.env.VITE_OPENAI_API_KEY?.trim();
    if (!apiKey?.trim()) {
      throw new Error('Serviço temporariamente indisponível. Tente novamente mais tarde.');
    }

    const [header, base64Content] = imageData.split(',');
    if (!header || !base64Content || !header.startsWith('data:image/')) {
      throw new Error('Formato de imagem inválido. Use uma foto no formato JPG ou PNG.');
    }
    const mimeType = header.split(':')[1].split(';')[0];
    if (!['image/jpeg', 'image/png'].includes(mimeType)) {
      throw new Error('Formato não suportado. Use apenas fotos JPG ou PNG.');
    }
    const imageSize = (base64Content.length * 3) / 4;
    if (imageSize > 4 * 1024 * 1024) {
      throw new Error(`Imagem muito grande (${Math.round(imageSize/1024/1024)}MB). Use uma foto menor que 4MB.`);
    }
    if (imageSize < 1024) {
      throw new Error('Imagem muito pequena. Tente tirar uma foto mais nítida.');
    }

    const response = await fetchWithRetry(`${OPENAI_API_URL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: ALLOWED_MODEL,
        messages: [
          {
            role: 'system',
            content: `Você é um nutricionista profissional especializado em análise de alimentos.
INSTRUÇÕES:
1. Analise a imagem e identifique os alimentos visíveis
2. Use apenas nomes comuns em português do Brasil
3. Ignore utensílios, decorações e fundo
4. Não invente ou suponha alimentos não visíveis
5. Liste apenas os alimentos claramente visíveis
6. Retorne a resposta no formato:
{
  "ingredients": ["alimento 1", "alimento 2"],
  "preparation": ["método 1", "método 2"],
  "confidence": 0.95
}`
          },
          {
            role: 'user',
            content: [
              { type: "text", text: "Analise esta imagem de alimento:" },
              { type: "image_url", url: imageData },
              { type: "text", text: "Identifique os alimentos visíveis e seus métodos de preparo." }
            ]
          }
        ],
        temperature: 0.3,
        max_tokens: 1000,
        presence_penalty: 0.6,
        frequency_penalty: 0.3
      })
    });

    if (!response.ok) {
      const error = await response.json();
      console.error('Erro da API OpenAI:', error);
      if (error.error?.code === 'rate_limit_exceeded') {
        throw new Error('Muitas solicitações. Por favor, aguarde alguns minutos.');
      } else if (error.error?.code === 'invalid_api_key') {
        throw new Error('Serviço temporariamente indisponível. Tente novamente em alguns minutos.');
      } else if (error.error?.code === 'model_not_available') {
        throw new Error('Serviço temporariamente indisponível. Por favor, tente novamente mais tarde.');
      } else {
        throw new Error('Não foi possível analisar a imagem. Tente novamente.');
      }
    }

    const data = await response.json();
    if (!data.choices?.[0]?.message?.content) {
      throw new Error('Não foi possível analisar a imagem. Tente novamente.');
    }

    let result;
    try {
      result = JSON.parse(data.choices[0].message.content);
    } catch (parseError) {
      console.error('Erro ao converter resposta para JSON:', parseError, '\nResposta:', data.choices[0].message.content);
      throw new Error('Erro ao processar a resposta. Tente novamente.');
    }

    if (!result.ingredients || !Array.isArray(result.ingredients) || result.ingredients.length === 0) {
      console.warn('No food detected:', result);
      throw new Error('Nenhum alimento identificado. Tente uma foto mais clara ou de outro ângulo.');
    }
    if (!result.confidence || typeof result.confidence !== 'number') {
      throw new Error('Erro na análise de confiança. Tente novamente.');
    }
    if (result.confidence < 0.7) {
      throw new Error('Não foi possível identificar os alimentos com certeza. Tente uma foto mais nítida.');
    }

    const analysis: FoodAnalysis = {
      ingredients: result.ingredients,
      timestamp: new Date().toISOString(),
      imageUrl: imageData,
      confidence: result.confidence,
      preparation: result.preparation || []
    };

    return analysis;
  } catch (error) {
    console.error('OpenAI image analysis error:', {
      error,
      message: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined
    });
    
    let errorMessage = 'Erro ao analisar imagem. Tente novamente.';
    if (error instanceof Error) {
      const msg = error.message.toLowerCase();
      if (msg.includes('failed to fetch') || msg.includes('network error') || msg.includes('connection')) {
        errorMessage = 'Erro de conexão. Verifique sua internet e tente novamente.';
        throw error;
      } else if (msg.includes('timeout')) {
        errorMessage = 'A análise está demorando muito. Tente uma foto mais simples.';
      } else if (msg.includes('api key')) {
        errorMessage = 'Serviço temporariamente indisponível. Tente novamente mais tarde.';
      } else if (msg.includes('rate limit')) {
        errorMessage = 'Muitas solicitações. Aguarde um momento e tente novamente.';
      } else if (msg.includes('invalid request') || msg.includes('formato')) {
        errorMessage = 'Formato de imagem inválido. Use uma foto no formato JPG ou PNG.';
        throw new Error(errorMessage);
      } else if (msg.includes('nenhum alimento') || msg.includes('não foi possível identificar')) {
        throw error;
      }
      throw new Error(errorMessage);
    }
    throw new Error(errorMessage);
  }
}