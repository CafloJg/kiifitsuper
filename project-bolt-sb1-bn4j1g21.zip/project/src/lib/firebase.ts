import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, enableIndexedDbPersistence, enableNetwork, disableNetwork } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  // TODO: Replace with your Firebase config
  apiKey: "AIzaSyCuiJLUrs61K7kGiHbGy7aeEFlVTHQsQMM",
  authDomain: "kiifit-4234c.firebaseapp.com",
  projectId: "kiifit-4234c",
  storageBucket: "kiifit-4234c.firebasestorage.app",
  messagingSenderId: "844707940642",
  appId: "844707940642"
};

const app = initializeApp(firebaseConfig);

// Initialize Firestore
const db = getFirestore(app);

// Enable persistence with error handling
enableIndexedDbPersistence(db).catch((err) => {
  if (err.code === 'failed-precondition') {
    console.warn('Multiple tabs open, persistence enabled in first tab only');
  } else if (err.code === 'unimplemented') {
    console.warn('Browser does not support persistence');
  }
});

const auth = getAuth(app);
const storage = getStorage(app);


export { auth, db, storage, enableNetwork, disableNetwork };