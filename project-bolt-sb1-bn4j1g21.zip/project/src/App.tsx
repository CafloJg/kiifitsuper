import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { auth, db } from './lib/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import Login from './pages/Login';
import Register from './pages/Register';
import ResetPassword from './pages/ResetPassword';
import Onboarding from './pages/Onboarding';
import Dashboard from './pages/Dashboard';
import Goals from './pages/Goals';
import Diet from './pages/Diet';
import Chat from './pages/Chat';
import Admin from './pages/Admin';
import Profile from './pages/Profile';
import { resetDailyStats } from './utils/dailyReset';
import type { UserProfile } from './types/user';
import NetworkStatus from './components/NetworkStatus';

function App() {
  useEffect(() => {
    const setupDailyReset = async () => {
      if (!auth.currentUser) return;

      // Get current time and calculate time until midnight
      const now = new Date();
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0);
      
      const timeUntilMidnight = tomorrow.getTime() - now.getTime();

      // Check if we need to reset now
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const userDoc = await getDoc(userRef);
      const userData = userDoc.data() as UserProfile;

      if (userData?.lastCheckIn) {
        const lastCheckDate = new Date(userData.lastCheckIn);
        const today = new Date();
        
        // If last check-in was not today, trigger auto check-in
        if (lastCheckDate.getDate() !== today.getDate() ||
            lastCheckDate.getMonth() !== today.getMonth() ||
            lastCheckDate.getFullYear() !== today.getFullYear()) {
          await resetDailyStats();
          
          // Update check-in streak
          const yesterday = new Date(today);
          yesterday.setDate(yesterday.getDate() - 1);
          
          const streak = lastCheckDate.getDate() === yesterday.getDate() ? 
            (userData.checkInStreak || 0) + 1 : 1;

          await updateDoc(userRef, {
            lastCheckIn: today.toISOString(),
            checkInStreak: streak
          });
        }
      }

      // Schedule next reset at midnight
      const scheduleNextReset = () => {
        const timer = setTimeout(async () => {
          if (auth.currentUser) {
            await resetDailyStats();
            // Set up daily interval after first reset
            setInterval(async () => {
              if (auth.currentUser) {
                await resetDailyStats();
              }
            }, 24 * 60 * 60 * 1000);
          }
        }, timeUntilMidnight);

        return timer;
      };

      const timer = scheduleNextReset();
      return () => clearTimeout(timer);
    };

    setupDailyReset();
  }, []);

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/onboarding" element={<Onboarding />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/goals" element={<Goals />} />
        <Route path="/diet" element={<Diet />} />
        <Route path="/chat" element={<Chat />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/profile" element={<Profile />} />
      </Routes>
      <NetworkStatus />
    </BrowserRouter>
  );
}

export default App;