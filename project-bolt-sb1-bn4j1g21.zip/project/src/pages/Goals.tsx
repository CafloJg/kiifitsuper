import React, { useState, useEffect } from 'react';
import { auth, db } from '../lib/firebase';
import { doc, updateDoc, arrayUnion, getDoc } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Scale, 
  Calendar, 
  Target, 
  Activity, 
  Trophy, 
  Plus, 
  ChevronRight,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import BottomNav from '../components/BottomNav';
import { checkBasicPlanLimits } from '../utils/planLimits';
import type { UserProfile, GoalType, ActivityLevel, CustomGoal, Achievement } from '../types/user';
import type { WeightProgress } from '../types/user';

function Goals() {
  const navigate = useNavigate();
  const [userData, setUserData] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [showWeightCheck, setShowWeightCheck] = useState(false);
  const [showCongratulations, setShowCongratulations] = useState(false);
  const [currentWeight, setCurrentWeight] = useState<number>(0);

  useEffect(() => {
    loadUserData();
  }, [navigate]);

  const loadUserData = async () => {
    if (!auth.currentUser) {
      navigate('/login');
      return;
    }

    try {
      const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
      if (userDoc.exists()) {
        const data = userDoc.data() as UserProfile;
        setUserData(data);
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      setError('Erro ao carregar seus dados');
    } finally {
      setIsLoading(false);
    }
  };

  const calculateProgress = () => {
    if (!userData?.goals?.targetWeight || !userData.weight) return 0;
    
    const initialWeight = userData.weightProgress?.[0]?.weight || userData.weight;
    const currentWeight = userData.weight;
    const targetWeight = userData.goals.targetWeight;
    
    // Se o objetivo é perder peso
    if (initialWeight > targetWeight) {
      const totalToLose = initialWeight - targetWeight;
      const lost = initialWeight - currentWeight;
      return Math.min(Math.round((lost / totalToLose) * 100), 100);
    }
    
    // Se o objetivo é ganhar peso
    if (initialWeight < targetWeight) {
      const totalToGain = targetWeight - initialWeight;
      const gained = currentWeight - initialWeight;
      return Math.min(Math.round((gained / totalToGain) * 100), 100);
    }
    
    return 100; // Manutenção
  };

  const getProgressStats = () => {
    if (!userData?.weightProgress?.length) return null;

    const initialWeight = userData.weightProgress[0].weight;
    const currentWeight = userData.weight || 0;
    const difference = currentWeight - initialWeight;
    
    const weeklyAverage = userData.weightProgress
      .slice(-7) // Últimos 7 registros
      .reduce((acc, curr, idx, arr) => {
        if (idx === 0) return 0;
        return acc + (curr.weight - arr[idx - 1].weight);
      }, 0) / 6; // Média das diferenças

    return {
      totalChange: difference.toFixed(1),
      weeklyAverage: weeklyAverage.toFixed(1),
      daysTracking: userData.weightProgress.length
    };
  };

  const handleWeightCheck = async () => {
    if (!auth.currentUser || !userData || !currentWeight) return;

    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const lastWeight = userData.weight || 0;
      const difference = currentWeight - lastWeight;
      const now = new Date().toISOString();

      const progress: WeightProgress = {
        weight: currentWeight,
        date: now,
        difference
      };

      await updateDoc(userRef, {
        weight: currentWeight,
        weightProgress: [...(userData.weightProgress || []), progress],
        updatedAt: now
      });

      setUserData(prev => ({
        ...prev!,
        weight: currentWeight,
        weightProgress: [...(prev?.weightProgress || []), progress]
      }));

      setShowWeightCheck(false);

      // Check if goal is completed
      const goalProgress = calculateProgress();
      if (goalProgress >= 100) {
        setShowCongratulations(true);
      }
    } catch (error) {
      console.error('Erro ao salvar peso:', error);
      setError('Erro ao salvar progresso. Por favor, tente novamente.');
    }
  };

  const handleGoalCompletion = async () => {
    if (!auth.currentUser || !userData?.goals) return;

    try {
      const archivedGoal = {
        ...userData.goals,
        completedAt: new Date().toISOString(),
        initialWeight: userData.weightProgress?.[0]?.weight || userData.weight,
        finalWeight: userData.weight
      };

      const userRef = doc(db, 'users', auth.currentUser.uid);
      await updateDoc(userRef, {
        'archivedGoals': arrayUnion(archivedGoal),
        'goals': null,
        'totalCoins': (userData.totalCoins || 0) + 100 // Bonus coins
      });

      setShowCongratulations(false);
      navigate('/onboarding');
    } catch (error) {
      console.error('Error handling goal completion:', error);
      setError('Erro ao atualizar metas. Por favor, tente novamente.');
    }
  };

  const renderWeightCheckModal = () => {
    if (!showWeightCheck) return null;

    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl max-w-lg w-full">
          <div className="p-6">
            <div className="flex items-center justify-center mb-6">
              <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center">
                <Scale className="text-primary-500" size={32} />
              </div>
            </div>

            <h3 className="text-xl font-semibold text-center mb-2">Check-in de Peso</h3>
            <p className="text-gray-600 text-center mb-6">
              Registre seu peso atual para acompanhar seu progresso
            </p>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Peso Atual (kg)
              </label>
              <input
                type="number"
                value={currentWeight || ''}
                onChange={(e) => setCurrentWeight(Number(e.target.value))}
                step="0.1"
                min="20"
                max="300"
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                placeholder="Ex: 70.5"
              />
            </div>

            <div className="space-y-3">
              <button
                onClick={handleWeightCheck}
                disabled={!currentWeight}
                className="w-full bg-primary-500 text-white rounded-xl py-3 hover:bg-primary-600 transition-colors disabled:opacity-50"
              >
                Registrar Peso
              </button>
              <button
                onClick={() => setShowWeightCheck(false)}
                className="w-full text-gray-600 py-2 hover:text-gray-800"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderCongratulationsModal = () => {
    if (!showCongratulations) return null;

    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl max-w-lg w-full text-center p-6">
          <div className="w-20 h-20 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <Trophy className="text-primary-500" size={40} />
          </div>
          
          <h3 className="text-2xl font-semibold mb-2">Parabéns!</h3>
          <p className="text-gray-600 mb-6">
            Você atingiu sua meta de {userData?.goals?.type === 'loss' ? 'emagrecimento' : 'ganho de peso'}!
            <br />
            <span className="font-medium">+100 moedas</span> foram adicionadas à sua conta.
          </p>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="p-4 bg-gray-50 rounded-xl">
              <p className="text-sm text-gray-600">Peso Inicial</p>
              <p className="text-lg font-semibold">
                {userData?.weightProgress?.[0]?.weight || userData?.weight}kg
              </p>
            </div>
            <div className="p-4 bg-gray-50 rounded-xl">
              <p className="text-sm text-gray-600">Peso Final</p>
              <p className="text-lg font-semibold">{userData?.weight}kg</p>
            </div>
          </div>

          <button
            onClick={handleGoalCompletion}
            className="w-full bg-primary-500 text-white rounded-xl py-3 hover:bg-primary-600 transition-colors"
          >
            Definir Nova Meta
          </button>
        </div>
      </div>
    );
  };

  const renderWeightProgress = () => {
    if (!userData?.weightProgress?.length) return null;

    const sortedProgress = [...userData.weightProgress]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 7); // Últimos 7 registros

    return (
      <div className="bg-white rounded-2xl p-6 shadow-sm mb-6">
        <h2 className="text-lg font-medium mb-4">Histórico de Peso</h2>
        <div className="space-y-4">
          {sortedProgress.map((progress, index) => (
            <div key={index} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  progress.difference === 0 
                    ? 'bg-gray-50' 
                    : progress.difference < 0 
                    ? 'bg-green-50' 
                    : 'bg-red-50'
                }`}>
                  {progress.difference === 0 ? (
                    <Minus className="text-gray-500" size={20} />
                  ) : progress.difference < 0 ? (
                    <TrendingDown className="text-green-500" size={20} />
                  ) : (
                    <TrendingUp className="text-red-500" size={20} />
                  )}
                </div>
                <div>
                  <p className="font-medium">{progress.weight} kg</p>
                  <p className="text-sm text-gray-500">
                    {new Date(progress.date).toLocaleDateString('pt-BR', {
                      day: '2-digit',
                      month: '2-digit',
                      year: '2-digit'
                    })}
                  </p>
                </div>
              </div>
              <span className={`text-sm font-medium ${
                progress.difference === 0 
                  ? 'text-gray-500' 
                  : progress.difference < 0 
                  ? 'text-green-500' 
                  : 'text-red-500'
              }`}>
                {progress.difference === 0 
                  ? 'Manteve' 
                  : progress.difference > 0 
                  ? `+${progress.difference.toFixed(1)}kg` 
                  : `${progress.difference.toFixed(1)}kg`}
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-lg mx-auto px-4 py-6 pb-20">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Metas e Progresso</h1>
            <p className="text-gray-600">Acompanhe sua evolução</p>
          </div>
          <button
            onClick={() => setShowWeightCheck(true)}
            className="flex items-center gap-2 px-6 py-3 bg-primary-500 text-white rounded-xl hover:bg-primary-600 transition-colors shadow-sm hover:shadow-lg active:scale-95"
          >
            <Scale size={20} />
            <span className="font-medium">Registrar Peso</span>
          </button>
        </div>

        {/* Progresso Geral */}
        <div className="bg-white rounded-2xl p-6 shadow-sm mb-6">
          <h2 className="text-lg font-medium mb-4">Progresso Geral</h2>
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="text-center p-4 bg-gray-50 rounded-xl">
              <p className="text-sm text-gray-600">Total</p>
              <p className="text-xl font-semibold text-primary-500">
                {getProgressStats()?.totalChange || '0'}kg
              </p>
              <p className="text-xs text-gray-500">Desde o início</p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-xl">
              <p className="text-sm text-gray-600">Média</p>
              <p className="text-xl font-semibold text-primary-500">
                {getProgressStats()?.weeklyAverage || '0'}kg
              </p>
              <p className="text-xs text-gray-500">Por semana</p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-xl">
              <p className="text-sm text-gray-600">Dias</p>
              <p className="text-xl font-semibold text-primary-500">
                {getProgressStats()?.daysTracking || '0'}
              </p>
              <p className="text-xs text-gray-500">De tracking</p>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="relative">
            <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary-500 rounded-full transition-all duration-500"
                style={{ width: `${calculateProgress()}%` }}
              />
            </div>
          </div>
        </div>

        {/* Weight Progress History */}
        {renderWeightProgress()}

        {/* Modals */}
        {renderWeightCheckModal()}
        {renderCongratulationsModal()}
      </div>
      <BottomNav />
    </div>
  );
}

export default Goals;