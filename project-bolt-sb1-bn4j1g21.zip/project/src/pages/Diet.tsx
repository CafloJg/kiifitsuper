import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Utensils, 
  ChevronRight, 
  Activity, 
  TrendingUp, 
  Target, 
  RefreshCw, 
  Calculator, 
  Apple, 
  AlertCircle, 
  Camera, 
  Calendar as CalendarIcon
} from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { generateMeals } from '../utils/dietGenerator';
import { calculateMacros } from '../lib/diet';
import MacroCalculator from '../components/MacroCalculator';
import DietCalendar from '../components/DietCalendar';
import MealCard from '../components/MealCard';
import DietProgress from '../components/DietProgress';
import MealSuggestions from '../components/MealSuggestions';
import BottomNav from '../components/BottomNav';
import ARCamera from '../components/ARCamera';
import type { FoodAnalysis } from '../types/food';
import type { UserProfile, Meal, DietPlan } from '../types/user';

function Diet() {
  const navigate = useNavigate();
  const [userData, setUserData] = useState<UserProfile | null>(null);
  const [dietPlan, setDietPlan] = useState<DietPlan | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const [error, setError] = useState('');
  const [completedMeals, setCompletedMeals] = useState<string[]>([]);
  const [showCamera, setShowCamera] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState<string | null>(null);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [dietHistory, setDietHistory] = useState<DietPlan[]>([]);

  useEffect(() => {
    loadUserData();
  }, [navigate]);

  const loadUserData = async () => {
    if (!auth.currentUser) {
      navigate('/login');
      return;
    }

    try {
      const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
      if (userDoc.exists()) {
        const data = userDoc.data() as UserProfile;
        setUserData(data);
        
        // Combine current plan with diet history
        const allPlans = [];
        
        if (data.currentDietPlan) {
          allPlans.push({
            ...data.currentDietPlan,
            date: new Date().toISOString().split('T')[0]
          });
          setDietPlan(data.currentDietPlan);
          
          // Load completed meals for today
          const today = new Date().toISOString().split('T')[0];
          const todayMeals = data.dailyStats?.completedMeals?.[today] || [];
          setCompletedMeals(todayMeals);
        }
        
        if (data.dietHistory?.plans) {
          const cutoffDate = new Date();
          cutoffDate.setDate(cutoffDate.getDate() - 120);
          
          allPlans.push(
            ...data.dietHistory.plans.filter(plan => 
              new Date(plan.date || plan.createdAt) > cutoffDate
            )
          );
        }
        
        // Sort by date descending
        allPlans.sort((a, b) => 
          new Date(b.date || b.createdAt).getTime() - 
          new Date(a.date || a.createdAt).getTime()
        );
        
        setDietHistory(allPlans);
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      setError('Erro ao carregar seu plano alimentar');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateNewPlan = async () => {
    if (!userData) return;
    
    if (isGenerating) return;
    
    // Validate required data first
    if (!userData.weight || !userData.height || !userData.age || !userData.gender) {
      setError('Complete seu perfil antes de gerar um plano alimentar');
      return;
    }

    if (!userData.goals?.type) {
      setError('Configure suas metas antes de gerar um plano alimentar');
      return;
    }

    if (!userData.dietType) {
      setError('Selecione um tipo de dieta no seu perfil');
      return;
    }

    const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
    if (!apiKey?.trim()) {
      setError('Serviço temporariamente indisponível. Por favor, tente novamente mais tarde.');
      return;
    }
    
    setIsGenerating(true);
    setGenerationProgress(0);
    setError('');
    
    // Clear any previous error
    const errorDiv = document.querySelector('.bg-red-50');
    if (errorDiv) {
      errorDiv.remove();
    }

    const now = new Date().toISOString();
    const today = now.split('T')[0];

    // Start progress animation
    const duration = 20000; // 20 seconds
    const interval = 100; // Update every 100ms
    const steps = duration / interval;
    let currentStep = 0;

    const progressTimer = setInterval(() => {
      currentStep++;
      const progress = Math.min((currentStep / steps) * 100, 95);
      setGenerationProgress(progress);
    }, interval);

    try {
      const newPlan = await generateMeals(userData);

      // Reset daily stats
      setGenerationProgress(100);
      const resetStats = {
        caloriesConsumed: 0,
        proteinConsumed: 0,
        carbsConsumed: 0,
        fatConsumed: 0,
        waterIntake: 0,
        macroDistribution: {
          protein: 0,
          carbs: 0,
          fat: 0
        },
        completedMeals: {
          [today]: []
        },
        lastUpdated: now
      };
      
      // Reset completed meals and local state
      setCompletedMeals([]);
      setUserData(prev => ({
        ...prev!,
        dailyStats: resetStats,
        currentDietPlan: newPlan
      }));
      setDietPlan(newPlan);

      // Update user document
      await updateDoc(doc(db, 'users', auth.currentUser!.uid), {
        currentDietPlan: newPlan,
        lastPlanGenerated: now,
        dailyStats: resetStats,
        'currentDietPlan.dailyStats': resetStats
      });

      setDietPlan(newPlan);
      
    } catch (error) {
      console.error('Erro ao gerar plano:', error);
      setError(
        error instanceof Error 
          ? error.message.includes('API key') 
            ? 'Serviço temporariamente indisponível. Por favor, tente novamente mais tarde.'
            : error.message
          : 'Erro ao gerar plano. Por favor, tente novamente.'
      );
    } finally {
      clearInterval(progressTimer);
      setIsGenerating(false);
      setTimeout(() => setGenerationProgress(0), 1000);
    }
  };

  const handleMealCheckIn = async (mealId: string) => {
    if (!auth.currentUser || !userData || !dietPlan) return;

    const meal = dietPlan.meals.find(m => m.id === mealId);
    if (!meal) return;

    const now = new Date();
    const today = now.toISOString().split('T')[0];
    const isCurrentPlan = dietPlan === userData.currentDietPlan;

    // Calculate new stats
    const currentStats = userData.dailyStats || {
      caloriesConsumed: 0,
      proteinConsumed: 0,
      carbsConsumed: 0,
      fatConsumed: 0,
      waterIntake: 0,
      completedMeals: {},
      lastUpdated: now.toISOString()
    };

    const newCompletedMeals = [...completedMeals, mealId];

    const newStats = {
      caloriesConsumed: currentStats.caloriesConsumed + meal.calories,
      proteinConsumed: currentStats.proteinConsumed + meal.protein,
      carbsConsumed: currentStats.carbsConsumed + meal.carbs,
      fatConsumed: currentStats.fatConsumed + meal.fat,
      waterIntake: currentStats.waterIntake,
      completedMeals: {
        ...currentStats.completedMeals,
        [today]: newCompletedMeals
      },
      lastUpdated: now.toISOString()
    };

    // Update local state immediately
    setCompletedMeals(newCompletedMeals);
    setUserData(prev => ({
      ...prev!,
      dailyStats: newStats,
      currentDietPlan: {
        ...prev!.currentDietPlan!,
        dailyStats: newStats
      }
    }));

    // Update Firestore
    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      
      if (isCurrentPlan) {
        // Update current plan stats
        await updateDoc(userRef, {
          dailyStats: newStats,
          'currentDietPlan.dailyStats': newStats
        });
      } else {
        // Update history plan stats
        const updatedHistory = {
          ...userData.dietHistory,
          plans: userData.dietHistory?.plans.map(p => 
            p.id === dietPlan.id 
              ? { ...p, dailyStats: newStats }
              : p
          )
        };
        
        await updateDoc(userRef, {
          'dietHistory': updatedHistory
        });
      }
      
      // Refresh diet history
      loadUserData();
    } catch (error) {
      console.error('Error updating meal stats:', error);
      // Revert local state on error
      setCompletedMeals(completedMeals);
      setUserData(userData);
      setError('Erro ao atualizar refeição. Tente novamente.');
    }
  };

  const handleFoodAnalysis = async (analysis: FoodAnalysis) => {
    if (!analysis.ingredients.length) return;
    
    setError('');
    try {
      // Calculate macros for detected ingredients
      const macros = await calculateMacros(analysis.ingredients);
      
      // Update daily stats
      if (auth.currentUser && userData) {
        const userRef = doc(db, 'users', auth.currentUser.uid);
        const dailyStats = {
          ...userData.dailyStats,
          caloriesConsumed: (userData.dailyStats?.caloriesConsumed || 0) + macros.calories,
          proteinConsumed: (userData.dailyStats?.proteinConsumed || 0) + macros.protein,
          carbsConsumed: (userData.dailyStats?.carbsConsumed || 0) + macros.carbs,
          fatConsumed: (userData.dailyStats?.fatConsumed || 0) + macros.fat,
          lastUpdated: new Date().toISOString()
        };

        await updateDoc(userRef, {
          dailyStats,
          foodAnalysis: analysis
        });

        setUserData(prev => ({
          ...prev!,
          dailyStats,
          foodAnalysis: analysis
        }));
      }
    } catch (error) {
      console.error('Erro ao processar análise:', error);
      setShowCamera(false);
      setError(
        error instanceof Error 
          ? error.message 
          : 'Erro ao processar análise. Por favor, tente novamente.'
      );
    }
  };

  const handleMealUpdate = async (updatedMeal: Meal) => {
    if (!auth.currentUser || !dietPlan) return;
    const isCurrentPlan = dietPlan === userData?.currentDietPlan;

    try {
      const updatedPlan = {
        ...dietPlan,
        meals: dietPlan.meals.map(meal =>
          meal.id === updatedMeal.id ? updatedMeal : meal
        )
      };

      const userRef = doc(db, 'users', auth.currentUser.uid);
      
      if (isCurrentPlan) {
        await updateDoc(userRef, {
          currentDietPlan: updatedPlan
        });
      } else {
        // Update plan in history
        const updatedHistory = {
          ...userData?.dietHistory,
          plans: userData?.dietHistory?.plans.map(p => 
            p.id === dietPlan.id ? updatedPlan : p
          )
        };
        
        await updateDoc(userRef, {
          'dietHistory': updatedHistory
        });
      }

      setDietPlan(updatedPlan);
      setShowSuggestions(null);
      
      // Refresh data to ensure consistency
      loadUserData();
    } catch (error) {
      console.error('Erro ao atualizar refeição:', error);
      setError('Erro ao atualizar refeição. Por favor, tente novamente.');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-lg mx-auto px-4 py-6 pb-20">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Dieta</h1>
            <p className="text-gray-600">Seu plano alimentar personalizado</p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => setShowCalendar(true)}
              className="p-3 bg-white rounded-xl shadow-sm hover:bg-gray-50 transition-colors"
              title="Histórico de Dietas"
            >
              <CalendarIcon size={20} />
            </button>
            <button
              onClick={() => setShowCalculator(true)}
              className="p-3 bg-white rounded-xl shadow-sm hover:bg-gray-50 transition-colors"
              title="Calculadora de Macros"
            >
              <Calculator size={20} />
            </button>
            <button
              onClick={() => setShowCamera(true)}
              className="p-3 bg-white rounded-xl shadow-sm hover:bg-gray-50 transition-colors"
              title="Analisar Alimentos"
            >
              <Camera size={20} />
            </button>
            <button
              onClick={handleGenerateNewPlan}
              disabled={isGenerating}
              className="p-3 bg-white rounded-xl shadow-sm hover:bg-gray-50 transition-colors disabled:opacity-50"
              title="Gerar Novo Plano"
            >
              <RefreshCw size={20} className={isGenerating ? 'animate-spin' : ''} />
            </button>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 rounded-xl p-4 mb-6">
            <div className="flex items-center gap-3">
              <AlertCircle className="text-red-500" size={24} />
              <div>
                <h3 className="font-medium text-red-800">Erro ao gerar plano</h3>
                <p className="text-red-600">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Generation Progress */}
        {isGenerating && (
          <div className="bg-white rounded-xl p-6 mb-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium">Gerando Plano Alimentar</h3>
              <span className="text-primary-500 font-medium">{Math.round(generationProgress)}%</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary-500 transition-all duration-300 ease-out"
                style={{ width: `${generationProgress}%` }}
              />
            </div>
            <p className="text-sm text-gray-500 mt-4">
              {generationProgress < 30 && "Analisando suas preferências..."}
              {generationProgress >= 30 && generationProgress < 60 && "Calculando macronutrientes..."}
              {generationProgress >= 60 && generationProgress < 90 && "Montando refeições balanceadas..."}
              {generationProgress >= 90 && "Finalizando seu plano..."}
            </p>
          </div>
        )}

        {dietPlan ? (
          <>
            {/* Progress Charts */}
            <DietProgress 
              plans={dietHistory}
              currentPlan={dietPlan}
            />

            {/* Meal Cards */}
            <div className="space-y-4 mt-6">
              {dietPlan.meals.map((meal) => (
                <React.Fragment key={meal.id}>
                  {showSuggestions === meal.id ? (
                    <MealSuggestions
                      meal={meal}
                      onSelect={handleMealUpdate}
                      onFavorite={async (favoriteMeal) => {
                        if (!auth.currentUser || !userData) return;
                        
                        try {
                          await updateDoc(doc(db, 'users', auth.currentUser.uid), {
                            [`favoriteMeals.${favoriteMeal.id}`]: {
                              ...favoriteMeal,
                              savedAt: new Date().toISOString()
                            }
                          });
                        } catch (error) {
                          console.error('Erro ao favoritar refeição:', error);
                        }
                      }}
                    />
                  ) : (
                    <div className="relative">
                      <MealCard 
                        meal={meal}
                        onCheckIn={handleMealCheckIn}
                        isCompleted={completedMeals.includes(meal.id)}
                      />
                      <button
                        onClick={() => setShowSuggestions(meal.id)}
                        className="absolute top-4 right-4 p-2 bg-white rounded-lg shadow-sm hover:bg-gray-50 transition-colors"
                      >
                        <ChevronRight size={20} />
                      </button>
                    </div>
                  )}
                </React.Fragment>
              ))}
            </div>
          </>
        ) : (
          <div className="bg-white rounded-2xl p-6 shadow-sm text-center">
            <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Apple className="text-primary-500" size={32} />
            </div>
            <h2 className="text-xl font-semibold mb-2">Nenhum plano encontrado</h2>
            <p className="text-gray-600 mb-6">
              Gere seu primeiro plano alimentar personalizado
            </p>
            <button
              onClick={handleGenerateNewPlan}
              disabled={isGenerating}
              className="w-full bg-primary-500 text-white rounded-lg py-3 hover:bg-primary-600 transition-colors disabled:opacity-50"
            >
              {isGenerating ? 'Gerando plano...' : 'Gerar Plano Alimentar'}
            </button>
          </div>
        )}
      </div>

      {showCalculator && (
        <MacroCalculator onClose={() => setShowCalculator(false)} />
      )}
      
      {showCamera && (
        <ARCamera
          onClose={() => setShowCamera(false)}
          onAnalysis={handleFoodAnalysis}
        />
      )}
      
      {showCalendar && (
        <DietCalendar
          plans={dietHistory}
          onSelectPlan={(plan) => {
            setDietPlan(plan);
            setShowCalendar(false);
          }}
          onClose={() => setShowCalendar(false)}
        />
      )}
      
      <BottomNav />
    </div>
  );
}

export default Diet;