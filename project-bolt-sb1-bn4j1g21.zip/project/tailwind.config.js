/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#FEF1FA',
          100: '#FDE4F6',
          200: '#FBC9ED',
          300: '#F9AEE4',
          400: '#F793DB',
          500: '#F840BA',
          600: '#F733B5',
          700: '#F626AF',
          800: '#F519A9',
          900: '#F30C9E'
        },
        secondary: {
          50: '#FDF6F3',
          100: '#FCEDE7',
          200: '#F9DBCF',
          300: '#F5C9B7',
          400: '#F2B79F',
          500: '#EE8B60',
          600: '#EC7E4F',
          700: '#EA713E',
          800: '#E8642D',
          900: '#E6571C'
        }
      },
      fontFamily: {
        sans: ['Nunito', 'system-ui', 'sans-serif'],
        display: ['Comfortaa', 'cursive']
      }
    },
  },
  plugins: [],
};